"use strict";
var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// node_modules/@anthropic-ai/sdk/internal/tslib.js
var require_tslib = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/tslib.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.__setModuleDefault = exports2.__createBinding = void 0;
    exports2.__classPrivateFieldSet = __classPrivateFieldSet;
    exports2.__classPrivateFieldGet = __classPrivateFieldGet;
    exports2.__importStar = __importStar;
    exports2.__exportStar = __exportStar;
    function __classPrivateFieldSet(receiver, state, value, kind, f) {
      if (kind === "m")
        throw new TypeError("Private method is not writable");
      if (kind === "a" && !f)
        throw new TypeError("Private accessor was defined without a setter");
      if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver))
        throw new TypeError("Cannot write private member to an object whose class did not declare it");
      return kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
    }
    function __classPrivateFieldGet(receiver, state, kind, f) {
      if (kind === "a" && !f)
        throw new TypeError("Private accessor was defined without a getter");
      if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver))
        throw new TypeError("Cannot read private member from an object whose class did not declare it");
      return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
    }
    var __createBinding = Object.create ? function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = {
          enumerable: true,
          get: function() {
            return m[k];
          }
        };
      }
      Object.defineProperty(o, k2, desc);
    } : function(o, m, k, k2) {
      if (k2 === void 0)
        k2 = k;
      o[k2] = m[k];
    };
    exports2.__createBinding = __createBinding;
    var __setModuleDefault = Object.create ? function(o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
    } : function(o, v) {
      o["default"] = v;
    };
    exports2.__setModuleDefault = __setModuleDefault;
    var ownKeys = function(o) {
      ownKeys = Object.getOwnPropertyNames || function(o2) {
        var ar = [];
        for (var k in o2)
          if (Object.prototype.hasOwnProperty.call(o2, k))
            ar[ar.length] = k;
        return ar;
      };
      return ownKeys(o);
    };
    function __importStar(mod) {
      if (mod && mod.__esModule)
        return mod;
      var result = {};
      if (mod != null) {
        for (var k = ownKeys(mod), i = 0; i < k.length; i++)
          if (k[i] !== "default")
            __createBinding(result, mod, k[i]);
      }
      __setModuleDefault(result, mod);
      return result;
    }
    function __exportStar(m, o) {
      for (var p in m)
        if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p))
          __createBinding(o, m, p);
    }
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/uuid.js
var require_uuid = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/uuid.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.uuid4 = void 0;
    var uuid4 = function() {
      const { crypto } = globalThis;
      if (crypto?.randomUUID) {
        exports2.uuid4 = crypto.randomUUID.bind(crypto);
        return crypto.randomUUID();
      }
      const u8 = new Uint8Array(1);
      const randomByte = crypto ? () => crypto.getRandomValues(u8)[0] : () => Math.random() * 255 & 255;
      return "10000000-1000-4000-8000-100000000000".replace(/[018]/g, (c) => (+c ^ randomByte() & 15 >> +c / 4).toString(16));
    };
    exports2.uuid4 = uuid4;
  }
});

// node_modules/@anthropic-ai/sdk/internal/errors.js
var require_errors = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/errors.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.castToError = void 0;
    exports2.isAbortError = isAbortError;
    function isAbortError(err) {
      return typeof err === "object" && err !== null && // Spec-compliant fetch implementations
      ("name" in err && err.name === "AbortError" || // Expo fetch
      "message" in err && String(err.message).includes("FetchRequestCanceledException"));
    }
    var castToError = (err) => {
      if (err instanceof Error)
        return err;
      if (typeof err === "object" && err !== null) {
        try {
          if (Object.prototype.toString.call(err) === "[object Error]") {
            const error = new Error(err.message, err.cause ? { cause: err.cause } : {});
            if (err.stack)
              error.stack = err.stack;
            if (err.cause && !error.cause)
              error.cause = err.cause;
            if (err.name)
              error.name = err.name;
            return error;
          }
        } catch {
        }
        try {
          return new Error(JSON.stringify(err));
        } catch {
        }
      }
      return new Error(err);
    };
    exports2.castToError = castToError;
  }
});

// node_modules/@anthropic-ai/sdk/core/error.js
var require_error = __commonJS({
  "node_modules/@anthropic-ai/sdk/core/error.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.InternalServerError = exports2.RateLimitError = exports2.UnprocessableEntityError = exports2.ConflictError = exports2.NotFoundError = exports2.PermissionDeniedError = exports2.AuthenticationError = exports2.BadRequestError = exports2.APIConnectionTimeoutError = exports2.APIConnectionError = exports2.APIUserAbortError = exports2.APIError = exports2.AnthropicError = void 0;
    var errors_1 = require_errors();
    var AnthropicError = class extends Error {
    };
    exports2.AnthropicError = AnthropicError;
    var APIError = class _APIError extends AnthropicError {
      constructor(status, error, message, headers, type) {
        super(`${_APIError.makeMessage(status, error, message)}`);
        this.status = status;
        this.headers = headers;
        this.requestID = headers?.get("request-id");
        this.error = error;
        this.type = type ?? null;
      }
      static makeMessage(status, error, message) {
        const msg = error?.message ? typeof error.message === "string" ? error.message : JSON.stringify(error.message) : error ? JSON.stringify(error) : message;
        if (status && msg) {
          return `${status} ${msg}`;
        }
        if (status) {
          return `${status} status code (no body)`;
        }
        if (msg) {
          return msg;
        }
        return "(no status code or body)";
      }
      static generate(status, errorResponse, message, headers) {
        if (!status || !headers) {
          return new APIConnectionError({ message, cause: (0, errors_1.castToError)(errorResponse) });
        }
        const error = errorResponse;
        const type = error?.["error"]?.["type"];
        if (status === 400) {
          return new BadRequestError(status, error, message, headers, type);
        }
        if (status === 401) {
          return new AuthenticationError(status, error, message, headers, type);
        }
        if (status === 403) {
          return new PermissionDeniedError(status, error, message, headers, type);
        }
        if (status === 404) {
          return new NotFoundError(status, error, message, headers, type);
        }
        if (status === 409) {
          return new ConflictError(status, error, message, headers, type);
        }
        if (status === 422) {
          return new UnprocessableEntityError(status, error, message, headers, type);
        }
        if (status === 429) {
          return new RateLimitError(status, error, message, headers, type);
        }
        if (status >= 500) {
          return new InternalServerError(status, error, message, headers, type);
        }
        return new _APIError(status, error, message, headers, type);
      }
    };
    exports2.APIError = APIError;
    var APIUserAbortError = class extends APIError {
      constructor({ message } = {}) {
        super(void 0, void 0, message || "Request was aborted.", void 0);
      }
    };
    exports2.APIUserAbortError = APIUserAbortError;
    var APIConnectionError = class extends APIError {
      constructor({ message, cause }) {
        super(void 0, void 0, message || "Connection error.", void 0);
        if (cause)
          this.cause = cause;
      }
    };
    exports2.APIConnectionError = APIConnectionError;
    var APIConnectionTimeoutError = class extends APIConnectionError {
      constructor({ message } = {}) {
        super({ message: message ?? "Request timed out." });
      }
    };
    exports2.APIConnectionTimeoutError = APIConnectionTimeoutError;
    var BadRequestError = class extends APIError {
    };
    exports2.BadRequestError = BadRequestError;
    var AuthenticationError = class extends APIError {
    };
    exports2.AuthenticationError = AuthenticationError;
    var PermissionDeniedError = class extends APIError {
    };
    exports2.PermissionDeniedError = PermissionDeniedError;
    var NotFoundError = class extends APIError {
    };
    exports2.NotFoundError = NotFoundError;
    var ConflictError = class extends APIError {
    };
    exports2.ConflictError = ConflictError;
    var UnprocessableEntityError = class extends APIError {
    };
    exports2.UnprocessableEntityError = UnprocessableEntityError;
    var RateLimitError = class extends APIError {
    };
    exports2.RateLimitError = RateLimitError;
    var InternalServerError = class extends APIError {
    };
    exports2.InternalServerError = InternalServerError;
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/values.js
var require_values = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/values.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.pop = exports2.safeJSON = exports2.maybeCoerceBoolean = exports2.maybeCoerceFloat = exports2.maybeCoerceInteger = exports2.coerceBoolean = exports2.coerceFloat = exports2.coerceInteger = exports2.validatePositiveInteger = exports2.ensurePresent = exports2.isReadonlyArray = exports2.isArray = exports2.isAbsoluteURL = void 0;
    exports2.maybeObj = maybeObj;
    exports2.isEmptyObj = isEmptyObj;
    exports2.hasOwn = hasOwn;
    exports2.isObj = isObj;
    var error_1 = require_error();
    var startsWithSchemeRegexp = /^[a-z][a-z0-9+.-]*:/i;
    var isAbsoluteURL = (url) => {
      return startsWithSchemeRegexp.test(url);
    };
    exports2.isAbsoluteURL = isAbsoluteURL;
    var isArray = (val) => (exports2.isArray = Array.isArray, (0, exports2.isArray)(val));
    exports2.isArray = isArray;
    exports2.isReadonlyArray = exports2.isArray;
    function maybeObj(x) {
      if (typeof x !== "object") {
        return {};
      }
      return x ?? {};
    }
    function isEmptyObj(obj) {
      if (!obj)
        return true;
      for (const _k in obj)
        return false;
      return true;
    }
    function hasOwn(obj, key) {
      return Object.prototype.hasOwnProperty.call(obj, key);
    }
    function isObj(obj) {
      return obj != null && typeof obj === "object" && !Array.isArray(obj);
    }
    var ensurePresent = (value) => {
      if (value == null) {
        throw new error_1.AnthropicError(`Expected a value to be given but received ${value} instead.`);
      }
      return value;
    };
    exports2.ensurePresent = ensurePresent;
    var validatePositiveInteger = (name, n) => {
      if (typeof n !== "number" || !Number.isInteger(n)) {
        throw new error_1.AnthropicError(`${name} must be an integer`);
      }
      if (n < 0) {
        throw new error_1.AnthropicError(`${name} must be a positive integer`);
      }
      return n;
    };
    exports2.validatePositiveInteger = validatePositiveInteger;
    var coerceInteger = (value) => {
      if (typeof value === "number")
        return Math.round(value);
      if (typeof value === "string")
        return parseInt(value, 10);
      throw new error_1.AnthropicError(`Could not coerce ${value} (type: ${typeof value}) into a number`);
    };
    exports2.coerceInteger = coerceInteger;
    var coerceFloat = (value) => {
      if (typeof value === "number")
        return value;
      if (typeof value === "string")
        return parseFloat(value);
      throw new error_1.AnthropicError(`Could not coerce ${value} (type: ${typeof value}) into a number`);
    };
    exports2.coerceFloat = coerceFloat;
    var coerceBoolean = (value) => {
      if (typeof value === "boolean")
        return value;
      if (typeof value === "string")
        return value === "true";
      return Boolean(value);
    };
    exports2.coerceBoolean = coerceBoolean;
    var maybeCoerceInteger = (value) => {
      if (value == null) {
        return void 0;
      }
      return (0, exports2.coerceInteger)(value);
    };
    exports2.maybeCoerceInteger = maybeCoerceInteger;
    var maybeCoerceFloat = (value) => {
      if (value == null) {
        return void 0;
      }
      return (0, exports2.coerceFloat)(value);
    };
    exports2.maybeCoerceFloat = maybeCoerceFloat;
    var maybeCoerceBoolean = (value) => {
      if (value == null) {
        return void 0;
      }
      return (0, exports2.coerceBoolean)(value);
    };
    exports2.maybeCoerceBoolean = maybeCoerceBoolean;
    var safeJSON = (text) => {
      try {
        return JSON.parse(text);
      } catch (err) {
        return void 0;
      }
    };
    exports2.safeJSON = safeJSON;
    var pop = (obj, key) => {
      const value = obj[key];
      delete obj[key];
      return value;
    };
    exports2.pop = pop;
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/sleep.js
var require_sleep = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/sleep.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.sleep = void 0;
    var sleep = (ms, signal) => new Promise((resolve) => {
      if (signal?.aborted)
        return resolve();
      const onAbort = () => {
        clearTimeout(timer);
        resolve();
      };
      const timer = setTimeout(() => {
        signal?.removeEventListener("abort", onAbort);
        resolve();
      }, ms);
      signal?.addEventListener("abort", onAbort, { once: true });
    });
    exports2.sleep = sleep;
  }
});

// node_modules/@anthropic-ai/sdk/version.js
var require_version = __commonJS({
  "node_modules/@anthropic-ai/sdk/version.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.VERSION = void 0;
    exports2.VERSION = "0.100.1";
  }
});

// node_modules/@anthropic-ai/sdk/internal/detect-platform.js
var require_detect_platform = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/detect-platform.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.getPlatformHeaders = exports2.isRunningInBrowser = void 0;
    var version_1 = require_version();
    var isRunningInBrowser = () => {
      return (
        // @ts-ignore
        typeof window !== "undefined" && // @ts-ignore
        typeof window.document !== "undefined" && // @ts-ignore
        typeof navigator !== "undefined"
      );
    };
    exports2.isRunningInBrowser = isRunningInBrowser;
    function getDetectedPlatform() {
      if (typeof Deno !== "undefined" && Deno.build != null) {
        return "deno";
      }
      if (typeof EdgeRuntime !== "undefined") {
        return "edge";
      }
      if (Object.prototype.toString.call(typeof globalThis.process !== "undefined" ? globalThis.process : 0) === "[object process]") {
        return "node";
      }
      return "unknown";
    }
    var getPlatformProperties = () => {
      const detectedPlatform = getDetectedPlatform();
      if (detectedPlatform === "deno") {
        return {
          "X-Stainless-Lang": "js",
          "X-Stainless-Package-Version": version_1.VERSION,
          "X-Stainless-OS": normalizePlatform(Deno.build.os),
          "X-Stainless-Arch": normalizeArch(Deno.build.arch),
          "X-Stainless-Runtime": "deno",
          "X-Stainless-Runtime-Version": typeof Deno.version === "string" ? Deno.version : Deno.version?.deno ?? "unknown"
        };
      }
      if (typeof EdgeRuntime !== "undefined") {
        return {
          "X-Stainless-Lang": "js",
          "X-Stainless-Package-Version": version_1.VERSION,
          "X-Stainless-OS": "Unknown",
          "X-Stainless-Arch": `other:${EdgeRuntime}`,
          "X-Stainless-Runtime": "edge",
          "X-Stainless-Runtime-Version": globalThis.process.version
        };
      }
      if (detectedPlatform === "node") {
        return {
          "X-Stainless-Lang": "js",
          "X-Stainless-Package-Version": version_1.VERSION,
          "X-Stainless-OS": normalizePlatform(globalThis.process.platform ?? "unknown"),
          "X-Stainless-Arch": normalizeArch(globalThis.process.arch ?? "unknown"),
          "X-Stainless-Runtime": "node",
          "X-Stainless-Runtime-Version": globalThis.process.version ?? "unknown"
        };
      }
      const browserInfo = getBrowserInfo();
      if (browserInfo) {
        return {
          "X-Stainless-Lang": "js",
          "X-Stainless-Package-Version": version_1.VERSION,
          "X-Stainless-OS": "Unknown",
          "X-Stainless-Arch": "unknown",
          "X-Stainless-Runtime": `browser:${browserInfo.browser}`,
          "X-Stainless-Runtime-Version": browserInfo.version
        };
      }
      return {
        "X-Stainless-Lang": "js",
        "X-Stainless-Package-Version": version_1.VERSION,
        "X-Stainless-OS": "Unknown",
        "X-Stainless-Arch": "unknown",
        "X-Stainless-Runtime": "unknown",
        "X-Stainless-Runtime-Version": "unknown"
      };
    };
    function getBrowserInfo() {
      if (typeof navigator === "undefined" || !navigator) {
        return null;
      }
      const browserPatterns = [
        { key: "edge", pattern: /Edge(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: "ie", pattern: /MSIE(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: "ie", pattern: /Trident(?:.*rv\:(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: "chrome", pattern: /Chrome(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: "firefox", pattern: /Firefox(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
        { key: "safari", pattern: /(?:Version\W+(\d+)\.(\d+)(?:\.(\d+))?)?(?:\W+Mobile\S*)?\W+Safari/ }
      ];
      for (const { key, pattern } of browserPatterns) {
        const match = pattern.exec(navigator.userAgent);
        if (match) {
          const major = match[1] || 0;
          const minor = match[2] || 0;
          const patch = match[3] || 0;
          return { browser: key, version: `${major}.${minor}.${patch}` };
        }
      }
      return null;
    }
    var normalizeArch = (arch) => {
      if (arch === "x32")
        return "x32";
      if (arch === "x86_64" || arch === "x64")
        return "x64";
      if (arch === "arm")
        return "arm";
      if (arch === "aarch64" || arch === "arm64")
        return "arm64";
      if (arch)
        return `other:${arch}`;
      return "unknown";
    };
    var normalizePlatform = (platform) => {
      platform = platform.toLowerCase();
      if (platform.includes("ios"))
        return "iOS";
      if (platform === "android")
        return "Android";
      if (platform === "darwin")
        return "MacOS";
      if (platform === "win32")
        return "Windows";
      if (platform === "freebsd")
        return "FreeBSD";
      if (platform === "openbsd")
        return "OpenBSD";
      if (platform === "linux")
        return "Linux";
      if (platform)
        return `Other:${platform}`;
      return "Unknown";
    };
    var _platformHeaders;
    var getPlatformHeaders = () => {
      return _platformHeaders ?? (_platformHeaders = getPlatformProperties());
    };
    exports2.getPlatformHeaders = getPlatformHeaders;
  }
});

// node_modules/@anthropic-ai/sdk/internal/shims.js
var require_shims = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/shims.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.getDefaultFetch = getDefaultFetch;
    exports2.makeReadableStream = makeReadableStream;
    exports2.ReadableStreamFrom = ReadableStreamFrom;
    exports2.ReadableStreamToAsyncIterable = ReadableStreamToAsyncIterable;
    exports2.CancelReadableStream = CancelReadableStream;
    function getDefaultFetch() {
      if (typeof fetch !== "undefined") {
        return fetch;
      }
      throw new Error("`fetch` is not defined as a global; Either pass `fetch` to the client, `new Anthropic({ fetch })` or polyfill the global, `globalThis.fetch = fetch`");
    }
    function makeReadableStream(...args) {
      const ReadableStream = globalThis.ReadableStream;
      if (typeof ReadableStream === "undefined") {
        throw new Error("`ReadableStream` is not defined as a global; You will need to polyfill it, `globalThis.ReadableStream = ReadableStream`");
      }
      return new ReadableStream(...args);
    }
    function ReadableStreamFrom(iterable) {
      let iter = Symbol.asyncIterator in iterable ? iterable[Symbol.asyncIterator]() : iterable[Symbol.iterator]();
      return makeReadableStream({
        start() {
        },
        async pull(controller) {
          const { done, value } = await iter.next();
          if (done) {
            controller.close();
          } else {
            controller.enqueue(value);
          }
        },
        async cancel() {
          await iter.return?.();
        }
      });
    }
    function ReadableStreamToAsyncIterable(stream) {
      if (stream[Symbol.asyncIterator])
        return stream;
      const reader = stream.getReader();
      return {
        async next() {
          try {
            const result = await reader.read();
            if (result?.done)
              reader.releaseLock();
            return result;
          } catch (e) {
            reader.releaseLock();
            throw e;
          }
        },
        async return() {
          const cancelPromise = reader.cancel();
          reader.releaseLock();
          await cancelPromise;
          return { done: true, value: void 0 };
        },
        [Symbol.asyncIterator]() {
          return this;
        }
      };
    }
    async function CancelReadableStream(stream) {
      if (stream === null || typeof stream !== "object")
        return;
      if (stream[Symbol.asyncIterator]) {
        await stream[Symbol.asyncIterator]().return?.();
        return;
      }
      const reader = stream.getReader();
      const cancelPromise = reader.cancel();
      reader.releaseLock();
      await cancelPromise;
    }
  }
});

// node_modules/@anthropic-ai/sdk/internal/request-options.js
var require_request_options = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/request-options.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.FallbackEncoder = void 0;
    var FallbackEncoder = ({ headers, body }) => {
      return {
        bodyHeaders: {
          "content-type": "application/json"
        },
        body: JSON.stringify(body)
      };
    };
    exports2.FallbackEncoder = FallbackEncoder;
  }
});

// node_modules/@anthropic-ai/sdk/internal/qs/formats.js
var require_formats = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/qs/formats.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.RFC3986 = exports2.RFC1738 = exports2.formatters = exports2.default_formatter = exports2.default_format = void 0;
    exports2.default_format = "RFC3986";
    var default_formatter = (v) => String(v);
    exports2.default_formatter = default_formatter;
    exports2.formatters = {
      RFC1738: (v) => String(v).replace(/%20/g, "+"),
      RFC3986: exports2.default_formatter
    };
    exports2.RFC1738 = "RFC1738";
    exports2.RFC3986 = "RFC3986";
  }
});

// node_modules/@anthropic-ai/sdk/internal/qs/utils.js
var require_utils = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/qs/utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.encode = exports2.has = void 0;
    exports2.merge = merge;
    exports2.assign_single_source = assign_single_source;
    exports2.decode = decode;
    exports2.compact = compact;
    exports2.is_regexp = is_regexp;
    exports2.is_buffer = is_buffer;
    exports2.combine = combine;
    exports2.maybe_map = maybe_map;
    var formats_1 = require_formats();
    var values_1 = require_values();
    var has = (obj, key) => (exports2.has = Object.hasOwn ?? Function.prototype.call.bind(Object.prototype.hasOwnProperty), (0, exports2.has)(obj, key));
    exports2.has = has;
    var hex_table = /* @__PURE__ */ (() => {
      const array = [];
      for (let i = 0; i < 256; ++i) {
        array.push("%" + ((i < 16 ? "0" : "") + i.toString(16)).toUpperCase());
      }
      return array;
    })();
    function compact_queue(queue) {
      while (queue.length > 1) {
        const item = queue.pop();
        if (!item)
          continue;
        const obj = item.obj[item.prop];
        if ((0, values_1.isArray)(obj)) {
          const compacted = [];
          for (let j = 0; j < obj.length; ++j) {
            if (typeof obj[j] !== "undefined") {
              compacted.push(obj[j]);
            }
          }
          item.obj[item.prop] = compacted;
        }
      }
    }
    function array_to_object(source, options) {
      const obj = options && options.plainObjects ? /* @__PURE__ */ Object.create(null) : {};
      for (let i = 0; i < source.length; ++i) {
        if (typeof source[i] !== "undefined") {
          obj[i] = source[i];
        }
      }
      return obj;
    }
    function merge(target, source, options = {}) {
      if (!source) {
        return target;
      }
      if (typeof source !== "object") {
        if ((0, values_1.isArray)(target)) {
          target.push(source);
        } else if (target && typeof target === "object") {
          if (options && (options.plainObjects || options.allowPrototypes) || !(0, exports2.has)(Object.prototype, source)) {
            target[source] = true;
          }
        } else {
          return [target, source];
        }
        return target;
      }
      if (!target || typeof target !== "object") {
        return [target].concat(source);
      }
      let mergeTarget = target;
      if ((0, values_1.isArray)(target) && !(0, values_1.isArray)(source)) {
        mergeTarget = array_to_object(target, options);
      }
      if ((0, values_1.isArray)(target) && (0, values_1.isArray)(source)) {
        source.forEach(function(item, i) {
          if ((0, exports2.has)(target, i)) {
            const targetItem = target[i];
            if (targetItem && typeof targetItem === "object" && item && typeof item === "object") {
              target[i] = merge(targetItem, item, options);
            } else {
              target.push(item);
            }
          } else {
            target[i] = item;
          }
        });
        return target;
      }
      return Object.keys(source).reduce(function(acc, key) {
        const value = source[key];
        if ((0, exports2.has)(acc, key)) {
          acc[key] = merge(acc[key], value, options);
        } else {
          acc[key] = value;
        }
        return acc;
      }, mergeTarget);
    }
    function assign_single_source(target, source) {
      return Object.keys(source).reduce(function(acc, key) {
        acc[key] = source[key];
        return acc;
      }, target);
    }
    function decode(str, _, charset) {
      const strWithoutPlus = str.replace(/\+/g, " ");
      if (charset === "iso-8859-1") {
        return strWithoutPlus.replace(/%[0-9a-f]{2}/gi, unescape);
      }
      try {
        return decodeURIComponent(strWithoutPlus);
      } catch (e) {
        return strWithoutPlus;
      }
    }
    var limit = 1024;
    var encode = (str, _defaultEncoder, charset, _kind, format) => {
      if (str.length === 0) {
        return str;
      }
      let string = str;
      if (typeof str === "symbol") {
        string = Symbol.prototype.toString.call(str);
      } else if (typeof str !== "string") {
        string = String(str);
      }
      if (charset === "iso-8859-1") {
        return escape(string).replace(/%u[0-9a-f]{4}/gi, function($0) {
          return "%26%23" + parseInt($0.slice(2), 16) + "%3B";
        });
      }
      let out = "";
      for (let j = 0; j < string.length; j += limit) {
        const segment = string.length >= limit ? string.slice(j, j + limit) : string;
        const arr = [];
        for (let i = 0; i < segment.length; ++i) {
          let c = segment.charCodeAt(i);
          if (c === 45 || // -
          c === 46 || // .
          c === 95 || // _
          c === 126 || // ~
          c >= 48 && c <= 57 || // 0-9
          c >= 65 && c <= 90 || // a-z
          c >= 97 && c <= 122 || // A-Z
          format === formats_1.RFC1738 && (c === 40 || c === 41)) {
            arr[arr.length] = segment.charAt(i);
            continue;
          }
          if (c < 128) {
            arr[arr.length] = hex_table[c];
            continue;
          }
          if (c < 2048) {
            arr[arr.length] = hex_table[192 | c >> 6] + hex_table[128 | c & 63];
            continue;
          }
          if (c < 55296 || c >= 57344) {
            arr[arr.length] = hex_table[224 | c >> 12] + hex_table[128 | c >> 6 & 63] + hex_table[128 | c & 63];
            continue;
          }
          i += 1;
          c = 65536 + ((c & 1023) << 10 | segment.charCodeAt(i) & 1023);
          arr[arr.length] = hex_table[240 | c >> 18] + hex_table[128 | c >> 12 & 63] + hex_table[128 | c >> 6 & 63] + hex_table[128 | c & 63];
        }
        out += arr.join("");
      }
      return out;
    };
    exports2.encode = encode;
    function compact(value) {
      const queue = [{ obj: { o: value }, prop: "o" }];
      const refs = [];
      for (let i = 0; i < queue.length; ++i) {
        const item = queue[i];
        const obj = item.obj[item.prop];
        const keys = Object.keys(obj);
        for (let j = 0; j < keys.length; ++j) {
          const key = keys[j];
          const val = obj[key];
          if (typeof val === "object" && val !== null && refs.indexOf(val) === -1) {
            queue.push({ obj, prop: key });
            refs.push(val);
          }
        }
      }
      compact_queue(queue);
      return value;
    }
    function is_regexp(obj) {
      return Object.prototype.toString.call(obj) === "[object RegExp]";
    }
    function is_buffer(obj) {
      if (!obj || typeof obj !== "object") {
        return false;
      }
      return !!(obj.constructor && obj.constructor.isBuffer && obj.constructor.isBuffer(obj));
    }
    function combine(a, b) {
      return [].concat(a, b);
    }
    function maybe_map(val, fn) {
      if ((0, values_1.isArray)(val)) {
        const mapped = [];
        for (let i = 0; i < val.length; i += 1) {
          mapped.push(fn(val[i]));
        }
        return mapped;
      }
      return fn(val);
    }
  }
});

// node_modules/@anthropic-ai/sdk/internal/qs/stringify.js
var require_stringify = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/qs/stringify.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.stringify = stringify;
    var utils_1 = require_utils();
    var formats_1 = require_formats();
    var values_1 = require_values();
    var array_prefix_generators = {
      brackets(prefix) {
        return String(prefix) + "[]";
      },
      comma: "comma",
      indices(prefix, key) {
        return String(prefix) + "[" + key + "]";
      },
      repeat(prefix) {
        return String(prefix);
      }
    };
    var push_to_array = function(arr, value_or_array) {
      Array.prototype.push.apply(arr, (0, values_1.isArray)(value_or_array) ? value_or_array : [value_or_array]);
    };
    var toISOString;
    var defaults = {
      addQueryPrefix: false,
      allowDots: false,
      allowEmptyArrays: false,
      arrayFormat: "indices",
      charset: "utf-8",
      charsetSentinel: false,
      delimiter: "&",
      encode: true,
      encodeDotInKeys: false,
      encoder: utils_1.encode,
      encodeValuesOnly: false,
      format: formats_1.default_format,
      formatter: formats_1.default_formatter,
      /** @deprecated */
      indices: false,
      serializeDate(date) {
        return (toISOString ?? (toISOString = Function.prototype.call.bind(Date.prototype.toISOString)))(date);
      },
      skipNulls: false,
      strictNullHandling: false
    };
    function is_non_nullish_primitive(v) {
      return typeof v === "string" || typeof v === "number" || typeof v === "boolean" || typeof v === "symbol" || typeof v === "bigint";
    }
    var sentinel = {};
    function inner_stringify(object, prefix, generateArrayPrefix, commaRoundTrip, allowEmptyArrays, strictNullHandling, skipNulls, encodeDotInKeys, encoder, filter, sort, allowDots, serializeDate, format, formatter, encodeValuesOnly, charset, sideChannel) {
      let obj = object;
      let tmp_sc = sideChannel;
      let step = 0;
      let find_flag = false;
      while ((tmp_sc = tmp_sc.get(sentinel)) !== void 0 && !find_flag) {
        const pos = tmp_sc.get(object);
        step += 1;
        if (typeof pos !== "undefined") {
          if (pos === step) {
            throw new RangeError("Cyclic object value");
          } else {
            find_flag = true;
          }
        }
        if (typeof tmp_sc.get(sentinel) === "undefined") {
          step = 0;
        }
      }
      if (typeof filter === "function") {
        obj = filter(prefix, obj);
      } else if (obj instanceof Date) {
        obj = serializeDate?.(obj);
      } else if (generateArrayPrefix === "comma" && (0, values_1.isArray)(obj)) {
        obj = (0, utils_1.maybe_map)(obj, function(value) {
          if (value instanceof Date) {
            return serializeDate?.(value);
          }
          return value;
        });
      }
      if (obj === null) {
        if (strictNullHandling) {
          return encoder && !encodeValuesOnly ? (
            // @ts-expect-error
            encoder(prefix, defaults.encoder, charset, "key", format)
          ) : prefix;
        }
        obj = "";
      }
      if (is_non_nullish_primitive(obj) || (0, utils_1.is_buffer)(obj)) {
        if (encoder) {
          const key_value = encodeValuesOnly ? prefix : encoder(prefix, defaults.encoder, charset, "key", format);
          return [
            formatter?.(key_value) + "=" + // @ts-expect-error
            formatter?.(encoder(obj, defaults.encoder, charset, "value", format))
          ];
        }
        return [formatter?.(prefix) + "=" + formatter?.(String(obj))];
      }
      const values = [];
      if (typeof obj === "undefined") {
        return values;
      }
      let obj_keys;
      if (generateArrayPrefix === "comma" && (0, values_1.isArray)(obj)) {
        if (encodeValuesOnly && encoder) {
          obj = (0, utils_1.maybe_map)(obj, encoder);
        }
        obj_keys = [{ value: obj.length > 0 ? obj.join(",") || null : void 0 }];
      } else if ((0, values_1.isArray)(filter)) {
        obj_keys = filter;
      } else {
        const keys = Object.keys(obj);
        obj_keys = sort ? keys.sort(sort) : keys;
      }
      const encoded_prefix = encodeDotInKeys ? String(prefix).replace(/\./g, "%2E") : String(prefix);
      const adjusted_prefix = commaRoundTrip && (0, values_1.isArray)(obj) && obj.length === 1 ? encoded_prefix + "[]" : encoded_prefix;
      if (allowEmptyArrays && (0, values_1.isArray)(obj) && obj.length === 0) {
        return adjusted_prefix + "[]";
      }
      for (let j = 0; j < obj_keys.length; ++j) {
        const key = obj_keys[j];
        const value = (
          // @ts-ignore
          typeof key === "object" && typeof key.value !== "undefined" ? key.value : obj[key]
        );
        if (skipNulls && value === null) {
          continue;
        }
        const encoded_key = allowDots && encodeDotInKeys ? key.replace(/\./g, "%2E") : key;
        const key_prefix = (0, values_1.isArray)(obj) ? typeof generateArrayPrefix === "function" ? generateArrayPrefix(adjusted_prefix, encoded_key) : adjusted_prefix : adjusted_prefix + (allowDots ? "." + encoded_key : "[" + encoded_key + "]");
        sideChannel.set(object, step);
        const valueSideChannel = /* @__PURE__ */ new WeakMap();
        valueSideChannel.set(sentinel, sideChannel);
        push_to_array(values, inner_stringify(
          value,
          key_prefix,
          generateArrayPrefix,
          commaRoundTrip,
          allowEmptyArrays,
          strictNullHandling,
          skipNulls,
          encodeDotInKeys,
          // @ts-ignore
          generateArrayPrefix === "comma" && encodeValuesOnly && (0, values_1.isArray)(obj) ? null : encoder,
          filter,
          sort,
          allowDots,
          serializeDate,
          format,
          formatter,
          encodeValuesOnly,
          charset,
          valueSideChannel
        ));
      }
      return values;
    }
    function normalize_stringify_options(opts = defaults) {
      if (typeof opts.allowEmptyArrays !== "undefined" && typeof opts.allowEmptyArrays !== "boolean") {
        throw new TypeError("`allowEmptyArrays` option can only be `true` or `false`, when provided");
      }
      if (typeof opts.encodeDotInKeys !== "undefined" && typeof opts.encodeDotInKeys !== "boolean") {
        throw new TypeError("`encodeDotInKeys` option can only be `true` or `false`, when provided");
      }
      if (opts.encoder !== null && typeof opts.encoder !== "undefined" && typeof opts.encoder !== "function") {
        throw new TypeError("Encoder has to be a function.");
      }
      const charset = opts.charset || defaults.charset;
      if (typeof opts.charset !== "undefined" && opts.charset !== "utf-8" && opts.charset !== "iso-8859-1") {
        throw new TypeError("The charset option must be either utf-8, iso-8859-1, or undefined");
      }
      let format = formats_1.default_format;
      if (typeof opts.format !== "undefined") {
        if (!(0, utils_1.has)(formats_1.formatters, opts.format)) {
          throw new TypeError("Unknown format option provided.");
        }
        format = opts.format;
      }
      const formatter = formats_1.formatters[format];
      let filter = defaults.filter;
      if (typeof opts.filter === "function" || (0, values_1.isArray)(opts.filter)) {
        filter = opts.filter;
      }
      let arrayFormat;
      if (opts.arrayFormat && opts.arrayFormat in array_prefix_generators) {
        arrayFormat = opts.arrayFormat;
      } else if ("indices" in opts) {
        arrayFormat = opts.indices ? "indices" : "repeat";
      } else {
        arrayFormat = defaults.arrayFormat;
      }
      if ("commaRoundTrip" in opts && typeof opts.commaRoundTrip !== "boolean") {
        throw new TypeError("`commaRoundTrip` must be a boolean, or absent");
      }
      const allowDots = typeof opts.allowDots === "undefined" ? !!opts.encodeDotInKeys === true ? true : defaults.allowDots : !!opts.allowDots;
      return {
        addQueryPrefix: typeof opts.addQueryPrefix === "boolean" ? opts.addQueryPrefix : defaults.addQueryPrefix,
        // @ts-ignore
        allowDots,
        allowEmptyArrays: typeof opts.allowEmptyArrays === "boolean" ? !!opts.allowEmptyArrays : defaults.allowEmptyArrays,
        arrayFormat,
        charset,
        charsetSentinel: typeof opts.charsetSentinel === "boolean" ? opts.charsetSentinel : defaults.charsetSentinel,
        commaRoundTrip: !!opts.commaRoundTrip,
        delimiter: typeof opts.delimiter === "undefined" ? defaults.delimiter : opts.delimiter,
        encode: typeof opts.encode === "boolean" ? opts.encode : defaults.encode,
        encodeDotInKeys: typeof opts.encodeDotInKeys === "boolean" ? opts.encodeDotInKeys : defaults.encodeDotInKeys,
        encoder: typeof opts.encoder === "function" ? opts.encoder : defaults.encoder,
        encodeValuesOnly: typeof opts.encodeValuesOnly === "boolean" ? opts.encodeValuesOnly : defaults.encodeValuesOnly,
        filter,
        format,
        formatter,
        serializeDate: typeof opts.serializeDate === "function" ? opts.serializeDate : defaults.serializeDate,
        skipNulls: typeof opts.skipNulls === "boolean" ? opts.skipNulls : defaults.skipNulls,
        // @ts-ignore
        sort: typeof opts.sort === "function" ? opts.sort : null,
        strictNullHandling: typeof opts.strictNullHandling === "boolean" ? opts.strictNullHandling : defaults.strictNullHandling
      };
    }
    function stringify(object, opts = {}) {
      let obj = object;
      const options = normalize_stringify_options(opts);
      let obj_keys;
      let filter;
      if (typeof options.filter === "function") {
        filter = options.filter;
        obj = filter("", obj);
      } else if ((0, values_1.isArray)(options.filter)) {
        filter = options.filter;
        obj_keys = filter;
      }
      const keys = [];
      if (typeof obj !== "object" || obj === null) {
        return "";
      }
      const generateArrayPrefix = array_prefix_generators[options.arrayFormat];
      const commaRoundTrip = generateArrayPrefix === "comma" && options.commaRoundTrip;
      if (!obj_keys) {
        obj_keys = Object.keys(obj);
      }
      if (options.sort) {
        obj_keys.sort(options.sort);
      }
      const sideChannel = /* @__PURE__ */ new WeakMap();
      for (let i = 0; i < obj_keys.length; ++i) {
        const key = obj_keys[i];
        if (options.skipNulls && obj[key] === null) {
          continue;
        }
        push_to_array(keys, inner_stringify(
          obj[key],
          key,
          // @ts-expect-error
          generateArrayPrefix,
          commaRoundTrip,
          options.allowEmptyArrays,
          options.strictNullHandling,
          options.skipNulls,
          options.encodeDotInKeys,
          options.encode ? options.encoder : null,
          options.filter,
          options.sort,
          options.allowDots,
          options.serializeDate,
          options.format,
          options.formatter,
          options.encodeValuesOnly,
          options.charset,
          sideChannel
        ));
      }
      const joined = keys.join(options.delimiter);
      let prefix = options.addQueryPrefix === true ? "?" : "";
      if (options.charsetSentinel) {
        if (options.charset === "iso-8859-1") {
          prefix += "utf8=%26%2310003%3B&";
        } else {
          prefix += "utf8=%E2%9C%93&";
        }
      }
      return joined.length > 0 ? prefix + joined : "";
    }
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/query.js
var require_query = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/query.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.stringifyQuery = stringifyQuery;
    var tslib_1 = require_tslib();
    var qs = tslib_1.__importStar(require_stringify());
    function stringifyQuery(query) {
      return qs.stringify(query, { arrayFormat: "brackets" });
    }
  }
});

// node_modules/@anthropic-ai/sdk/lib/credentials/types.js
var require_types = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/credentials/types.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() {
          return m[k];
        } };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __setModuleDefault = exports2 && exports2.__setModuleDefault || (Object.create ? (function(o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function(o, v) {
      o["default"] = v;
    });
    var __importStar = exports2 && exports2.__importStar || /* @__PURE__ */ (function() {
      var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o2) {
          var ar = [];
          for (var k in o2) if (Object.prototype.hasOwnProperty.call(o2, k)) ar[ar.length] = k;
          return ar;
        };
        return ownKeys(o);
      };
      return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
          for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
      };
    })();
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.WorkloadIdentityError = exports2.ADVISORY_REFRESH_BACKOFF_IN_SECONDS = exports2.MANDATORY_REFRESH_THRESHOLD_IN_SECONDS = exports2.ADVISORY_REFRESH_THRESHOLD_IN_SECONDS = exports2.FEDERATION_BETA_HEADER = exports2.OAUTH_API_BETA_HEADER = exports2.TOKEN_ENDPOINT = exports2.GRANT_TYPE_REFRESH_TOKEN = exports2.GRANT_TYPE_JWT_BEARER = void 0;
    exports2.requireSecureTokenEndpoint = requireSecureTokenEndpoint;
    exports2.parseTokenResponse = parseTokenResponse;
    exports2.redactSensitive = redactSensitive;
    exports2.checkCredentialsFileSafety = checkCredentialsFileSafety;
    exports2.writeCredentialsFileAtomic = writeCredentialsFileAtomic;
    var error_1 = require_error();
    exports2.GRANT_TYPE_JWT_BEARER = "urn:ietf:params:oauth:grant-type:jwt-bearer";
    exports2.GRANT_TYPE_REFRESH_TOKEN = "refresh_token";
    exports2.TOKEN_ENDPOINT = "/v1/oauth/token";
    exports2.OAUTH_API_BETA_HEADER = "oauth-2025-04-20";
    exports2.FEDERATION_BETA_HEADER = "oidc-federation-2026-04-01";
    exports2.ADVISORY_REFRESH_THRESHOLD_IN_SECONDS = 120;
    exports2.MANDATORY_REFRESH_THRESHOLD_IN_SECONDS = 30;
    exports2.ADVISORY_REFRESH_BACKOFF_IN_SECONDS = 5;
    var MAX_TOKEN_RESPONSE_BYTES = 1 << 20;
    function requireSecureTokenEndpoint(baseURL) {
      if (!baseURL)
        return;
      let u;
      try {
        u = new URL(baseURL);
      } catch (err) {
        throw new WorkloadIdentityError(`Invalid token endpoint base URL "${baseURL}": ${err}`);
      }
      if (u.protocol === "https:")
        return;
      const host = u.hostname.toLowerCase().replace(/^\[|\]$/g, "");
      if (u.protocol === "http:" && (host === "localhost" || host === "127.0.0.1" || host === "::1")) {
        return;
      }
      throw new WorkloadIdentityError(`Refusing to send credential over non-https token endpoint "${baseURL}"`);
    }
    async function parseTokenResponse(resp, requestId) {
      const text = await readLimitedText(resp);
      let data;
      try {
        data = JSON.parse(text);
      } catch {
        throw new WorkloadIdentityError(`Token endpoint returned non-JSON response (status ${resp.status})`, resp.status, redactSensitive(text), requestId);
      }
      if (!data.access_token) {
        throw new WorkloadIdentityError(`Token endpoint response missing access_token: ${JSON.stringify(redactSensitive(data))}`, resp.status, redactSensitive(data), requestId);
      }
      if (data.token_type && data.token_type.toLowerCase() !== "bearer") {
        throw new WorkloadIdentityError(`Token endpoint response: unsupported token_type "${data.token_type}" (want Bearer)`, resp.status, redactSensitive(data), requestId);
      }
      return data;
    }
    var MAX_ERROR_BODY_CHARS = 2e3;
    var SAFE_ERROR_KEYS = /* @__PURE__ */ new Set(["error", "error_description", "error_uri"]);
    function redactSensitive(body) {
      if (body == null)
        return body;
      if (typeof body === "string") {
        let parsed;
        try {
          parsed = JSON.parse(body);
        } catch {
          if (body.length <= MAX_ERROR_BODY_CHARS)
            return body;
          return body.slice(0, MAX_ERROR_BODY_CHARS) + `... <${body.length - MAX_ERROR_BODY_CHARS} more chars>`;
        }
        return JSON.stringify(redactSensitive(parsed));
      }
      if (typeof body === "object" && !Array.isArray(body)) {
        const out = {};
        for (const [k, v] of Object.entries(body)) {
          if (SAFE_ERROR_KEYS.has(k))
            out[k] = v;
        }
        return out;
      }
      return null;
    }
    async function checkCredentialsFileSafety(path, onWarn = (m) => console.warn(`anthropic-sdk: ${m}`)) {
      if (typeof process === "undefined" || process.platform === "win32")
        return;
      const fs = await Promise.resolve().then(() => __importStar(require("fs")));
      let resolved = path;
      let st;
      try {
        resolved = await fs.promises.realpath(path);
        st = await fs.promises.stat(resolved);
      } catch {
        return;
      }
      const mode = st.mode & 511;
      if (mode & 18) {
        throw new WorkloadIdentityError(`Credentials file at ${resolved} is group/world-writable (mode 0o${mode.toString(8)}); this allows other local users to plant tokens. Run \`chmod 600 ${resolved}\`.`);
      }
      if (mode & 36) {
        throw new WorkloadIdentityError(`Credentials file at ${resolved} is group/world-readable (mode 0o${mode.toString(8)}); run \`chmod 600 ${resolved}\` before retrying.`);
      }
      if (typeof process.getuid === "function" && st.uid !== process.getuid()) {
        onWarn(`credentials file at ${resolved} is owned by uid ${st.uid} (current process uid ${process.getuid()}); verify this is intentional.`);
      }
    }
    async function writeCredentialsFileAtomic(targetPath, data) {
      const fs = await Promise.resolve().then(() => __importStar(require("fs")));
      const path = await Promise.resolve().then(() => __importStar(require("path")));
      const dir = path.dirname(targetPath);
      await fs.promises.mkdir(dir, { recursive: true, mode: 448 });
      const tmpPath = `${targetPath}.${process.pid}.${Math.random().toString(36).slice(2)}.tmp`;
      try {
        const fh = await fs.promises.open(tmpPath, "w", 384);
        try {
          await fh.writeFile(JSON.stringify(data, null, 2));
          await fh.sync();
        } finally {
          await fh.close();
        }
        await fs.promises.rename(tmpPath, targetPath);
      } catch (err) {
        await fs.promises.unlink(tmpPath).catch(() => {
        });
        throw err;
      }
      try {
        const dirFh = await fs.promises.open(dir, "r");
        try {
          await dirFh.sync();
        } finally {
          await dirFh.close();
        }
      } catch {
      }
    }
    async function readLimitedText(resp) {
      if (!resp.body) {
        return "";
      }
      const reader = resp.body.getReader();
      const chunks = [];
      let received = 0;
      for (; ; ) {
        const { done, value } = await reader.read();
        if (done)
          break;
        if (received + value.length > MAX_TOKEN_RESPONSE_BYTES) {
          const remaining = MAX_TOKEN_RESPONSE_BYTES - received;
          if (remaining > 0)
            chunks.push(value.subarray(0, remaining));
          await reader.cancel();
          break;
        }
        chunks.push(value);
        received += value.length;
      }
      let merged;
      if (chunks.length === 1) {
        merged = chunks[0];
      } else {
        merged = new Uint8Array(chunks.reduce((n, c) => n + c.length, 0));
        let offset = 0;
        for (const c of chunks) {
          merged.set(c, offset);
          offset += c.length;
        }
      }
      return new TextDecoder("utf-8").decode(merged);
    }
    var WorkloadIdentityError = class extends error_1.AnthropicError {
      constructor(message, statusCode = null, body = null, requestId = null) {
        super(message);
        this.statusCode = statusCode;
        this.body = body;
        this.requestId = requestId;
      }
    };
    exports2.WorkloadIdentityError = WorkloadIdentityError;
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/time.js
var require_time = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/time.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.nowAsSeconds = nowAsSeconds;
    function nowAsSeconds() {
      return Math.floor(Date.now() / 1e3);
    }
  }
});

// node_modules/@anthropic-ai/sdk/lib/credentials/token-cache.js
var require_token_cache = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/credentials/token-cache.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.TokenCache = void 0;
    var types_1 = require_types();
    var time_1 = require_time();
    var TokenCache = class {
      constructor(provider, onAdvisoryRefreshError) {
        this.cached = null;
        this.pendingRefresh = null;
        this.nextForce = false;
        this.lastAdvisoryError = 0;
        this.provider = provider;
        this.onAdvisoryRefreshError = onAdvisoryRefreshError;
      }
      async getToken() {
        const force = this.nextForce;
        this.nextForce = false;
        const cached = this.cached;
        if (force || cached == null) {
          const token2 = await this.refresh(force);
          return token2.token;
        }
        if (cached.expiresAt == null) {
          return cached.token;
        }
        const remaining = cached.expiresAt - (0, time_1.nowAsSeconds)();
        if (remaining > types_1.ADVISORY_REFRESH_THRESHOLD_IN_SECONDS) {
          return cached.token;
        }
        if (remaining > types_1.MANDATORY_REFRESH_THRESHOLD_IN_SECONDS) {
          this.backgroundRefresh();
          return cached.token;
        }
        const token = await this.refresh();
        return token.token;
      }
      /**
       * Clears the cached token and marks the next {@link getToken} as a forced
       * refresh, so the underlying provider bypasses any on-disk freshness check.
       * Called after a 401 — the server has just told us the token is bad even
       * if its `expires_at` still looks fresh.
       */
      invalidate() {
        this.cached = null;
        this.nextForce = true;
      }
      /**
       * Mandatory refresh. Joins any in-flight refresh unless forced — a forced
       * refresh must not coalesce into a non-forced one that may re-serve the
       * same stale disk token.
       */
      refresh(force = false) {
        if (this.pendingRefresh && !force) {
          return this.pendingRefresh;
        }
        return this.doRefresh(force);
      }
      /**
       * Advisory background refresh. Shares the same in-flight promise as
       * mandatory refreshes for deduplication, but swallows errors so the
       * stale cached token keeps being served. Backs off for
       * {@link ADVISORY_REFRESH_BACKOFF_IN_SECONDS} after a failure so an
       * outage during the advisory window doesn't hammer the token endpoint.
       */
      backgroundRefresh() {
        if (this.pendingRefresh) {
          return;
        }
        if ((0, time_1.nowAsSeconds)() - this.lastAdvisoryError < types_1.ADVISORY_REFRESH_BACKOFF_IN_SECONDS) {
          return;
        }
        this.doRefresh().catch((err) => {
          this.lastAdvisoryError = (0, time_1.nowAsSeconds)();
          this.onAdvisoryRefreshError?.(err);
        });
      }
      /**
       * Core refresh. Sets {@link pendingRefresh} so concurrent callers
       * (both advisory and mandatory) coalesce into a single provider call.
       */
      doRefresh(force = false) {
        this.pendingRefresh = this.provider(force ? { forceRefresh: true } : void 0).then((token) => {
          this.cached = token;
          this.pendingRefresh = null;
          return token;
        }, (err) => {
          this.pendingRefresh = null;
          throw err;
        });
        return this.pendingRefresh;
      }
    };
    exports2.TokenCache = TokenCache;
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/env.js
var require_env = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/env.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.readEnv = void 0;
    var readEnv = (env) => {
      if (typeof globalThis.process !== "undefined") {
        return globalThis.process.env?.[env]?.trim() || void 0;
      }
      if (typeof globalThis.Deno !== "undefined") {
        return globalThis.Deno.env?.get?.(env)?.trim() || void 0;
      }
      return void 0;
    };
    exports2.readEnv = readEnv;
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/bytes.js
var require_bytes = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/bytes.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.concatBytes = concatBytes;
    exports2.encodeUTF8 = encodeUTF8;
    exports2.decodeUTF8 = decodeUTF8;
    function concatBytes(buffers) {
      let length = 0;
      for (const buffer of buffers) {
        length += buffer.length;
      }
      const output = new Uint8Array(length);
      let index = 0;
      for (const buffer of buffers) {
        output.set(buffer, index);
        index += buffer.length;
      }
      return output;
    }
    var encodeUTF8_;
    function encodeUTF8(str) {
      let encoder;
      return (encodeUTF8_ ?? (encoder = new globalThis.TextEncoder(), encodeUTF8_ = encoder.encode.bind(encoder)))(str);
    }
    var decodeUTF8_;
    function decodeUTF8(bytes) {
      let decoder;
      return (decodeUTF8_ ?? (decoder = new globalThis.TextDecoder(), decodeUTF8_ = decoder.decode.bind(decoder)))(bytes);
    }
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/base64.js
var require_base64 = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/base64.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.fromBase64 = exports2.toBase64 = void 0;
    var error_1 = require_error();
    var bytes_1 = require_bytes();
    var toBase64 = (data) => {
      if (!data)
        return "";
      if (typeof globalThis.Buffer !== "undefined") {
        return globalThis.Buffer.from(data).toString("base64");
      }
      if (typeof data === "string") {
        data = (0, bytes_1.encodeUTF8)(data);
      }
      if (typeof btoa !== "undefined") {
        return btoa(String.fromCharCode.apply(null, data));
      }
      throw new error_1.AnthropicError("Cannot generate base64 string; Expected `Buffer` or `btoa` to be defined");
    };
    exports2.toBase64 = toBase64;
    var fromBase64 = (str) => {
      if (typeof globalThis.Buffer !== "undefined") {
        const buf = globalThis.Buffer.from(str, "base64");
        return new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength);
      }
      if (typeof atob !== "undefined") {
        const bstr = atob(str);
        const buf = new Uint8Array(bstr.length);
        for (let i = 0; i < bstr.length; i++) {
          buf[i] = bstr.charCodeAt(i);
        }
        return buf;
      }
      throw new error_1.AnthropicError("Cannot decode base64 string; Expected `Buffer` or `atob` to be defined");
    };
    exports2.fromBase64 = fromBase64;
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/log.js
var require_log = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/log.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.formatRequestDetails = exports2.parseLogLevel = void 0;
    exports2.loggerFor = loggerFor;
    var values_1 = require_values();
    var levelNumbers = {
      off: 0,
      error: 200,
      warn: 300,
      info: 400,
      debug: 500
    };
    var parseLogLevel = (maybeLevel, sourceName, client) => {
      if (!maybeLevel) {
        return void 0;
      }
      if ((0, values_1.hasOwn)(levelNumbers, maybeLevel)) {
        return maybeLevel;
      }
      loggerFor(client).warn(`${sourceName} was set to ${JSON.stringify(maybeLevel)}, expected one of ${JSON.stringify(Object.keys(levelNumbers))}`);
      return void 0;
    };
    exports2.parseLogLevel = parseLogLevel;
    function noop() {
    }
    function makeLogFn(fnLevel, logger, logLevel) {
      if (!logger || levelNumbers[fnLevel] > levelNumbers[logLevel]) {
        return noop;
      } else {
        return logger[fnLevel].bind(logger);
      }
    }
    var noopLogger = {
      error: noop,
      warn: noop,
      info: noop,
      debug: noop
    };
    var cachedLoggers = /* @__PURE__ */ new WeakMap();
    function loggerFor(client) {
      const logger = client.logger;
      const logLevel = client.logLevel ?? "off";
      if (!logger) {
        return noopLogger;
      }
      const cachedLogger = cachedLoggers.get(logger);
      if (cachedLogger && cachedLogger[0] === logLevel) {
        return cachedLogger[1];
      }
      const levelLogger = {
        error: makeLogFn("error", logger, logLevel),
        warn: makeLogFn("warn", logger, logLevel),
        info: makeLogFn("info", logger, logLevel),
        debug: makeLogFn("debug", logger, logLevel)
      };
      cachedLoggers.set(logger, [logLevel, levelLogger]);
      return levelLogger;
    }
    var formatRequestDetails = (details) => {
      if (details.options) {
        details.options = { ...details.options };
        delete details.options["headers"];
      }
      if (details.headers) {
        details.headers = Object.fromEntries((details.headers instanceof Headers ? [...details.headers] : Object.entries(details.headers)).map(([name, value]) => [
          name,
          name.toLowerCase() === "authorization" || name.toLowerCase() === "api-key" || name.toLowerCase() === "x-api-key" || name.toLowerCase() === "cookie" || name.toLowerCase() === "set-cookie" ? "***" : value
        ]));
      }
      if ("retryOfRequestLogID" in details) {
        if (details.retryOfRequestLogID) {
          details.retryOf = details.retryOfRequestLogID;
        }
        delete details.retryOfRequestLogID;
      }
      return details;
    };
    exports2.formatRequestDetails = formatRequestDetails;
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils.js
var require_utils2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    tslib_1.__exportStar(require_values(), exports2);
    tslib_1.__exportStar(require_base64(), exports2);
    tslib_1.__exportStar(require_env(), exports2);
    tslib_1.__exportStar(require_log(), exports2);
    tslib_1.__exportStar(require_uuid(), exports2);
    tslib_1.__exportStar(require_sleep(), exports2);
    tslib_1.__exportStar(require_query(), exports2);
  }
});

// node_modules/@anthropic-ai/sdk/core/credentials.js
var require_credentials = __commonJS({
  "node_modules/@anthropic-ai/sdk/core/credentials.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() {
          return m[k];
        } };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __setModuleDefault = exports2 && exports2.__setModuleDefault || (Object.create ? (function(o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function(o, v) {
      o["default"] = v;
    });
    var __importStar = exports2 && exports2.__importStar || /* @__PURE__ */ (function() {
      var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o2) {
          var ar = [];
          for (var k in o2) if (Object.prototype.hasOwnProperty.call(o2, k)) ar[ar.length] = k;
          return ar;
        };
        return ownKeys(o);
      };
      return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
          for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
      };
    })();
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.getCredentialsPath = exports2.loadCredentials = exports2.loadConfigWithSource = exports2.loadConfig = exports2.CREDENTIALS_FILE_VERSION = exports2.CONFIG_FILE_VERSION = void 0;
    var detect_platform_1 = require_detect_platform();
    var utils_1 = require_utils2();
    exports2.CONFIG_FILE_VERSION = "1.0";
    exports2.CREDENTIALS_FILE_VERSION = "1.0";
    var PROFILE_NAME_PATTERN = /^[A-Za-z0-9_.-]+$/;
    function validateProfileName(name) {
      if (!name) {
        throw new Error("profile name is empty");
      }
      if (name === "." || name === "..") {
        throw new Error(`profile name "${name}" is not allowed`);
      }
      if (name.includes("/") || name.includes("\\")) {
        throw new Error(`profile name "${name}" must not contain path separators`);
      }
      if (!PROFILE_NAME_PATTERN.test(name)) {
        throw new Error(`profile name "${name}" contains disallowed characters (allowed: letters, digits, '_', '.', '-')`);
      }
    }
    var loadConfig = async (profile) => {
      return (await (0, exports2.loadConfigWithSource)(profile))?.config ?? null;
    };
    exports2.loadConfig = loadConfig;
    var loadConfigWithSource = async (profile) => {
      var _a, _b;
      const rootConfigPath = await getRootConfigPath();
      if (rootConfigPath === null) {
        return null;
      }
      const profileName = profile ?? await getActiveProfileName();
      if (profileName === null) {
        return null;
      }
      validateProfileName(profileName);
      const fs = await Promise.resolve().then(() => __importStar(require("fs")));
      const path = await Promise.resolve().then(() => __importStar(require("path")));
      const configPath = path.join(rootConfigPath, "configs", `${profileName}.json`);
      let configRaw;
      try {
        configRaw = await fs.promises.readFile(configPath, "utf-8");
      } catch (err) {
        if (err?.code !== "ENOENT") {
          throw new Error(`failed to read config file ${configPath}: ${err}`);
        }
        configRaw = null;
      }
      if (configRaw === null) {
        const organizationId = (0, utils_1.readEnv)("ANTHROPIC_ORGANIZATION_ID");
        const identityTokenFile = (0, utils_1.readEnv)("ANTHROPIC_IDENTITY_TOKEN_FILE");
        const federationRuleId = (0, utils_1.readEnv)("ANTHROPIC_FEDERATION_RULE_ID");
        if (federationRuleId && organizationId) {
          return {
            fromFile: false,
            config: {
              organization_id: organizationId,
              // A defaulted-but-empty CI variable (`ANTHROPIC_WORKSPACE_ID=""`) is
              // treated as unset — readEnv coerces empty to undefined, and the body
              // builder's truthy check skips it — so `"workspace_id": ""` never goes
              // on the wire.
              workspace_id: (0, utils_1.readEnv)("ANTHROPIC_WORKSPACE_ID"),
              base_url: (0, utils_1.readEnv)("ANTHROPIC_BASE_URL"),
              authentication: {
                type: "oidc_federation",
                federation_rule_id: federationRuleId,
                service_account_id: (0, utils_1.readEnv)("ANTHROPIC_SERVICE_ACCOUNT_ID"),
                identity_token: identityTokenFile ? { source: "file", path: identityTokenFile } : void 0,
                scope: (0, utils_1.readEnv)("ANTHROPIC_SCOPE")
              }
            }
          };
        }
        return null;
      }
      let config;
      try {
        config = JSON.parse(configRaw);
      } catch (err) {
        throw new Error(`failed to parse config file ${configPath}: ${err}`);
      }
      if (!config.authentication) {
        throw new Error(`config file ${configPath} is missing "authentication"`);
      }
      const authType = config.authentication.type;
      if (authType !== "oidc_federation" && authType !== "user_oauth") {
        throw new Error(`authentication.type "${authType}" is not a known authentication type`);
      }
      config.organization_id ?? (config.organization_id = (0, utils_1.readEnv)("ANTHROPIC_ORGANIZATION_ID"));
      config.workspace_id ?? (config.workspace_id = (0, utils_1.readEnv)("ANTHROPIC_WORKSPACE_ID"));
      config.base_url ?? (config.base_url = (0, utils_1.readEnv)("ANTHROPIC_BASE_URL"));
      (_a = config.authentication).scope ?? (_a.scope = (0, utils_1.readEnv)("ANTHROPIC_SCOPE"));
      if (config.authentication.type === "oidc_federation") {
        if (!config.authentication.identity_token) {
          const identityTokenFile = (0, utils_1.readEnv)("ANTHROPIC_IDENTITY_TOKEN_FILE");
          if (identityTokenFile) {
            config.authentication.identity_token = {
              source: "file",
              path: identityTokenFile
            };
          }
        }
        if (!config.authentication.federation_rule_id) {
          config.authentication.federation_rule_id = (0, utils_1.readEnv)("ANTHROPIC_FEDERATION_RULE_ID") ?? "";
        }
        (_b = config.authentication).service_account_id ?? (_b.service_account_id = (0, utils_1.readEnv)("ANTHROPIC_SERVICE_ACCOUNT_ID"));
      }
      return { config, fromFile: true };
    };
    exports2.loadConfigWithSource = loadConfigWithSource;
    var loadCredentials = async () => {
      const config = await (0, exports2.loadConfig)();
      const credentialsPath = await (0, exports2.getCredentialsPath)(config);
      if (!credentialsPath) {
        return null;
      }
      const fs = await Promise.resolve().then(() => __importStar(require("fs")));
      let raw;
      try {
        raw = await fs.promises.readFile(credentialsPath, "utf-8");
      } catch (err) {
        if (err?.code !== "ENOENT") {
          throw new Error(`failed to read credentials file ${credentialsPath}: ${err}`);
        }
        return null;
      }
      let creds;
      try {
        creds = JSON.parse(raw);
      } catch (err) {
        throw new Error(`failed to parse credentials file ${credentialsPath}: ${err}`);
      }
      if (creds.type && creds.type !== "oauth_token") {
        throw new Error(`credentials file ${credentialsPath} has unsupported type "${creds.type}" (want "oauth_token")`);
      }
      return creds;
    };
    exports2.loadCredentials = loadCredentials;
    var getCredentialsPath = async (config, profile) => {
      if (config?.authentication.credentials_path) {
        return config.authentication.credentials_path;
      }
      const rootConfigPath = await getRootConfigPath();
      if (!rootConfigPath) {
        return null;
      }
      const profileName = profile ?? await getActiveProfileName();
      if (!profileName) {
        return null;
      }
      validateProfileName(profileName);
      const path = await Promise.resolve().then(() => __importStar(require("path")));
      return path.join(rootConfigPath, "credentials", `${profileName}.json`);
    };
    exports2.getCredentialsPath = getCredentialsPath;
    var getRootConfigPath = async () => {
      if (!supportsLocalConfigFiles()) {
        return null;
      }
      const path = await Promise.resolve().then(() => __importStar(require("path")));
      const configDir = (0, utils_1.readEnv)("ANTHROPIC_CONFIG_DIR");
      if (configDir) {
        return configDir;
      }
      const os = (0, detect_platform_1.getPlatformHeaders)()["X-Stainless-OS"];
      if (os === "Windows") {
        const appData = (0, utils_1.readEnv)("APPDATA");
        if (appData) {
          return path.join(appData, "Anthropic");
        }
        const userProfile = (0, utils_1.readEnv)("USERPROFILE");
        if (userProfile) {
          return path.join(userProfile, "AppData", "Roaming", "Anthropic");
        }
        return null;
      }
      const xdgConfigHome = (0, utils_1.readEnv)("XDG_CONFIG_HOME");
      if (xdgConfigHome) {
        return path.join(xdgConfigHome, "anthropic");
      }
      const home = (0, utils_1.readEnv)("HOME");
      if (home) {
        return path.join(home, ".config", "anthropic");
      }
      return null;
    };
    var supportsLocalConfigFiles = () => {
      const runtime = (0, detect_platform_1.getPlatformHeaders)()["X-Stainless-Runtime"];
      return runtime === "node" || runtime === "deno";
    };
    var getActiveProfileName = async () => {
      const rootConfigPath = await getRootConfigPath();
      if (!rootConfigPath) {
        return null;
      }
      const profileName = (0, utils_1.readEnv)("ANTHROPIC_PROFILE");
      if (profileName) {
        return profileName;
      }
      const fs = await Promise.resolve().then(() => __importStar(require("fs")));
      const path = await Promise.resolve().then(() => __importStar(require("path")));
      const filePath = path.join(rootConfigPath, "active_config");
      try {
        return (await fs.promises.readFile(filePath, "utf-8")).trim() || "default";
      } catch (err) {
        if (err?.code !== "ENOENT") {
          throw new Error(`failed to read ${filePath}: ${err}`);
        }
        return "default";
      }
    };
  }
});

// node_modules/@anthropic-ai/sdk/lib/credentials/identity-token.js
var require_identity_token = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/credentials/identity-token.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() {
          return m[k];
        } };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __setModuleDefault = exports2 && exports2.__setModuleDefault || (Object.create ? (function(o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function(o, v) {
      o["default"] = v;
    });
    var __importStar = exports2 && exports2.__importStar || /* @__PURE__ */ (function() {
      var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o2) {
          var ar = [];
          for (var k in o2) if (Object.prototype.hasOwnProperty.call(o2, k)) ar[ar.length] = k;
          return ar;
        };
        return ownKeys(o);
      };
      return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
          for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
      };
    })();
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.identityTokenFromFile = identityTokenFromFile;
    exports2.identityTokenFromValue = identityTokenFromValue;
    var error_1 = require_error();
    function identityTokenFromFile(path) {
      if (!path) {
        throw new error_1.AnthropicError("Identity token file path is empty");
      }
      return async () => {
        const fs = await Promise.resolve().then(() => __importStar(require("fs")));
        let content;
        try {
          content = await fs.promises.readFile(path, "utf-8");
        } catch (err) {
          throw new error_1.AnthropicError(`Failed to read identity token file at ${path}: ${err}`);
        }
        const token = content.trim();
        if (!token) {
          throw new error_1.AnthropicError(`Identity token file at ${path} is empty`);
        }
        return token;
      };
    }
    function identityTokenFromValue(token) {
      if (!token) {
        throw new error_1.AnthropicError("Identity token value is empty");
      }
      return () => token;
    }
  }
});

// node_modules/@anthropic-ai/sdk/lib/credentials/oidc-federation.js
var require_oidc_federation = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/credentials/oidc-federation.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.oidcFederationProvider = oidcFederationProvider;
    var types_1 = require_types();
    var time_1 = require_time();
    var version_1 = require_version();
    function oidcFederationProvider(config) {
      return async () => {
        (0, types_1.requireSecureTokenEndpoint)(config.baseURL);
        const jwt = await config.identityTokenProvider();
        if (jwt.length > 16 * 1024) {
          throw new types_1.WorkloadIdentityError(`Identity token is ${Math.ceil(jwt.length / 1024)} KiB, exceeds the 16 KiB assertion limit`);
        }
        const body = {
          grant_type: types_1.GRANT_TYPE_JWT_BEARER,
          assertion: jwt,
          federation_rule_id: config.federationRuleId,
          organization_id: config.organizationId
        };
        if (config.serviceAccountId) {
          body["service_account_id"] = config.serviceAccountId;
        }
        if (config.workspaceId) {
          body["workspace_id"] = config.workspaceId;
        }
        const url = `${config.baseURL}${types_1.TOKEN_ENDPOINT}`;
        let resp;
        try {
          resp = await config.fetch(url, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "anthropic-beta": `${types_1.OAUTH_API_BETA_HEADER},${types_1.FEDERATION_BETA_HEADER}`,
              "User-Agent": config.userAgent || `anthropic-sdk-typescript/${version_1.VERSION} oidcFederationProvider`
            },
            body: JSON.stringify(body)
          });
        } catch (err) {
          throw new types_1.WorkloadIdentityError(`Failed to reach token endpoint ${url}: ${err}`);
        }
        const requestId = resp.headers.get("Request-Id");
        if (!resp.ok) {
          const text = await resp.text().catch(() => "");
          const redacted = (0, types_1.redactSensitive)(text);
          let hint = "";
          if (resp.status === 401) {
            const hintMiddle = config.workspaceId ? "" : "If your federation rule is scoped to multiple workspaces, set the ANTHROPIC_WORKSPACE_ID environment variable, the 'workspace_id' config key, or the `workspaceId` option. ";
            hint = ` Ensure your federation rule matches your identity token. ${hintMiddle}View your authentication events in the Workload identity page of Claude Console for more details.`;
          }
          throw new types_1.WorkloadIdentityError(`Token exchange failed with status ${resp.status}${requestId ? ` (request-id ${requestId})` : ""}: ${redacted}${hint}`, resp.status, redacted, requestId);
        }
        const data = await (0, types_1.parseTokenResponse)(resp, requestId);
        const expiresIn = Number(data.expires_in);
        if (!Number.isFinite(expiresIn)) {
          throw new types_1.WorkloadIdentityError(`Token endpoint response missing required fields: ${JSON.stringify((0, types_1.redactSensitive)(data))}`, resp.status, (0, types_1.redactSensitive)(data), requestId);
        }
        return {
          token: data.access_token,
          expiresAt: (0, time_1.nowAsSeconds)() + expiresIn
        };
      };
    }
  }
});

// node_modules/@anthropic-ai/sdk/lib/credentials/user-oauth.js
var require_user_oauth = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/credentials/user-oauth.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() {
          return m[k];
        } };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __setModuleDefault = exports2 && exports2.__setModuleDefault || (Object.create ? (function(o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function(o, v) {
      o["default"] = v;
    });
    var __importStar = exports2 && exports2.__importStar || /* @__PURE__ */ (function() {
      var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o2) {
          var ar = [];
          for (var k in o2) if (Object.prototype.hasOwnProperty.call(o2, k)) ar[ar.length] = k;
          return ar;
        };
        return ownKeys(o);
      };
      return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
          for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
      };
    })();
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.userOAuthProvider = userOAuthProvider;
    var credentials_1 = require_credentials();
    var types_1 = require_types();
    var time_1 = require_time();
    var version_1 = require_version();
    function userOAuthProvider(config) {
      return async (opts) => {
        const fs = await Promise.resolve().then(() => __importStar(require("fs")));
        await (0, types_1.checkCredentialsFileSafety)(config.credentialsPath, config.onSafetyWarning);
        let raw;
        try {
          raw = await fs.promises.readFile(config.credentialsPath, "utf-8");
        } catch (err) {
          throw new types_1.WorkloadIdentityError(`Credentials file not found at ${config.credentialsPath}: ${err}`);
        }
        let creds;
        try {
          creds = JSON.parse(raw);
        } catch (err) {
          throw new types_1.WorkloadIdentityError(`Credentials file at ${config.credentialsPath} is not valid JSON: ${err}`);
        }
        const accessToken = creds.access_token;
        if (!accessToken) {
          throw new types_1.WorkloadIdentityError(`Credentials file at ${config.credentialsPath} must include 'access_token'`);
        }
        const expiresAt = creds.expires_at;
        if (!opts?.forceRefresh && (expiresAt == null || (0, time_1.nowAsSeconds)() < expiresAt - types_1.MANDATORY_REFRESH_THRESHOLD_IN_SECONDS)) {
          return { token: accessToken, expiresAt: expiresAt ?? null };
        }
        const refreshToken = creds.refresh_token;
        if (!config.clientId || !refreshToken) {
          throw new types_1.WorkloadIdentityError(`Access token at ${config.credentialsPath} has expired and no refresh is available (client_id ${config.clientId ? "set" : "empty"}, refresh_token ${refreshToken ? "set" : "empty"})`);
        }
        (0, types_1.requireSecureTokenEndpoint)(config.baseURL);
        const body = {
          grant_type: types_1.GRANT_TYPE_REFRESH_TOKEN,
          refresh_token: refreshToken,
          client_id: config.clientId
        };
        const url = `${config.baseURL}${types_1.TOKEN_ENDPOINT}`;
        let resp;
        try {
          resp = await config.fetch(url, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "anthropic-beta": types_1.OAUTH_API_BETA_HEADER,
              "User-Agent": config.userAgent || `anthropic-sdk-typescript/${version_1.VERSION} userOAuthProvider`
            },
            body: JSON.stringify(body)
          });
        } catch (err) {
          throw new types_1.WorkloadIdentityError(`User OAuth refresh failed to reach token endpoint: ${err}`);
        }
        const requestId = resp.headers.get("Request-Id");
        if (!resp.ok) {
          const text = await resp.text().catch(() => "");
          throw new types_1.WorkloadIdentityError(`User OAuth refresh failed (HTTP ${resp.status}): ${(0, types_1.redactSensitive)(text)}`, resp.status, (0, types_1.redactSensitive)(text), requestId);
        }
        const data = await (0, types_1.parseTokenResponse)(resp, requestId);
        const expiresIn = Number(data.expires_in);
        if (!Number.isFinite(expiresIn)) {
          throw new types_1.WorkloadIdentityError(`User OAuth refresh response missing or invalid expires_in: ${JSON.stringify((0, types_1.redactSensitive)(data))}`, resp.status, (0, types_1.redactSensitive)(data), requestId);
        }
        const newExpiresAt = (0, time_1.nowAsSeconds)() + expiresIn;
        const newRefreshToken = data.refresh_token || refreshToken;
        await (0, types_1.writeCredentialsFileAtomic)(config.credentialsPath, {
          ...creds,
          version: credentials_1.CREDENTIALS_FILE_VERSION,
          type: "oauth_token",
          access_token: data.access_token,
          expires_at: newExpiresAt,
          refresh_token: newRefreshToken
        });
        return { token: data.access_token, expiresAt: newExpiresAt };
      };
    }
  }
});

// node_modules/@anthropic-ai/sdk/lib/credentials/credential-chain.js
var require_credential_chain = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/credentials/credential-chain.js"(exports2) {
    "use strict";
    var __createBinding = exports2 && exports2.__createBinding || (Object.create ? (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      var desc = Object.getOwnPropertyDescriptor(m, k);
      if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
        desc = { enumerable: true, get: function() {
          return m[k];
        } };
      }
      Object.defineProperty(o, k2, desc);
    }) : (function(o, m, k, k2) {
      if (k2 === void 0) k2 = k;
      o[k2] = m[k];
    }));
    var __setModuleDefault = exports2 && exports2.__setModuleDefault || (Object.create ? (function(o, v) {
      Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function(o, v) {
      o["default"] = v;
    });
    var __importStar = exports2 && exports2.__importStar || /* @__PURE__ */ (function() {
      var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function(o2) {
          var ar = [];
          for (var k in o2) if (Object.prototype.hasOwnProperty.call(o2, k)) ar[ar.length] = k;
          return ar;
        };
        return ownKeys(o);
      };
      return function(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) {
          for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        }
        __setModuleDefault(result, mod);
        return result;
      };
    })();
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.resolveCredentialsFromConfig = resolveCredentialsFromConfig;
    exports2.defaultCredentials = defaultCredentials;
    var env_1 = require_env();
    var credentials_1 = require_credentials();
    var types_1 = require_types();
    var time_1 = require_time();
    var identity_token_1 = require_identity_token();
    var oidc_federation_1 = require_oidc_federation();
    var user_oauth_1 = require_user_oauth();
    function resolveCredentialsFromConfig(config, options) {
      const credentialsPath = config.authentication.credentials_path ?? null;
      const effectiveBaseURL = (config.base_url || options.baseURL).replace(/\/+$/, "");
      const provider = buildProvider(config, credentialsPath, effectiveBaseURL, options);
      const extraHeaders = {};
      if (config.workspace_id && config.authentication.type === "user_oauth") {
        extraHeaders["anthropic-workspace-id"] = config.workspace_id;
      }
      return { provider, extraHeaders, baseURL: config.base_url || void 0 };
    }
    async function defaultCredentials(options, profile) {
      const loaded = await (0, credentials_1.loadConfigWithSource)(profile);
      if (!loaded) {
        return null;
      }
      const { config, fromFile } = loaded;
      const withPath = config.authentication.credentials_path || !fromFile ? config : {
        ...config,
        authentication: {
          ...config.authentication,
          credentials_path: await (0, credentials_1.getCredentialsPath)(config, profile) ?? void 0
        }
      };
      return resolveCredentialsFromConfig(withPath, options);
    }
    function buildProvider(config, credentialsPath, baseURL, options) {
      switch (config.authentication.type) {
        case "oidc_federation": {
          const auth = config.authentication;
          const identityProvider = resolveIdentityTokenProvider(auth);
          if (!identityProvider) {
            throw new types_1.WorkloadIdentityError("oidc_federation config requires an identity token (set authentication.identity_token, ANTHROPIC_IDENTITY_TOKEN_FILE, or ANTHROPIC_IDENTITY_TOKEN)");
          }
          if (!auth.federation_rule_id) {
            throw new types_1.WorkloadIdentityError("oidc_federation config requires 'federation_rule_id'. Set it in authentication.federation_rule_id in your profile, or via ANTHROPIC_FEDERATION_RULE_ID (profile takes precedence).");
          }
          if (!config.organization_id) {
            throw new types_1.WorkloadIdentityError("oidc_federation config requires organization_id (set ANTHROPIC_ORGANIZATION_ID or config.organization_id)");
          }
          const exchange = (0, oidc_federation_1.oidcFederationProvider)({
            identityTokenProvider: identityProvider,
            federationRuleId: auth.federation_rule_id,
            organizationId: config.organization_id,
            serviceAccountId: auth.service_account_id,
            workspaceId: config.workspace_id,
            baseURL,
            fetch: options.fetch,
            userAgent: options.userAgent
          });
          if (credentialsPath) {
            return cachedExchangeProvider(exchange, credentialsPath, options.onCacheWriteError, options.onSafetyWarning);
          }
          return exchange;
        }
        case "user_oauth": {
          if (!credentialsPath) {
            throw new types_1.WorkloadIdentityError("user_oauth config requires authentication.credentials_path (or load via a profile so it defaults to <config_dir>/credentials/<profile>.json)");
          }
          return (0, user_oauth_1.userOAuthProvider)({
            credentialsPath,
            clientId: config.authentication.client_id,
            baseURL,
            fetch: options.fetch,
            userAgent: options.userAgent,
            onSafetyWarning: options.onSafetyWarning
          });
        }
        default: {
          const t = config.authentication.type;
          throw new types_1.WorkloadIdentityError(`authentication.type "${t}" is not a known authentication type`);
        }
      }
    }
    function resolveIdentityTokenProvider(auth) {
      if (auth.identity_token) {
        const source = auth.identity_token.source;
        if (source !== "file") {
          throw new types_1.WorkloadIdentityError(`identity_token.source "${source}" is not supported by this SDK version (only "file")`);
        }
        if (!auth.identity_token.path) {
          throw new types_1.WorkloadIdentityError(`identity_token.source "file" requires a non-empty path`);
        }
        return (0, identity_token_1.identityTokenFromFile)(auth.identity_token.path);
      }
      const tokenFile = (0, env_1.readEnv)("ANTHROPIC_IDENTITY_TOKEN_FILE");
      if (tokenFile) {
        return (0, identity_token_1.identityTokenFromFile)(tokenFile);
      }
      const tokenValue = (0, env_1.readEnv)("ANTHROPIC_IDENTITY_TOKEN");
      if (tokenValue) {
        return (0, identity_token_1.identityTokenFromValue)(tokenValue);
      }
      return null;
    }
    function cachedExchangeProvider(exchange, credentialsPath, onCacheWriteError, onSafetyWarning) {
      return async (opts) => {
        const fs = await Promise.resolve().then(() => __importStar(require("fs")));
        await (0, types_1.checkCredentialsFileSafety)(credentialsPath, onSafetyWarning);
        let existing;
        try {
          const raw = await fs.promises.readFile(credentialsPath, "utf-8");
          existing = JSON.parse(raw);
          const token = existing?.["access_token"];
          if (token && !opts?.forceRefresh) {
            const expiresAt = existing?.["expires_at"];
            if (expiresAt == null || (0, time_1.nowAsSeconds)() < expiresAt - types_1.MANDATORY_REFRESH_THRESHOLD_IN_SECONDS) {
              return { token, expiresAt: expiresAt ?? null };
            }
          }
        } catch (err) {
          const code = err?.code;
          if (code !== "ENOENT" && !(err instanceof SyntaxError)) {
            onCacheWriteError?.(err);
          }
        }
        const result = await exchange(opts);
        try {
          await (0, types_1.writeCredentialsFileAtomic)(credentialsPath, {
            ...existing ?? {},
            version: credentials_1.CREDENTIALS_FILE_VERSION,
            type: "oauth_token",
            access_token: result.token,
            expires_at: result.expiresAt
          });
        } catch (err) {
          onCacheWriteError?.(err);
        }
        return result;
      };
    }
  }
});

// node_modules/@anthropic-ai/sdk/internal/decoders/line.js
var require_line = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/decoders/line.js"(exports2) {
    "use strict";
    var _LineDecoder_buffer;
    var _LineDecoder_carriageReturnIndex;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.LineDecoder = void 0;
    exports2.findDoubleNewlineIndex = findDoubleNewlineIndex;
    var tslib_1 = require_tslib();
    var bytes_1 = require_bytes();
    var LineDecoder = class {
      constructor() {
        _LineDecoder_buffer.set(this, void 0);
        _LineDecoder_carriageReturnIndex.set(this, void 0);
        tslib_1.__classPrivateFieldSet(this, _LineDecoder_buffer, new Uint8Array(), "f");
        tslib_1.__classPrivateFieldSet(this, _LineDecoder_carriageReturnIndex, null, "f");
      }
      decode(chunk) {
        if (chunk == null) {
          return [];
        }
        const binaryChunk = chunk instanceof ArrayBuffer ? new Uint8Array(chunk) : typeof chunk === "string" ? (0, bytes_1.encodeUTF8)(chunk) : chunk;
        tslib_1.__classPrivateFieldSet(this, _LineDecoder_buffer, (0, bytes_1.concatBytes)([tslib_1.__classPrivateFieldGet(this, _LineDecoder_buffer, "f"), binaryChunk]), "f");
        const lines = [];
        let patternIndex;
        while ((patternIndex = findNewlineIndex(tslib_1.__classPrivateFieldGet(this, _LineDecoder_buffer, "f"), tslib_1.__classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f"))) != null) {
          if (patternIndex.carriage && tslib_1.__classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f") == null) {
            tslib_1.__classPrivateFieldSet(this, _LineDecoder_carriageReturnIndex, patternIndex.index, "f");
            continue;
          }
          if (tslib_1.__classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f") != null && (patternIndex.index !== tslib_1.__classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f") + 1 || patternIndex.carriage)) {
            lines.push((0, bytes_1.decodeUTF8)(tslib_1.__classPrivateFieldGet(this, _LineDecoder_buffer, "f").subarray(0, tslib_1.__classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f") - 1)));
            tslib_1.__classPrivateFieldSet(this, _LineDecoder_buffer, tslib_1.__classPrivateFieldGet(this, _LineDecoder_buffer, "f").subarray(tslib_1.__classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f")), "f");
            tslib_1.__classPrivateFieldSet(this, _LineDecoder_carriageReturnIndex, null, "f");
            continue;
          }
          const endIndex = tslib_1.__classPrivateFieldGet(this, _LineDecoder_carriageReturnIndex, "f") !== null ? patternIndex.preceding - 1 : patternIndex.preceding;
          const line = (0, bytes_1.decodeUTF8)(tslib_1.__classPrivateFieldGet(this, _LineDecoder_buffer, "f").subarray(0, endIndex));
          lines.push(line);
          tslib_1.__classPrivateFieldSet(this, _LineDecoder_buffer, tslib_1.__classPrivateFieldGet(this, _LineDecoder_buffer, "f").subarray(patternIndex.index), "f");
          tslib_1.__classPrivateFieldSet(this, _LineDecoder_carriageReturnIndex, null, "f");
        }
        return lines;
      }
      flush() {
        if (!tslib_1.__classPrivateFieldGet(this, _LineDecoder_buffer, "f").length) {
          return [];
        }
        return this.decode("\n");
      }
    };
    exports2.LineDecoder = LineDecoder;
    _LineDecoder_buffer = /* @__PURE__ */ new WeakMap(), _LineDecoder_carriageReturnIndex = /* @__PURE__ */ new WeakMap();
    LineDecoder.NEWLINE_CHARS = /* @__PURE__ */ new Set(["\n", "\r"]);
    LineDecoder.NEWLINE_REGEXP = /\r\n|[\n\r]/g;
    function findNewlineIndex(buffer, startIndex) {
      const newline = 10;
      const carriage = 13;
      for (let i = startIndex ?? 0; i < buffer.length; i++) {
        if (buffer[i] === newline) {
          return { preceding: i, index: i + 1, carriage: false };
        }
        if (buffer[i] === carriage) {
          return { preceding: i, index: i + 1, carriage: true };
        }
      }
      return null;
    }
    function findDoubleNewlineIndex(buffer) {
      const newline = 10;
      const carriage = 13;
      for (let i = 0; i < buffer.length - 1; i++) {
        if (buffer[i] === newline && buffer[i + 1] === newline) {
          return i + 2;
        }
        if (buffer[i] === carriage && buffer[i + 1] === carriage) {
          return i + 2;
        }
        if (buffer[i] === carriage && buffer[i + 1] === newline && i + 3 < buffer.length && buffer[i + 2] === carriage && buffer[i + 3] === newline) {
          return i + 4;
        }
      }
      return -1;
    }
  }
});

// node_modules/@anthropic-ai/sdk/core/streaming.js
var require_streaming = __commonJS({
  "node_modules/@anthropic-ai/sdk/core/streaming.js"(exports2) {
    "use strict";
    var _Stream_client;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Stream = void 0;
    exports2._iterSSEMessages = _iterSSEMessages;
    var tslib_1 = require_tslib();
    var error_1 = require_error();
    var shims_1 = require_shims();
    var line_1 = require_line();
    var shims_2 = require_shims();
    var errors_1 = require_errors();
    var values_1 = require_values();
    var bytes_1 = require_bytes();
    var log_1 = require_log();
    var error_2 = require_error();
    var Stream = class _Stream {
      constructor(iterator, controller, client) {
        this.iterator = iterator;
        _Stream_client.set(this, void 0);
        this.controller = controller;
        tslib_1.__classPrivateFieldSet(this, _Stream_client, client, "f");
      }
      static fromSSEResponse(response, controller, client) {
        let consumed = false;
        const logger = client ? (0, log_1.loggerFor)(client) : console;
        async function* iterator() {
          if (consumed) {
            throw new error_1.AnthropicError("Cannot iterate over a consumed stream, use `.tee()` to split the stream.");
          }
          consumed = true;
          let done = false;
          try {
            for await (const sse of _iterSSEMessages(response, controller)) {
              if (sse.event === "completion") {
                try {
                  yield JSON.parse(sse.data);
                } catch (e) {
                  logger.error(`Could not parse message into JSON:`, sse.data);
                  logger.error(`From chunk:`, sse.raw);
                  throw e;
                }
              }
              if (sse.event === "message_start" || sse.event === "message_delta" || sse.event === "message_stop" || sse.event === "content_block_start" || sse.event === "content_block_delta" || sse.event === "content_block_stop" || sse.event === "message" || sse.event === "user.message" || sse.event === "user.interrupt" || sse.event === "user.tool_confirmation" || sse.event === "user.custom_tool_result" || sse.event === "user.tool_result" || sse.event === "agent.message" || sse.event === "agent.thinking" || sse.event === "agent.tool_use" || sse.event === "agent.tool_result" || sse.event === "agent.mcp_tool_use" || sse.event === "agent.mcp_tool_result" || sse.event === "agent.custom_tool_use" || sse.event === "agent.thread_context_compacted" || sse.event === "session.status_running" || sse.event === "session.status_idle" || sse.event === "session.status_rescheduled" || sse.event === "session.status_terminated" || sse.event === "session.error" || sse.event === "session.deleted" || sse.event === "session.updated" || sse.event === "span.model_request_start" || sse.event === "span.model_request_end" || sse.event === "span.outcome_evaluation_start" || sse.event === "span.outcome_evaluation_ongoing" || sse.event === "span.outcome_evaluation_end" || sse.event === "user.define_outcome" || sse.event === "agent.thread_message_received" || sse.event === "agent.thread_message_sent" || sse.event === "agent.session_thread_message_received" || sse.event === "agent.session_thread_message_sent" || sse.event === "session.thread_created" || sse.event === "session.thread_status_created" || sse.event === "session.thread_status_running" || sse.event === "session.thread_status_idle" || sse.event === "session.thread_status_rescheduled" || sse.event === "session.thread_status_terminated") {
                try {
                  yield JSON.parse(sse.data);
                } catch (e) {
                  logger.error(`Could not parse message into JSON:`, sse.data);
                  logger.error(`From chunk:`, sse.raw);
                  throw e;
                }
              }
              if (sse.event === "ping") {
                continue;
              }
              if (sse.event === "error") {
                const body = (0, values_1.safeJSON)(sse.data) ?? sse.data;
                const type = body?.error?.type;
                throw new error_2.APIError(void 0, body, void 0, response.headers, type);
              }
            }
            done = true;
          } catch (e) {
            if ((0, errors_1.isAbortError)(e))
              return;
            throw e;
          } finally {
            if (!done)
              controller.abort();
          }
        }
        return new _Stream(iterator, controller, client);
      }
      /**
       * Generates a Stream from a newline-separated ReadableStream
       * where each item is a JSON value.
       */
      static fromReadableStream(readableStream, controller, client) {
        let consumed = false;
        async function* iterLines() {
          const lineDecoder = new line_1.LineDecoder();
          const iter = (0, shims_2.ReadableStreamToAsyncIterable)(readableStream);
          for await (const chunk of iter) {
            for (const line of lineDecoder.decode(chunk)) {
              yield line;
            }
          }
          for (const line of lineDecoder.flush()) {
            yield line;
          }
        }
        async function* iterator() {
          if (consumed) {
            throw new error_1.AnthropicError("Cannot iterate over a consumed stream, use `.tee()` to split the stream.");
          }
          consumed = true;
          let done = false;
          try {
            for await (const line of iterLines()) {
              if (done)
                continue;
              if (line)
                yield JSON.parse(line);
            }
            done = true;
          } catch (e) {
            if ((0, errors_1.isAbortError)(e))
              return;
            throw e;
          } finally {
            if (!done)
              controller.abort();
          }
        }
        return new _Stream(iterator, controller, client);
      }
      [(_Stream_client = /* @__PURE__ */ new WeakMap(), Symbol.asyncIterator)]() {
        return this.iterator();
      }
      /**
       * Splits the stream into two streams which can be
       * independently read from at different speeds.
       */
      tee() {
        const left = [];
        const right = [];
        const iterator = this.iterator();
        const teeIterator = (queue) => {
          return {
            next: () => {
              if (queue.length === 0) {
                const result = iterator.next();
                left.push(result);
                right.push(result);
              }
              return queue.shift();
            }
          };
        };
        return [
          new _Stream(() => teeIterator(left), this.controller, tslib_1.__classPrivateFieldGet(this, _Stream_client, "f")),
          new _Stream(() => teeIterator(right), this.controller, tslib_1.__classPrivateFieldGet(this, _Stream_client, "f"))
        ];
      }
      /**
       * Converts this stream to a newline-separated ReadableStream of
       * JSON stringified values in the stream
       * which can be turned back into a Stream with `Stream.fromReadableStream()`.
       */
      toReadableStream() {
        const self = this;
        let iter;
        return (0, shims_1.makeReadableStream)({
          async start() {
            iter = self[Symbol.asyncIterator]();
          },
          async pull(ctrl) {
            try {
              const { value, done } = await iter.next();
              if (done)
                return ctrl.close();
              const bytes = (0, bytes_1.encodeUTF8)(JSON.stringify(value) + "\n");
              ctrl.enqueue(bytes);
            } catch (err) {
              ctrl.error(err);
            }
          },
          async cancel() {
            await iter.return?.();
          }
        });
      }
    };
    exports2.Stream = Stream;
    async function* _iterSSEMessages(response, controller) {
      if (!response.body) {
        controller.abort();
        if (typeof globalThis.navigator !== "undefined" && globalThis.navigator.product === "ReactNative") {
          throw new error_1.AnthropicError(`The default react-native fetch implementation does not support streaming. Please use expo/fetch: https://docs.expo.dev/versions/latest/sdk/expo/#expofetch-api`);
        }
        throw new error_1.AnthropicError(`Attempted to iterate over a response with no body`);
      }
      const sseDecoder = new SSEDecoder();
      const lineDecoder = new line_1.LineDecoder();
      const iter = (0, shims_2.ReadableStreamToAsyncIterable)(response.body);
      for await (const sseChunk of iterSSEChunks(iter)) {
        for (const line of lineDecoder.decode(sseChunk)) {
          const sse = sseDecoder.decode(line);
          if (sse)
            yield sse;
        }
      }
      for (const line of lineDecoder.flush()) {
        const sse = sseDecoder.decode(line);
        if (sse)
          yield sse;
      }
    }
    async function* iterSSEChunks(iterator) {
      let data = new Uint8Array();
      for await (const chunk of iterator) {
        if (chunk == null) {
          continue;
        }
        const binaryChunk = chunk instanceof ArrayBuffer ? new Uint8Array(chunk) : typeof chunk === "string" ? (0, bytes_1.encodeUTF8)(chunk) : chunk;
        let newData = new Uint8Array(data.length + binaryChunk.length);
        newData.set(data);
        newData.set(binaryChunk, data.length);
        data = newData;
        let patternIndex;
        while ((patternIndex = (0, line_1.findDoubleNewlineIndex)(data)) !== -1) {
          yield data.slice(0, patternIndex);
          data = data.slice(patternIndex);
        }
      }
      if (data.length > 0) {
        yield data;
      }
    }
    var SSEDecoder = class {
      constructor() {
        this.event = null;
        this.data = [];
        this.chunks = [];
      }
      decode(line) {
        if (line.endsWith("\r")) {
          line = line.substring(0, line.length - 1);
        }
        if (!line) {
          if (!this.event && !this.data.length)
            return null;
          const sse = {
            event: this.event,
            data: this.data.join("\n"),
            raw: this.chunks
          };
          this.event = null;
          this.data = [];
          this.chunks = [];
          return sse;
        }
        this.chunks.push(line);
        if (line.startsWith(":")) {
          return null;
        }
        let [fieldname, _, value] = partition(line, ":");
        if (value.startsWith(" ")) {
          value = value.substring(1);
        }
        if (fieldname === "event") {
          this.event = value;
        } else if (fieldname === "data") {
          this.data.push(value);
        }
        return null;
      }
    };
    function partition(str, delimiter) {
      const index = str.indexOf(delimiter);
      if (index !== -1) {
        return [str.substring(0, index), delimiter, str.substring(index + delimiter.length)];
      }
      return [str, "", ""];
    }
  }
});

// node_modules/@anthropic-ai/sdk/internal/parse.js
var require_parse = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/parse.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.defaultParseResponse = defaultParseResponse;
    exports2.addRequestID = addRequestID;
    var streaming_1 = require_streaming();
    var log_1 = require_log();
    async function defaultParseResponse(client, props) {
      const { response, requestLogID, retryOfRequestLogID, startTime } = props;
      const body = await (async () => {
        if (props.options.stream) {
          (0, log_1.loggerFor)(client).debug("response", response.status, response.url, response.headers, response.body);
          if (props.options.__streamClass) {
            return props.options.__streamClass.fromSSEResponse(response, props.controller);
          }
          return streaming_1.Stream.fromSSEResponse(response, props.controller);
        }
        if (response.status === 204) {
          return null;
        }
        if (props.options.__binaryResponse) {
          return response;
        }
        const contentType = response.headers.get("content-type");
        const mediaType = contentType?.split(";")[0]?.trim();
        const isJSON = mediaType?.includes("application/json") || mediaType?.endsWith("+json");
        if (isJSON) {
          const contentLength = response.headers.get("content-length");
          if (contentLength === "0") {
            return void 0;
          }
          const json = await response.json();
          return addRequestID(json, response);
        }
        const text = await response.text();
        return text;
      })();
      (0, log_1.loggerFor)(client).debug(`[${requestLogID}] response parsed`, (0, log_1.formatRequestDetails)({
        retryOfRequestLogID,
        url: response.url,
        status: response.status,
        body,
        durationMs: Date.now() - startTime
      }));
      return body;
    }
    function addRequestID(value, response) {
      if (!value || typeof value !== "object" || Array.isArray(value)) {
        return value;
      }
      return Object.defineProperty(value, "_request_id", {
        value: response.headers.get("request-id"),
        enumerable: false
      });
    }
  }
});

// node_modules/@anthropic-ai/sdk/core/api-promise.js
var require_api_promise = __commonJS({
  "node_modules/@anthropic-ai/sdk/core/api-promise.js"(exports2) {
    "use strict";
    var _APIPromise_client;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.APIPromise = void 0;
    var tslib_1 = require_tslib();
    var parse_1 = require_parse();
    var APIPromise = class _APIPromise extends Promise {
      constructor(client, responsePromise, parseResponse = parse_1.defaultParseResponse) {
        super((resolve) => {
          resolve(null);
        });
        this.responsePromise = responsePromise;
        this.parseResponse = parseResponse;
        _APIPromise_client.set(this, void 0);
        tslib_1.__classPrivateFieldSet(this, _APIPromise_client, client, "f");
      }
      _thenUnwrap(transform) {
        return new _APIPromise(tslib_1.__classPrivateFieldGet(this, _APIPromise_client, "f"), this.responsePromise, async (client, props) => (0, parse_1.addRequestID)(transform(await this.parseResponse(client, props), props), props.response));
      }
      /**
       * Gets the raw `Response` instance instead of parsing the response
       * data.
       *
       * If you want to parse the response body but still get the `Response`
       * instance, you can use {@link withResponse()}.
       *
       * 👋 Getting the wrong TypeScript type for `Response`?
       * Try setting `"moduleResolution": "NodeNext"` or add `"lib": ["DOM"]`
       * to your `tsconfig.json`.
       */
      asResponse() {
        return this.responsePromise.then((p) => p.response);
      }
      /**
       * Gets the parsed response data, the raw `Response` instance and the ID of the request,
       * returned via the `request-id` header which is useful for debugging requests and resporting
       * issues to Anthropic.
       *
       * If you just want to get the raw `Response` instance without parsing it,
       * you can use {@link asResponse()}.
       *
       * 👋 Getting the wrong TypeScript type for `Response`?
       * Try setting `"moduleResolution": "NodeNext"` or add `"lib": ["DOM"]`
       * to your `tsconfig.json`.
       */
      async withResponse() {
        const [data, response] = await Promise.all([this.parse(), this.asResponse()]);
        return { data, response, request_id: response.headers.get("request-id") };
      }
      parse() {
        if (!this.parsedPromise) {
          this.parsedPromise = this.responsePromise.then((data) => this.parseResponse(tslib_1.__classPrivateFieldGet(this, _APIPromise_client, "f"), data));
        }
        return this.parsedPromise;
      }
      then(onfulfilled, onrejected) {
        return this.parse().then(onfulfilled, onrejected);
      }
      catch(onrejected) {
        return this.parse().catch(onrejected);
      }
      finally(onfinally) {
        return this.parse().finally(onfinally);
      }
    };
    exports2.APIPromise = APIPromise;
    _APIPromise_client = /* @__PURE__ */ new WeakMap();
  }
});

// node_modules/@anthropic-ai/sdk/core/pagination.js
var require_pagination = __commonJS({
  "node_modules/@anthropic-ai/sdk/core/pagination.js"(exports2) {
    "use strict";
    var _AbstractPage_client;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.PageCursor = exports2.TokenPage = exports2.Page = exports2.PagePromise = exports2.AbstractPage = void 0;
    var tslib_1 = require_tslib();
    var error_1 = require_error();
    var parse_1 = require_parse();
    var api_promise_1 = require_api_promise();
    var values_1 = require_values();
    var AbstractPage = class {
      constructor(client, response, body, options) {
        _AbstractPage_client.set(this, void 0);
        tslib_1.__classPrivateFieldSet(this, _AbstractPage_client, client, "f");
        this.options = options;
        this.response = response;
        this.body = body;
      }
      hasNextPage() {
        const items = this.getPaginatedItems();
        if (!items.length)
          return false;
        return this.nextPageRequestOptions() != null;
      }
      async getNextPage() {
        const nextOptions = this.nextPageRequestOptions();
        if (!nextOptions) {
          throw new error_1.AnthropicError("No next page expected; please check `.hasNextPage()` before calling `.getNextPage()`.");
        }
        return await tslib_1.__classPrivateFieldGet(this, _AbstractPage_client, "f").requestAPIList(this.constructor, nextOptions);
      }
      async *iterPages() {
        let page = this;
        yield page;
        while (page.hasNextPage()) {
          page = await page.getNextPage();
          yield page;
        }
      }
      async *[(_AbstractPage_client = /* @__PURE__ */ new WeakMap(), Symbol.asyncIterator)]() {
        for await (const page of this.iterPages()) {
          for (const item of page.getPaginatedItems()) {
            yield item;
          }
        }
      }
    };
    exports2.AbstractPage = AbstractPage;
    var PagePromise = class extends api_promise_1.APIPromise {
      constructor(client, request, Page2) {
        super(client, request, async (client2, props) => new Page2(client2, props.response, await (0, parse_1.defaultParseResponse)(client2, props), props.options));
      }
      /**
       * Allow auto-paginating iteration on an unawaited list call, eg:
       *
       *    for await (const item of client.items.list()) {
       *      console.log(item)
       *    }
       */
      async *[Symbol.asyncIterator]() {
        const page = await this;
        for await (const item of page) {
          yield item;
        }
      }
    };
    exports2.PagePromise = PagePromise;
    var Page = class extends AbstractPage {
      constructor(client, response, body, options) {
        super(client, response, body, options);
        this.data = body.data || [];
        this.has_more = body.has_more || false;
        this.first_id = body.first_id || null;
        this.last_id = body.last_id || null;
      }
      getPaginatedItems() {
        return this.data ?? [];
      }
      hasNextPage() {
        if (this.has_more === false) {
          return false;
        }
        return super.hasNextPage();
      }
      nextPageRequestOptions() {
        if (this.options.query?.["before_id"]) {
          const first_id = this.first_id;
          if (!first_id) {
            return null;
          }
          return {
            ...this.options,
            query: {
              ...(0, values_1.maybeObj)(this.options.query),
              before_id: first_id
            }
          };
        }
        const cursor = this.last_id;
        if (!cursor) {
          return null;
        }
        return {
          ...this.options,
          query: {
            ...(0, values_1.maybeObj)(this.options.query),
            after_id: cursor
          }
        };
      }
    };
    exports2.Page = Page;
    var TokenPage = class extends AbstractPage {
      constructor(client, response, body, options) {
        super(client, response, body, options);
        this.data = body.data || [];
        this.has_more = body.has_more || false;
        this.next_page = body.next_page || null;
      }
      getPaginatedItems() {
        return this.data ?? [];
      }
      hasNextPage() {
        if (this.has_more === false) {
          return false;
        }
        return super.hasNextPage();
      }
      nextPageRequestOptions() {
        const cursor = this.next_page;
        if (!cursor) {
          return null;
        }
        return {
          ...this.options,
          query: {
            ...(0, values_1.maybeObj)(this.options.query),
            page_token: cursor
          }
        };
      }
    };
    exports2.TokenPage = TokenPage;
    var PageCursor = class extends AbstractPage {
      constructor(client, response, body, options) {
        super(client, response, body, options);
        this.data = body.data || [];
        this.next_page = body.next_page || null;
      }
      getPaginatedItems() {
        return this.data ?? [];
      }
      nextPageRequestOptions() {
        const cursor = this.next_page;
        if (!cursor) {
          return null;
        }
        return {
          ...this.options,
          query: {
            ...(0, values_1.maybeObj)(this.options.query),
            page: cursor
          }
        };
      }
    };
    exports2.PageCursor = PageCursor;
  }
});

// node_modules/@anthropic-ai/sdk/internal/uploads.js
var require_uploads = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/uploads.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.createForm = exports2.multipartFormRequestOptions = exports2.maybeMultipartFormRequestOptions = exports2.isAsyncIterable = exports2.checkFileSupport = void 0;
    exports2.makeFile = makeFile;
    exports2.getName = getName;
    var shims_1 = require_shims();
    var checkFileSupport = () => {
      if (typeof File === "undefined") {
        const { process: process2 } = globalThis;
        const isOldNode = typeof process2?.versions?.node === "string" && parseInt(process2.versions.node.split(".")) < 20;
        throw new Error("`File` is not defined as a global, which is required for file uploads." + (isOldNode ? " Update to Node 20 LTS or newer, or set `globalThis.File` to `import('node:buffer').File`." : ""));
      }
    };
    exports2.checkFileSupport = checkFileSupport;
    function makeFile(fileBits, fileName, options) {
      (0, exports2.checkFileSupport)();
      return new File(fileBits, fileName ?? "unknown_file", options);
    }
    function getName(value, stripPath) {
      const val = typeof value === "object" && value !== null && ("name" in value && value.name && String(value.name) || "url" in value && value.url && String(value.url) || "filename" in value && value.filename && String(value.filename) || "path" in value && value.path && String(value.path)) || "";
      return stripPath ? val.split(/[\\/]/).pop() || void 0 : val;
    }
    var isAsyncIterable = (value) => value != null && typeof value === "object" && typeof value[Symbol.asyncIterator] === "function";
    exports2.isAsyncIterable = isAsyncIterable;
    var maybeMultipartFormRequestOptions = async (opts, fetch2) => {
      if (!hasUploadableValue(opts.body))
        return opts;
      return { ...opts, body: await (0, exports2.createForm)(opts.body, fetch2) };
    };
    exports2.maybeMultipartFormRequestOptions = maybeMultipartFormRequestOptions;
    var multipartFormRequestOptions = async (opts, fetch2, stripFilenames = true) => {
      return { ...opts, body: await (0, exports2.createForm)(opts.body, fetch2, stripFilenames) };
    };
    exports2.multipartFormRequestOptions = multipartFormRequestOptions;
    var supportsFormDataMap = /* @__PURE__ */ new WeakMap();
    function supportsFormData(fetchObject) {
      const fetch2 = typeof fetchObject === "function" ? fetchObject : fetchObject.fetch;
      const cached = supportsFormDataMap.get(fetch2);
      if (cached)
        return cached;
      const promise = (async () => {
        try {
          const FetchResponse = "Response" in fetch2 ? fetch2.Response : (await fetch2("data:,")).constructor;
          const data = new FormData();
          if (data.toString() === await new FetchResponse(data).text()) {
            return false;
          }
          return true;
        } catch {
          return true;
        }
      })();
      supportsFormDataMap.set(fetch2, promise);
      return promise;
    }
    var createForm = async (body, fetch2, stripFilenames = true) => {
      if (!await supportsFormData(fetch2)) {
        throw new TypeError("The provided fetch function does not support file uploads with the current global FormData class.");
      }
      const form = new FormData();
      await Promise.all(Object.entries(body || {}).map(([key, value]) => addFormValue(form, key, value, stripFilenames)));
      return form;
    };
    exports2.createForm = createForm;
    var isNamedBlob = (value) => value instanceof Blob && "name" in value;
    var isUploadable = (value) => typeof value === "object" && value !== null && (value instanceof Response || (0, exports2.isAsyncIterable)(value) || isNamedBlob(value));
    var hasUploadableValue = (value) => {
      if (isUploadable(value))
        return true;
      if (Array.isArray(value))
        return value.some(hasUploadableValue);
      if (value && typeof value === "object") {
        for (const k in value) {
          if (hasUploadableValue(value[k]))
            return true;
        }
      }
      return false;
    };
    var addFormValue = async (form, key, value, stripFilenames) => {
      if (value === void 0)
        return;
      if (value == null) {
        throw new TypeError(`Received null for "${key}"; to pass null in FormData, you must use the string 'null'`);
      }
      if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
        form.append(key, String(value));
      } else if (value instanceof Response) {
        let options = {};
        const contentType = value.headers.get("Content-Type");
        if (contentType) {
          options = { type: contentType };
        }
        form.append(key, makeFile([await value.blob()], getName(value, stripFilenames), options));
      } else if ((0, exports2.isAsyncIterable)(value)) {
        form.append(key, makeFile([await new Response((0, shims_1.ReadableStreamFrom)(value)).blob()], getName(value, stripFilenames)));
      } else if (isNamedBlob(value)) {
        form.append(key, makeFile([value], getName(value, stripFilenames), { type: value.type }));
      } else if (Array.isArray(value)) {
        await Promise.all(value.map((entry) => addFormValue(form, key + "[]", entry, stripFilenames)));
      } else if (typeof value === "object") {
        await Promise.all(Object.entries(value).map(([name, prop]) => addFormValue(form, `${key}[${name}]`, prop, stripFilenames)));
      } else {
        throw new TypeError(`Invalid value given to form, expected a string, number, boolean, object, Array, File or Blob but got ${value} instead`);
      }
    };
  }
});

// node_modules/@anthropic-ai/sdk/internal/to-file.js
var require_to_file = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/to-file.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.toFile = toFile;
    var uploads_1 = require_uploads();
    var uploads_2 = require_uploads();
    var isBlobLike = (value) => value != null && typeof value === "object" && typeof value.size === "number" && typeof value.type === "string" && typeof value.text === "function" && typeof value.slice === "function" && typeof value.arrayBuffer === "function";
    var isFileLike = (value) => value != null && typeof value === "object" && typeof value.name === "string" && typeof value.lastModified === "number" && isBlobLike(value);
    var isResponseLike = (value) => value != null && typeof value === "object" && typeof value.url === "string" && typeof value.blob === "function";
    async function toFile(value, name, options) {
      (0, uploads_2.checkFileSupport)();
      value = await value;
      name || (name = (0, uploads_1.getName)(value, true));
      if (isFileLike(value)) {
        if (value instanceof File && name == null && options == null) {
          return value;
        }
        return (0, uploads_1.makeFile)([await value.arrayBuffer()], name ?? value.name, {
          type: value.type,
          lastModified: value.lastModified,
          ...options
        });
      }
      if (isResponseLike(value)) {
        const blob = await value.blob();
        name || (name = new URL(value.url).pathname.split(/[\\/]/).pop());
        return (0, uploads_1.makeFile)(await getBytes(blob), name, options);
      }
      const parts = await getBytes(value);
      if (!options?.type) {
        const type = parts.find((part) => typeof part === "object" && "type" in part && part.type);
        if (typeof type === "string") {
          options = { ...options, type };
        }
      }
      return (0, uploads_1.makeFile)(parts, name, options);
    }
    async function getBytes(value) {
      let parts = [];
      if (typeof value === "string" || ArrayBuffer.isView(value) || // includes Uint8Array, Buffer, etc.
      value instanceof ArrayBuffer) {
        parts.push(value);
      } else if (isBlobLike(value)) {
        parts.push(value instanceof Blob ? value : await value.arrayBuffer());
      } else if ((0, uploads_1.isAsyncIterable)(value)) {
        for await (const chunk of value) {
          parts.push(...await getBytes(chunk));
        }
      } else {
        const constructor = value?.constructor?.name;
        throw new Error(`Unexpected data type: ${typeof value}${constructor ? `; constructor: ${constructor}` : ""}${propsForError(value)}`);
      }
      return parts;
    }
    function propsForError(value) {
      if (typeof value !== "object" || value === null)
        return "";
      const props = Object.getOwnPropertyNames(value);
      return `; props: [${props.map((p) => `"${p}"`).join(", ")}]`;
    }
  }
});

// node_modules/@anthropic-ai/sdk/core/uploads.js
var require_uploads2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/core/uploads.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.toFile = void 0;
    var to_file_1 = require_to_file();
    Object.defineProperty(exports2, "toFile", { enumerable: true, get: function() {
      return to_file_1.toFile;
    } });
  }
});

// node_modules/@anthropic-ai/sdk/resources/shared.js
var require_shared = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/shared.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
  }
});

// node_modules/@anthropic-ai/sdk/core/resource.js
var require_resource = __commonJS({
  "node_modules/@anthropic-ai/sdk/core/resource.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.APIResource = void 0;
    var APIResource = class {
      constructor(client) {
        this._client = client;
      }
    };
    exports2.APIResource = APIResource;
  }
});

// node_modules/@anthropic-ai/sdk/internal/headers.js
var require_headers = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/headers.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.isEmptyHeaders = exports2.buildHeaders = void 0;
    var values_1 = require_values();
    var brand_privateNullableHeaders = /* @__PURE__ */ Symbol.for("brand.privateNullableHeaders");
    function* iterateHeaders(headers) {
      if (!headers)
        return;
      if (brand_privateNullableHeaders in headers) {
        const { values, nulls } = headers;
        yield* values.entries();
        for (const name of nulls) {
          yield [name, null];
        }
        return;
      }
      let shouldClear = false;
      let iter;
      if (headers instanceof Headers) {
        iter = headers.entries();
      } else if ((0, values_1.isReadonlyArray)(headers)) {
        iter = headers;
      } else {
        shouldClear = true;
        iter = Object.entries(headers ?? {});
      }
      for (let row of iter) {
        const name = row[0];
        if (typeof name !== "string")
          throw new TypeError("expected header name to be a string");
        const values = (0, values_1.isReadonlyArray)(row[1]) ? row[1] : [row[1]];
        let didClear = false;
        for (const value of values) {
          if (value === void 0)
            continue;
          if (shouldClear && !didClear) {
            didClear = true;
            yield [name, null];
          }
          yield [name, value];
        }
      }
    }
    var buildHeaders = (newHeaders) => {
      const targetHeaders = new Headers();
      const nullHeaders = /* @__PURE__ */ new Set();
      for (const headers of newHeaders) {
        const seenHeaders = /* @__PURE__ */ new Set();
        for (const [name, value] of iterateHeaders(headers)) {
          const lowerName = name.toLowerCase();
          if (!seenHeaders.has(lowerName)) {
            targetHeaders.delete(name);
            seenHeaders.add(lowerName);
          }
          if (value === null) {
            targetHeaders.delete(name);
            nullHeaders.add(lowerName);
          } else {
            targetHeaders.append(name, value);
            nullHeaders.delete(lowerName);
          }
        }
      }
      return { [brand_privateNullableHeaders]: true, values: targetHeaders, nulls: nullHeaders };
    };
    exports2.buildHeaders = buildHeaders;
    var isEmptyHeaders = (headers) => {
      for (const _ of iterateHeaders(headers))
        return false;
      return true;
    };
    exports2.isEmptyHeaders = isEmptyHeaders;
  }
});

// node_modules/@anthropic-ai/sdk/lib/stainless-helper-header.js
var require_stainless_helper_header = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/stainless-helper-header.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.SDK_HELPER_SYMBOL = void 0;
    exports2.wasCreatedByStainlessHelper = wasCreatedByStainlessHelper;
    exports2.collectStainlessHelpers = collectStainlessHelpers;
    exports2.stainlessHelperHeader = stainlessHelperHeader;
    exports2.stainlessHelperHeaderFromFile = stainlessHelperHeaderFromFile;
    exports2.SDK_HELPER_SYMBOL = /* @__PURE__ */ Symbol("anthropic.sdk.stainlessHelper");
    function wasCreatedByStainlessHelper(value) {
      return typeof value === "object" && value !== null && exports2.SDK_HELPER_SYMBOL in value;
    }
    function collectStainlessHelpers(tools, messages) {
      const helpers = /* @__PURE__ */ new Set();
      if (tools) {
        for (const tool of tools) {
          if (wasCreatedByStainlessHelper(tool)) {
            helpers.add(tool[exports2.SDK_HELPER_SYMBOL]);
          }
        }
      }
      if (messages) {
        for (const message of messages) {
          if (wasCreatedByStainlessHelper(message)) {
            helpers.add(message[exports2.SDK_HELPER_SYMBOL]);
          }
          if (Array.isArray(message.content)) {
            for (const block of message.content) {
              if (wasCreatedByStainlessHelper(block)) {
                helpers.add(block[exports2.SDK_HELPER_SYMBOL]);
              }
            }
          }
        }
      }
      return Array.from(helpers);
    }
    function stainlessHelperHeader(tools, messages) {
      const helpers = collectStainlessHelpers(tools, messages);
      if (helpers.length === 0)
        return {};
      return { "x-stainless-helper": helpers.join(", ") };
    }
    function stainlessHelperHeaderFromFile(file) {
      if (wasCreatedByStainlessHelper(file)) {
        return { "x-stainless-helper": file[exports2.SDK_HELPER_SYMBOL] };
      }
      return {};
    }
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/path.js
var require_path = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/path.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.path = exports2.createPathTagFunction = void 0;
    exports2.encodeURIPath = encodeURIPath;
    var error_1 = require_error();
    function encodeURIPath(str) {
      return str.replace(/[^A-Za-z0-9\-._~!$&'()*+,;=:@]+/g, encodeURIComponent);
    }
    var EMPTY = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.create(null));
    var createPathTagFunction = (pathEncoder = encodeURIPath) => function path(statics, ...params) {
      if (statics.length === 1)
        return statics[0];
      let postPath = false;
      const invalidSegments = [];
      const path2 = statics.reduce((previousValue, currentValue, index) => {
        if (/[?#]/.test(currentValue)) {
          postPath = true;
        }
        const value = params[index];
        let encoded = (postPath ? encodeURIComponent : pathEncoder)("" + value);
        if (index !== params.length && (value == null || typeof value === "object" && // handle values from other realms
        value.toString === Object.getPrototypeOf(Object.getPrototypeOf(value.hasOwnProperty ?? EMPTY) ?? EMPTY)?.toString)) {
          encoded = value + "";
          invalidSegments.push({
            start: previousValue.length + currentValue.length,
            length: encoded.length,
            error: `Value of type ${Object.prototype.toString.call(value).slice(8, -1)} is not a valid path parameter`
          });
        }
        return previousValue + currentValue + (index === params.length ? "" : encoded);
      }, "");
      const pathOnly = path2.split(/[?#]/, 1)[0];
      const invalidSegmentPattern = /(?<=^|\/)(?:\.|%2e){1,2}(?=\/|$)/gi;
      let match;
      while ((match = invalidSegmentPattern.exec(pathOnly)) !== null) {
        invalidSegments.push({
          start: match.index,
          length: match[0].length,
          error: `Value "${match[0]}" can't be safely passed as a path parameter`
        });
      }
      invalidSegments.sort((a, b) => a.start - b.start);
      if (invalidSegments.length > 0) {
        let lastEnd = 0;
        const underline = invalidSegments.reduce((acc, segment) => {
          const spaces = " ".repeat(segment.start - lastEnd);
          const arrows = "^".repeat(segment.length);
          lastEnd = segment.start + segment.length;
          return acc + spaces + arrows;
        }, "");
        throw new error_1.AnthropicError(`Path parameters result in path with invalid segments:
${invalidSegments.map((e) => e.error).join("\n")}
${path2}
${underline}`);
      }
      return path2;
    };
    exports2.createPathTagFunction = createPathTagFunction;
    exports2.path = (0, exports2.createPathTagFunction)(encodeURIPath);
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/files.js
var require_files = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/files.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Files = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var stainless_helper_header_1 = require_stainless_helper_header();
    var uploads_1 = require_uploads();
    var path_1 = require_path();
    var Files = class extends resource_1.APIResource {
      /**
       * List Files
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const fileMetadata of client.beta.files.list()) {
       *   // ...
       * }
       * ```
       */
      list(params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList("/v1/files?beta=true", pagination_1.Page, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "files-api-2025-04-14"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Delete File
       *
       * @example
       * ```ts
       * const deletedFile = await client.beta.files.delete(
       *   'file_id',
       * );
       * ```
       */
      delete(fileID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.delete((0, path_1.path)`/v1/files/${fileID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "files-api-2025-04-14"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Download File
       *
       * @example
       * ```ts
       * const response = await client.beta.files.download(
       *   'file_id',
       * );
       *
       * const content = await response.blob();
       * console.log(content);
       * ```
       */
      download(fileID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/files/${fileID}/content?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "files-api-2025-04-14"].toString(),
              Accept: "application/binary"
            },
            options?.headers
          ]),
          __binaryResponse: true
        });
      }
      /**
       * Get File Metadata
       *
       * @example
       * ```ts
       * const fileMetadata =
       *   await client.beta.files.retrieveMetadata('file_id');
       * ```
       */
      retrieveMetadata(fileID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/files/${fileID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "files-api-2025-04-14"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Upload File
       *
       * @example
       * ```ts
       * const fileMetadata = await client.beta.files.upload({
       *   file: fs.createReadStream('path/to/file'),
       * });
       * ```
       */
      upload(params, options) {
        const { betas, ...body } = params;
        return this._client.post("/v1/files?beta=true", (0, uploads_1.multipartFormRequestOptions)({
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "files-api-2025-04-14"].toString() },
            (0, stainless_helper_header_1.stainlessHelperHeaderFromFile)(body.file),
            options?.headers
          ])
        }, this._client));
      }
    };
    exports2.Files = Files;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/models.js
var require_models = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/models.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Models = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Models = class extends resource_1.APIResource {
      /**
       * Get a specific model.
       *
       * The Models API response can be used to determine information about a specific
       * model or resolve a model alias to a model ID.
       *
       * @example
       * ```ts
       * const betaModelInfo = await client.beta.models.retrieve(
       *   'model_id',
       * );
       * ```
       */
      retrieve(modelID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/models/${modelID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
            options?.headers
          ])
        });
      }
      /**
       * List available models.
       *
       * The Models API response can be used to determine which models are available for
       * use in the API. More recently released models are listed first.
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaModelInfo of client.beta.models.list()) {
       *   // ...
       * }
       * ```
       */
      list(params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList("/v1/models?beta=true", pagination_1.Page, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
            options?.headers
          ])
        });
      }
    };
    exports2.Models = Models;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/user-profiles.js
var require_user_profiles = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/user-profiles.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.UserProfiles = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var UserProfiles = class extends resource_1.APIResource {
      /**
       * Create User Profile
       *
       * @example
       * ```ts
       * const betaUserProfile =
       *   await client.beta.userProfiles.create();
       * ```
       */
      create(params, options) {
        const { betas, ...body } = params;
        return this._client.post("/v1/user_profiles?beta=true", {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "user-profiles-2026-03-24"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Get User Profile
       *
       * @example
       * ```ts
       * const betaUserProfile =
       *   await client.beta.userProfiles.retrieve(
       *     'uprof_011CZkZCu8hGbp5mYRQgUmz9',
       *   );
       * ```
       */
      retrieve(userProfileID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/user_profiles/${userProfileID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "user-profiles-2026-03-24"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Update User Profile
       *
       * @example
       * ```ts
       * const betaUserProfile =
       *   await client.beta.userProfiles.update(
       *     'uprof_011CZkZCu8hGbp5mYRQgUmz9',
       *   );
       * ```
       */
      update(userProfileID, params, options) {
        const { betas, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/user_profiles/${userProfileID}?beta=true`, {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "user-profiles-2026-03-24"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * List User Profiles
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaUserProfile of client.beta.userProfiles.list()) {
       *   // ...
       * }
       * ```
       */
      list(params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList("/v1/user_profiles?beta=true", pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "user-profiles-2026-03-24"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Create Enrollment URL
       *
       * @example
       * ```ts
       * const betaUserProfileEnrollmentURL =
       *   await client.beta.userProfiles.createEnrollmentURL(
       *     'uprof_011CZkZCu8hGbp5mYRQgUmz9',
       *   );
       * ```
       */
      createEnrollmentURL(userProfileID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.post((0, path_1.path)`/v1/user_profiles/${userProfileID}/enrollment_url?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "user-profiles-2026-03-24"].toString() },
            options?.headers
          ])
        });
      }
    };
    exports2.UserProfiles = UserProfiles;
  }
});

// node_modules/standardwebhooks/dist/timing_safe_equal.js
var require_timing_safe_equal = __commonJS({
  "node_modules/standardwebhooks/dist/timing_safe_equal.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.timingSafeEqual = void 0;
    function assert(expr, msg = "") {
      if (!expr) {
        throw new Error(msg);
      }
    }
    function timingSafeEqual(a, b) {
      if (a.byteLength !== b.byteLength) {
        return false;
      }
      if (!(a instanceof DataView)) {
        a = new DataView(ArrayBuffer.isView(a) ? a.buffer : a);
      }
      if (!(b instanceof DataView)) {
        b = new DataView(ArrayBuffer.isView(b) ? b.buffer : b);
      }
      assert(a instanceof DataView);
      assert(b instanceof DataView);
      const length = a.byteLength;
      let out = 0;
      let i = -1;
      while (++i < length) {
        out |= a.getUint8(i) ^ b.getUint8(i);
      }
      return out === 0;
    }
    exports2.timingSafeEqual = timingSafeEqual;
  }
});

// node_modules/@stablelib/base64/lib/base64.js
var require_base642 = __commonJS({
  "node_modules/@stablelib/base64/lib/base64.js"(exports2) {
    "use strict";
    var __extends = exports2 && exports2.__extends || /* @__PURE__ */ (function() {
      var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
          d2.__proto__ = b2;
        } || function(d2, b2) {
          for (var p in b2) if (b2.hasOwnProperty(p)) d2[p] = b2[p];
        };
        return extendStatics(d, b);
      };
      return function(d, b) {
        extendStatics(d, b);
        function __() {
          this.constructor = d;
        }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    })();
    Object.defineProperty(exports2, "__esModule", { value: true });
    var INVALID_BYTE = 256;
    var Coder = (
      /** @class */
      (function() {
        function Coder2(_paddingCharacter) {
          if (_paddingCharacter === void 0) {
            _paddingCharacter = "=";
          }
          this._paddingCharacter = _paddingCharacter;
        }
        Coder2.prototype.encodedLength = function(length) {
          if (!this._paddingCharacter) {
            return (length * 8 + 5) / 6 | 0;
          }
          return (length + 2) / 3 * 4 | 0;
        };
        Coder2.prototype.encode = function(data) {
          var out = "";
          var i = 0;
          for (; i < data.length - 2; i += 3) {
            var c = data[i] << 16 | data[i + 1] << 8 | data[i + 2];
            out += this._encodeByte(c >>> 3 * 6 & 63);
            out += this._encodeByte(c >>> 2 * 6 & 63);
            out += this._encodeByte(c >>> 1 * 6 & 63);
            out += this._encodeByte(c >>> 0 * 6 & 63);
          }
          var left = data.length - i;
          if (left > 0) {
            var c = data[i] << 16 | (left === 2 ? data[i + 1] << 8 : 0);
            out += this._encodeByte(c >>> 3 * 6 & 63);
            out += this._encodeByte(c >>> 2 * 6 & 63);
            if (left === 2) {
              out += this._encodeByte(c >>> 1 * 6 & 63);
            } else {
              out += this._paddingCharacter || "";
            }
            out += this._paddingCharacter || "";
          }
          return out;
        };
        Coder2.prototype.maxDecodedLength = function(length) {
          if (!this._paddingCharacter) {
            return (length * 6 + 7) / 8 | 0;
          }
          return length / 4 * 3 | 0;
        };
        Coder2.prototype.decodedLength = function(s) {
          return this.maxDecodedLength(s.length - this._getPaddingLength(s));
        };
        Coder2.prototype.decode = function(s) {
          if (s.length === 0) {
            return new Uint8Array(0);
          }
          var paddingLength = this._getPaddingLength(s);
          var length = s.length - paddingLength;
          var out = new Uint8Array(this.maxDecodedLength(length));
          var op = 0;
          var i = 0;
          var haveBad = 0;
          var v0 = 0, v1 = 0, v2 = 0, v3 = 0;
          for (; i < length - 4; i += 4) {
            v0 = this._decodeChar(s.charCodeAt(i + 0));
            v1 = this._decodeChar(s.charCodeAt(i + 1));
            v2 = this._decodeChar(s.charCodeAt(i + 2));
            v3 = this._decodeChar(s.charCodeAt(i + 3));
            out[op++] = v0 << 2 | v1 >>> 4;
            out[op++] = v1 << 4 | v2 >>> 2;
            out[op++] = v2 << 6 | v3;
            haveBad |= v0 & INVALID_BYTE;
            haveBad |= v1 & INVALID_BYTE;
            haveBad |= v2 & INVALID_BYTE;
            haveBad |= v3 & INVALID_BYTE;
          }
          if (i < length - 1) {
            v0 = this._decodeChar(s.charCodeAt(i));
            v1 = this._decodeChar(s.charCodeAt(i + 1));
            out[op++] = v0 << 2 | v1 >>> 4;
            haveBad |= v0 & INVALID_BYTE;
            haveBad |= v1 & INVALID_BYTE;
          }
          if (i < length - 2) {
            v2 = this._decodeChar(s.charCodeAt(i + 2));
            out[op++] = v1 << 4 | v2 >>> 2;
            haveBad |= v2 & INVALID_BYTE;
          }
          if (i < length - 3) {
            v3 = this._decodeChar(s.charCodeAt(i + 3));
            out[op++] = v2 << 6 | v3;
            haveBad |= v3 & INVALID_BYTE;
          }
          if (haveBad !== 0) {
            throw new Error("Base64Coder: incorrect characters for decoding");
          }
          return out;
        };
        Coder2.prototype._encodeByte = function(b) {
          var result = b;
          result += 65;
          result += 25 - b >>> 8 & 0 - 65 - 26 + 97;
          result += 51 - b >>> 8 & 26 - 97 - 52 + 48;
          result += 61 - b >>> 8 & 52 - 48 - 62 + 43;
          result += 62 - b >>> 8 & 62 - 43 - 63 + 47;
          return String.fromCharCode(result);
        };
        Coder2.prototype._decodeChar = function(c) {
          var result = INVALID_BYTE;
          result += (42 - c & c - 44) >>> 8 & -INVALID_BYTE + c - 43 + 62;
          result += (46 - c & c - 48) >>> 8 & -INVALID_BYTE + c - 47 + 63;
          result += (47 - c & c - 58) >>> 8 & -INVALID_BYTE + c - 48 + 52;
          result += (64 - c & c - 91) >>> 8 & -INVALID_BYTE + c - 65 + 0;
          result += (96 - c & c - 123) >>> 8 & -INVALID_BYTE + c - 97 + 26;
          return result;
        };
        Coder2.prototype._getPaddingLength = function(s) {
          var paddingLength = 0;
          if (this._paddingCharacter) {
            for (var i = s.length - 1; i >= 0; i--) {
              if (s[i] !== this._paddingCharacter) {
                break;
              }
              paddingLength++;
            }
            if (s.length < 4 || paddingLength > 2) {
              throw new Error("Base64Coder: incorrect padding");
            }
          }
          return paddingLength;
        };
        return Coder2;
      })()
    );
    exports2.Coder = Coder;
    var stdCoder = new Coder();
    function encode(data) {
      return stdCoder.encode(data);
    }
    exports2.encode = encode;
    function decode(s) {
      return stdCoder.decode(s);
    }
    exports2.decode = decode;
    var URLSafeCoder = (
      /** @class */
      (function(_super) {
        __extends(URLSafeCoder2, _super);
        function URLSafeCoder2() {
          return _super !== null && _super.apply(this, arguments) || this;
        }
        URLSafeCoder2.prototype._encodeByte = function(b) {
          var result = b;
          result += 65;
          result += 25 - b >>> 8 & 0 - 65 - 26 + 97;
          result += 51 - b >>> 8 & 26 - 97 - 52 + 48;
          result += 61 - b >>> 8 & 52 - 48 - 62 + 45;
          result += 62 - b >>> 8 & 62 - 45 - 63 + 95;
          return String.fromCharCode(result);
        };
        URLSafeCoder2.prototype._decodeChar = function(c) {
          var result = INVALID_BYTE;
          result += (44 - c & c - 46) >>> 8 & -INVALID_BYTE + c - 45 + 62;
          result += (94 - c & c - 96) >>> 8 & -INVALID_BYTE + c - 95 + 63;
          result += (47 - c & c - 58) >>> 8 & -INVALID_BYTE + c - 48 + 52;
          result += (64 - c & c - 91) >>> 8 & -INVALID_BYTE + c - 65 + 0;
          result += (96 - c & c - 123) >>> 8 & -INVALID_BYTE + c - 97 + 26;
          return result;
        };
        return URLSafeCoder2;
      })(Coder)
    );
    exports2.URLSafeCoder = URLSafeCoder;
    var urlSafeCoder = new URLSafeCoder();
    function encodeURLSafe(data) {
      return urlSafeCoder.encode(data);
    }
    exports2.encodeURLSafe = encodeURLSafe;
    function decodeURLSafe(s) {
      return urlSafeCoder.decode(s);
    }
    exports2.decodeURLSafe = decodeURLSafe;
    exports2.encodedLength = function(length) {
      return stdCoder.encodedLength(length);
    };
    exports2.maxDecodedLength = function(length) {
      return stdCoder.maxDecodedLength(length);
    };
    exports2.decodedLength = function(s) {
      return stdCoder.decodedLength(s);
    };
  }
});

// node_modules/fast-sha256/sha256.js
var require_sha256 = __commonJS({
  "node_modules/fast-sha256/sha256.js"(exports2, module2) {
    (function(root, factory) {
      var exports3 = {};
      factory(exports3);
      var sha256 = exports3["default"];
      for (var k in exports3) {
        sha256[k] = exports3[k];
      }
      if (typeof module2 === "object" && typeof module2.exports === "object") {
        module2.exports = sha256;
      } else if (typeof define === "function" && define.amd) {
        define(function() {
          return sha256;
        });
      } else {
        root.sha256 = sha256;
      }
    })(exports2, function(exports3) {
      "use strict";
      exports3.__esModule = true;
      exports3.digestLength = 32;
      exports3.blockSize = 64;
      var K = new Uint32Array([
        1116352408,
        1899447441,
        3049323471,
        3921009573,
        961987163,
        1508970993,
        2453635748,
        2870763221,
        3624381080,
        310598401,
        607225278,
        1426881987,
        1925078388,
        2162078206,
        2614888103,
        3248222580,
        3835390401,
        4022224774,
        264347078,
        604807628,
        770255983,
        1249150122,
        1555081692,
        1996064986,
        2554220882,
        2821834349,
        2952996808,
        3210313671,
        3336571891,
        3584528711,
        113926993,
        338241895,
        666307205,
        773529912,
        1294757372,
        1396182291,
        1695183700,
        1986661051,
        2177026350,
        2456956037,
        2730485921,
        2820302411,
        3259730800,
        3345764771,
        3516065817,
        3600352804,
        4094571909,
        275423344,
        430227734,
        506948616,
        659060556,
        883997877,
        958139571,
        1322822218,
        1537002063,
        1747873779,
        1955562222,
        2024104815,
        2227730452,
        2361852424,
        2428436474,
        2756734187,
        3204031479,
        3329325298
      ]);
      function hashBlocks(w, v, p, pos, len) {
        var a, b, c, d, e, f, g, h, u, i, j, t1, t2;
        while (len >= 64) {
          a = v[0];
          b = v[1];
          c = v[2];
          d = v[3];
          e = v[4];
          f = v[5];
          g = v[6];
          h = v[7];
          for (i = 0; i < 16; i++) {
            j = pos + i * 4;
            w[i] = (p[j] & 255) << 24 | (p[j + 1] & 255) << 16 | (p[j + 2] & 255) << 8 | p[j + 3] & 255;
          }
          for (i = 16; i < 64; i++) {
            u = w[i - 2];
            t1 = (u >>> 17 | u << 32 - 17) ^ (u >>> 19 | u << 32 - 19) ^ u >>> 10;
            u = w[i - 15];
            t2 = (u >>> 7 | u << 32 - 7) ^ (u >>> 18 | u << 32 - 18) ^ u >>> 3;
            w[i] = (t1 + w[i - 7] | 0) + (t2 + w[i - 16] | 0);
          }
          for (i = 0; i < 64; i++) {
            t1 = (((e >>> 6 | e << 32 - 6) ^ (e >>> 11 | e << 32 - 11) ^ (e >>> 25 | e << 32 - 25)) + (e & f ^ ~e & g) | 0) + (h + (K[i] + w[i] | 0) | 0) | 0;
            t2 = ((a >>> 2 | a << 32 - 2) ^ (a >>> 13 | a << 32 - 13) ^ (a >>> 22 | a << 32 - 22)) + (a & b ^ a & c ^ b & c) | 0;
            h = g;
            g = f;
            f = e;
            e = d + t1 | 0;
            d = c;
            c = b;
            b = a;
            a = t1 + t2 | 0;
          }
          v[0] += a;
          v[1] += b;
          v[2] += c;
          v[3] += d;
          v[4] += e;
          v[5] += f;
          v[6] += g;
          v[7] += h;
          pos += 64;
          len -= 64;
        }
        return pos;
      }
      var Hash = (
        /** @class */
        (function() {
          function Hash2() {
            this.digestLength = exports3.digestLength;
            this.blockSize = exports3.blockSize;
            this.state = new Int32Array(8);
            this.temp = new Int32Array(64);
            this.buffer = new Uint8Array(128);
            this.bufferLength = 0;
            this.bytesHashed = 0;
            this.finished = false;
            this.reset();
          }
          Hash2.prototype.reset = function() {
            this.state[0] = 1779033703;
            this.state[1] = 3144134277;
            this.state[2] = 1013904242;
            this.state[3] = 2773480762;
            this.state[4] = 1359893119;
            this.state[5] = 2600822924;
            this.state[6] = 528734635;
            this.state[7] = 1541459225;
            this.bufferLength = 0;
            this.bytesHashed = 0;
            this.finished = false;
            return this;
          };
          Hash2.prototype.clean = function() {
            for (var i = 0; i < this.buffer.length; i++) {
              this.buffer[i] = 0;
            }
            for (var i = 0; i < this.temp.length; i++) {
              this.temp[i] = 0;
            }
            this.reset();
          };
          Hash2.prototype.update = function(data, dataLength) {
            if (dataLength === void 0) {
              dataLength = data.length;
            }
            if (this.finished) {
              throw new Error("SHA256: can't update because hash was finished.");
            }
            var dataPos = 0;
            this.bytesHashed += dataLength;
            if (this.bufferLength > 0) {
              while (this.bufferLength < 64 && dataLength > 0) {
                this.buffer[this.bufferLength++] = data[dataPos++];
                dataLength--;
              }
              if (this.bufferLength === 64) {
                hashBlocks(this.temp, this.state, this.buffer, 0, 64);
                this.bufferLength = 0;
              }
            }
            if (dataLength >= 64) {
              dataPos = hashBlocks(this.temp, this.state, data, dataPos, dataLength);
              dataLength %= 64;
            }
            while (dataLength > 0) {
              this.buffer[this.bufferLength++] = data[dataPos++];
              dataLength--;
            }
            return this;
          };
          Hash2.prototype.finish = function(out) {
            if (!this.finished) {
              var bytesHashed = this.bytesHashed;
              var left = this.bufferLength;
              var bitLenHi = bytesHashed / 536870912 | 0;
              var bitLenLo = bytesHashed << 3;
              var padLength = bytesHashed % 64 < 56 ? 64 : 128;
              this.buffer[left] = 128;
              for (var i = left + 1; i < padLength - 8; i++) {
                this.buffer[i] = 0;
              }
              this.buffer[padLength - 8] = bitLenHi >>> 24 & 255;
              this.buffer[padLength - 7] = bitLenHi >>> 16 & 255;
              this.buffer[padLength - 6] = bitLenHi >>> 8 & 255;
              this.buffer[padLength - 5] = bitLenHi >>> 0 & 255;
              this.buffer[padLength - 4] = bitLenLo >>> 24 & 255;
              this.buffer[padLength - 3] = bitLenLo >>> 16 & 255;
              this.buffer[padLength - 2] = bitLenLo >>> 8 & 255;
              this.buffer[padLength - 1] = bitLenLo >>> 0 & 255;
              hashBlocks(this.temp, this.state, this.buffer, 0, padLength);
              this.finished = true;
            }
            for (var i = 0; i < 8; i++) {
              out[i * 4 + 0] = this.state[i] >>> 24 & 255;
              out[i * 4 + 1] = this.state[i] >>> 16 & 255;
              out[i * 4 + 2] = this.state[i] >>> 8 & 255;
              out[i * 4 + 3] = this.state[i] >>> 0 & 255;
            }
            return this;
          };
          Hash2.prototype.digest = function() {
            var out = new Uint8Array(this.digestLength);
            this.finish(out);
            return out;
          };
          Hash2.prototype._saveState = function(out) {
            for (var i = 0; i < this.state.length; i++) {
              out[i] = this.state[i];
            }
          };
          Hash2.prototype._restoreState = function(from, bytesHashed) {
            for (var i = 0; i < this.state.length; i++) {
              this.state[i] = from[i];
            }
            this.bytesHashed = bytesHashed;
            this.finished = false;
            this.bufferLength = 0;
          };
          return Hash2;
        })()
      );
      exports3.Hash = Hash;
      var HMAC = (
        /** @class */
        (function() {
          function HMAC2(key) {
            this.inner = new Hash();
            this.outer = new Hash();
            this.blockSize = this.inner.blockSize;
            this.digestLength = this.inner.digestLength;
            var pad = new Uint8Array(this.blockSize);
            if (key.length > this.blockSize) {
              new Hash().update(key).finish(pad).clean();
            } else {
              for (var i = 0; i < key.length; i++) {
                pad[i] = key[i];
              }
            }
            for (var i = 0; i < pad.length; i++) {
              pad[i] ^= 54;
            }
            this.inner.update(pad);
            for (var i = 0; i < pad.length; i++) {
              pad[i] ^= 54 ^ 92;
            }
            this.outer.update(pad);
            this.istate = new Uint32Array(8);
            this.ostate = new Uint32Array(8);
            this.inner._saveState(this.istate);
            this.outer._saveState(this.ostate);
            for (var i = 0; i < pad.length; i++) {
              pad[i] = 0;
            }
          }
          HMAC2.prototype.reset = function() {
            this.inner._restoreState(this.istate, this.inner.blockSize);
            this.outer._restoreState(this.ostate, this.outer.blockSize);
            return this;
          };
          HMAC2.prototype.clean = function() {
            for (var i = 0; i < this.istate.length; i++) {
              this.ostate[i] = this.istate[i] = 0;
            }
            this.inner.clean();
            this.outer.clean();
          };
          HMAC2.prototype.update = function(data) {
            this.inner.update(data);
            return this;
          };
          HMAC2.prototype.finish = function(out) {
            if (this.outer.finished) {
              this.outer.finish(out);
            } else {
              this.inner.finish(out);
              this.outer.update(out, this.digestLength).finish(out);
            }
            return this;
          };
          HMAC2.prototype.digest = function() {
            var out = new Uint8Array(this.digestLength);
            this.finish(out);
            return out;
          };
          return HMAC2;
        })()
      );
      exports3.HMAC = HMAC;
      function hash(data) {
        var h = new Hash().update(data);
        var digest = h.digest();
        h.clean();
        return digest;
      }
      exports3.hash = hash;
      exports3["default"] = hash;
      function hmac(key, data) {
        var h = new HMAC(key).update(data);
        var digest = h.digest();
        h.clean();
        return digest;
      }
      exports3.hmac = hmac;
      function fillBuffer(buffer, hmac2, info2, counter) {
        var num = counter[0];
        if (num === 0) {
          throw new Error("hkdf: cannot expand more");
        }
        hmac2.reset();
        if (num > 1) {
          hmac2.update(buffer);
        }
        if (info2) {
          hmac2.update(info2);
        }
        hmac2.update(counter);
        hmac2.finish(buffer);
        counter[0]++;
      }
      var hkdfSalt = new Uint8Array(exports3.digestLength);
      function hkdf(key, salt, info2, length) {
        if (salt === void 0) {
          salt = hkdfSalt;
        }
        if (length === void 0) {
          length = 32;
        }
        var counter = new Uint8Array([1]);
        var okm = hmac(salt, key);
        var hmac_ = new HMAC(okm);
        var buffer = new Uint8Array(hmac_.digestLength);
        var bufpos = buffer.length;
        var out = new Uint8Array(length);
        for (var i = 0; i < length; i++) {
          if (bufpos === buffer.length) {
            fillBuffer(buffer, hmac_, info2, counter);
            bufpos = 0;
          }
          out[i] = buffer[bufpos++];
        }
        hmac_.clean();
        buffer.fill(0);
        counter.fill(0);
        return out;
      }
      exports3.hkdf = hkdf;
      function pbkdf2(password, salt, iterations, dkLen) {
        var prf = new HMAC(password);
        var len = prf.digestLength;
        var ctr = new Uint8Array(4);
        var t = new Uint8Array(len);
        var u = new Uint8Array(len);
        var dk = new Uint8Array(dkLen);
        for (var i = 0; i * len < dkLen; i++) {
          var c = i + 1;
          ctr[0] = c >>> 24 & 255;
          ctr[1] = c >>> 16 & 255;
          ctr[2] = c >>> 8 & 255;
          ctr[3] = c >>> 0 & 255;
          prf.reset();
          prf.update(salt);
          prf.update(ctr);
          prf.finish(u);
          for (var j = 0; j < len; j++) {
            t[j] = u[j];
          }
          for (var j = 2; j <= iterations; j++) {
            prf.reset();
            prf.update(u).finish(u);
            for (var k = 0; k < len; k++) {
              t[k] ^= u[k];
            }
          }
          for (var j = 0; j < len && i * len + j < dkLen; j++) {
            dk[i * len + j] = t[j];
          }
        }
        for (var i = 0; i < len; i++) {
          t[i] = u[i] = 0;
        }
        for (var i = 0; i < 4; i++) {
          ctr[i] = 0;
        }
        prf.clean();
        return dk;
      }
      exports3.pbkdf2 = pbkdf2;
    });
  }
});

// node_modules/standardwebhooks/dist/index.js
var require_dist = __commonJS({
  "node_modules/standardwebhooks/dist/index.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Webhook = exports2.WebhookVerificationError = void 0;
    var timing_safe_equal_1 = require_timing_safe_equal();
    var base64 = require_base642();
    var sha256 = require_sha256();
    var WEBHOOK_TOLERANCE_IN_SECONDS = 5 * 60;
    var ExtendableError = class _ExtendableError extends Error {
      constructor(message) {
        super(message);
        Object.setPrototypeOf(this, _ExtendableError.prototype);
        this.name = "ExtendableError";
        this.stack = new Error(message).stack;
      }
    };
    var WebhookVerificationError = class _WebhookVerificationError extends ExtendableError {
      constructor(message) {
        super(message);
        Object.setPrototypeOf(this, _WebhookVerificationError.prototype);
        this.name = "WebhookVerificationError";
      }
    };
    exports2.WebhookVerificationError = WebhookVerificationError;
    var Webhook = class _Webhook {
      constructor(secret, options) {
        if (!secret) {
          throw new Error("Secret can't be empty.");
        }
        if ((options === null || options === void 0 ? void 0 : options.format) === "raw") {
          if (secret instanceof Uint8Array) {
            this.key = secret;
          } else {
            this.key = Uint8Array.from(secret, (c) => c.charCodeAt(0));
          }
        } else {
          if (typeof secret !== "string") {
            throw new Error("Expected secret to be of type string");
          }
          if (secret.startsWith(_Webhook.prefix)) {
            secret = secret.substring(_Webhook.prefix.length);
          }
          this.key = base64.decode(secret);
        }
      }
      verify(payload, headers_) {
        const headers = {};
        for (const key of Object.keys(headers_)) {
          headers[key.toLowerCase()] = headers_[key];
        }
        const msgId = headers["webhook-id"];
        const msgSignature = headers["webhook-signature"];
        const msgTimestamp = headers["webhook-timestamp"];
        if (!msgSignature || !msgId || !msgTimestamp) {
          throw new WebhookVerificationError("Missing required headers");
        }
        const timestamp = this.verifyTimestamp(msgTimestamp);
        const computedSignature = this.sign(msgId, timestamp, payload);
        const expectedSignature = computedSignature.split(",")[1];
        const passedSignatures = msgSignature.split(" ");
        const encoder = new globalThis.TextEncoder();
        for (const versionedSignature of passedSignatures) {
          const [version, signature] = versionedSignature.split(",");
          if (version !== "v1") {
            continue;
          }
          if ((0, timing_safe_equal_1.timingSafeEqual)(encoder.encode(signature), encoder.encode(expectedSignature))) {
            return JSON.parse(payload.toString());
          }
        }
        throw new WebhookVerificationError("No matching signature found");
      }
      sign(msgId, timestamp, payload) {
        if (typeof payload === "string") {
        } else if (payload.constructor.name === "Buffer") {
          payload = payload.toString();
        } else {
          throw new Error("Expected payload to be of type string or Buffer.");
        }
        const encoder = new TextEncoder();
        const timestampNumber = Math.floor(timestamp.getTime() / 1e3);
        const toSign = encoder.encode(`${msgId}.${timestampNumber}.${payload}`);
        const expectedSignature = base64.encode(sha256.hmac(this.key, toSign));
        return `v1,${expectedSignature}`;
      }
      verifyTimestamp(timestampHeader) {
        const now = Math.floor(Date.now() / 1e3);
        const timestamp = parseInt(timestampHeader, 10);
        if (isNaN(timestamp)) {
          throw new WebhookVerificationError("Invalid Signature Headers");
        }
        if (now - timestamp > WEBHOOK_TOLERANCE_IN_SECONDS) {
          throw new WebhookVerificationError("Message timestamp too old");
        }
        if (timestamp > now + WEBHOOK_TOLERANCE_IN_SECONDS) {
          throw new WebhookVerificationError("Message timestamp too new");
        }
        return new Date(timestamp * 1e3);
      }
    };
    exports2.Webhook = Webhook;
    Webhook.prefix = "whsec_";
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/webhooks.js
var require_webhooks = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/webhooks.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Webhooks = void 0;
    var resource_1 = require_resource();
    var standardwebhooks_1 = require_dist();
    var Webhooks = class extends resource_1.APIResource {
      unwrap(body, { headers, key }) {
        if (headers !== void 0) {
          const keyStr = key === void 0 ? this._client.webhookKey : key;
          if (keyStr === null)
            throw new Error("Webhook key must not be null in order to unwrap");
          const wh = new standardwebhooks_1.Webhook(keyStr);
          wh.verify(body, headers);
        }
        return JSON.parse(body);
      }
    };
    exports2.Webhooks = Webhooks;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/agents/versions.js
var require_versions = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/agents/versions.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Versions = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Versions = class extends resource_1.APIResource {
      /**
       * List Agent Versions
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaManagedAgentsAgent of client.beta.agents.versions.list(
       *   'agent_011CZkYpogX7uDKUyvBTophP',
       * )) {
       *   // ...
       * }
       * ```
       */
      list(agentID, params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList((0, path_1.path)`/v1/agents/${agentID}/versions?beta=true`, pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
    };
    exports2.Versions = Versions;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/agents/agents.js
var require_agents = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/agents/agents.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Agents = void 0;
    var tslib_1 = require_tslib();
    var resource_1 = require_resource();
    var VersionsAPI = tslib_1.__importStar(require_versions());
    var versions_1 = require_versions();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Agents = class extends resource_1.APIResource {
      constructor() {
        super(...arguments);
        this.versions = new VersionsAPI.Versions(this._client);
      }
      /**
       * Create Agent
       *
       * @example
       * ```ts
       * const betaManagedAgentsAgent =
       *   await client.beta.agents.create({
       *     model: 'claude-sonnet-4-6',
       *     name: 'My First Agent',
       *   });
       * ```
       */
      create(params, options) {
        const { betas, ...body } = params;
        return this._client.post("/v1/agents?beta=true", {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Get Agent
       *
       * @example
       * ```ts
       * const betaManagedAgentsAgent =
       *   await client.beta.agents.retrieve(
       *     'agent_011CZkYpogX7uDKUyvBTophP',
       *   );
       * ```
       */
      retrieve(agentID, params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/agents/${agentID}?beta=true`, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Update Agent
       *
       * @example
       * ```ts
       * const betaManagedAgentsAgent =
       *   await client.beta.agents.update(
       *     'agent_011CZkYpogX7uDKUyvBTophP',
       *     { version: 1 },
       *   );
       * ```
       */
      update(agentID, params, options) {
        const { betas, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/agents/${agentID}?beta=true`, {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * List Agents
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaManagedAgentsAgent of client.beta.agents.list()) {
       *   // ...
       * }
       * ```
       */
      list(params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList("/v1/agents?beta=true", pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Archive Agent
       *
       * @example
       * ```ts
       * const betaManagedAgentsAgent =
       *   await client.beta.agents.archive(
       *     'agent_011CZkYpogX7uDKUyvBTophP',
       *   );
       * ```
       */
      archive(agentID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.post((0, path_1.path)`/v1/agents/${agentID}/archive?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
    };
    exports2.Agents = Agents;
    Agents.Versions = versions_1.Versions;
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/abort.js
var require_abort = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/abort.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.linkAbort = linkAbort;
    function linkAbort(external, controller) {
      if (!external)
        return () => {
        };
      if (external.aborted) {
        controller.abort();
        return () => {
        };
      }
      const onAbort = () => controller.abort();
      external.addEventListener("abort", onAbort);
      return () => external.removeEventListener("abort", onAbort);
    }
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/backoff.js
var require_backoff = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/backoff.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.isStatus = isStatus;
    exports2.is4xx = is4xx;
    exports2.isFatal4xx = isFatal4xx;
    exports2.backoff = backoff;
    exports2.jitter = jitter;
    exports2.applyJitter = applyJitter;
    var error_1 = require_error();
    function isStatus(e, code) {
      return e instanceof error_1.APIError && e.status === code;
    }
    function is4xx(e) {
      return e instanceof error_1.APIError && typeof e.status === "number" && e.status >= 400 && e.status < 500;
    }
    function isFatal4xx(e) {
      return is4xx(e) && !isStatus(e, 408) && !isStatus(e, 409) && !isStatus(e, 429);
    }
    function backoff(attempt, baseMs, capMs) {
      return Math.min(baseMs * 2 ** attempt, capMs);
    }
    function jitter(lowMs, highMs) {
      return lowMs + Math.random() * (highMs - lowMs);
    }
    function applyJitter(ms) {
      return ms * (1 - Math.random() * 0.25);
    }
  }
});

// node_modules/@anthropic-ai/sdk/lib/helper-client.js
var require_helper_client = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/helper-client.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.copyClientForHelper = copyClientForHelper;
    var error_1 = require_error();
    var headers_1 = require_headers();
    function copyClientForHelper(client, { authToken, helper }) {
      if (!authToken) {
        throw new error_1.AnthropicError(`copyClientForHelper: expected a non-empty authToken but received ${JSON.stringify(authToken)}`);
      }
      const internal = client;
      const parentDefaults = internal._options.defaultHeaders;
      const parentAuthExtraHeaders = internal._authState?.extraHeaders;
      const inheritedAuthExtraHeaders = parentAuthExtraHeaders ? Object.fromEntries(Object.entries(parentAuthExtraHeaders).filter(([name]) => {
        const lower = name.toLowerCase();
        return lower !== "authorization" && lower !== "x-api-key";
      })) : void 0;
      const defaultHeaders = (0, headers_1.buildHeaders)([
        inheritedAuthExtraHeaders,
        parentDefaults,
        { "x-stainless-helper": helper }
      ]);
      return client.withOptions({
        apiKey: null,
        authToken,
        baseURL: client.baseURL,
        credentials: void 0,
        defaultHeaders
      });
    }
  }
});

// node_modules/@anthropic-ai/sdk/lib/environments/poller.js
var require_poller = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/environments/poller.js"(exports2) {
    "use strict";
    var _WorkPoller_runnerClient;
    var _WorkPoller_consumed;
    var _WorkPoller_controller;
    var _WorkPoller_detachExternal;
    var _WorkPoller_autoStop;
    var _WorkPoller_drain;
    var _WorkPoller_blockMs;
    var _WorkPoller_reclaimOlderThanMs;
    var _WorkPoller_requestOpts;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.WorkPoller = exports2.POLL_BLOCK_MS = exports2.jitter = exports2.isStatus = exports2.isFatal4xx = exports2.is4xx = void 0;
    exports2.backoff = backoff;
    var tslib_1 = require_tslib();
    var error_1 = require_error();
    var log_1 = require_log();
    var sleep_1 = require_sleep();
    var uuid_1 = require_uuid();
    var abort_1 = require_abort();
    var headers_1 = require_headers();
    var backoff_1 = require_backoff();
    var helper_client_1 = require_helper_client();
    var backoff_2 = require_backoff();
    Object.defineProperty(exports2, "is4xx", { enumerable: true, get: function() {
      return backoff_2.is4xx;
    } });
    Object.defineProperty(exports2, "isFatal4xx", { enumerable: true, get: function() {
      return backoff_2.isFatal4xx;
    } });
    Object.defineProperty(exports2, "isStatus", { enumerable: true, get: function() {
      return backoff_2.isStatus;
    } });
    Object.defineProperty(exports2, "jitter", { enumerable: true, get: function() {
      return backoff_2.jitter;
    } });
    exports2.POLL_BLOCK_MS = 999;
    var POLL_BACKOFF_BASE_MS = 1e3;
    var POLL_BACKOFF_CAP_MS = 6e4;
    var WorkPoller = class {
      constructor(opts) {
        _WorkPoller_runnerClient.set(this, void 0);
        _WorkPoller_consumed.set(this, false);
        _WorkPoller_controller.set(this, void 0);
        _WorkPoller_detachExternal.set(this, void 0);
        _WorkPoller_autoStop.set(this, void 0);
        _WorkPoller_drain.set(this, void 0);
        _WorkPoller_blockMs.set(this, void 0);
        _WorkPoller_reclaimOlderThanMs.set(this, void 0);
        _WorkPoller_requestOpts.set(this, void 0);
        this.client = opts.client;
        this.environmentId = opts.environmentId;
        this.environmentKey = opts.environmentKey;
        this.workerId = opts.workerId ?? defaultWorkerId();
        tslib_1.__classPrivateFieldSet(this, _WorkPoller_runnerClient, (0, helper_client_1.copyClientForHelper)(opts.client, {
          authToken: opts.environmentKey,
          helper: "environments-work-poller"
        }), "f");
        tslib_1.__classPrivateFieldSet(this, _WorkPoller_autoStop, opts.autoStop ?? true, "f");
        tslib_1.__classPrivateFieldSet(this, _WorkPoller_drain, opts.drain ?? false, "f");
        tslib_1.__classPrivateFieldSet(this, _WorkPoller_blockMs, opts.blockMs === void 0 ? exports2.POLL_BLOCK_MS : opts.blockMs, "f");
        tslib_1.__classPrivateFieldSet(this, _WorkPoller_reclaimOlderThanMs, opts.reclaimOlderThanMs ?? null, "f");
        tslib_1.__classPrivateFieldSet(this, _WorkPoller_requestOpts, opts.requestOptions, "f");
        tslib_1.__classPrivateFieldSet(this, _WorkPoller_controller, new AbortController(), "f");
        tslib_1.__classPrivateFieldSet(this, _WorkPoller_detachExternal, (0, abort_1.linkAbort)(opts.signal, tslib_1.__classPrivateFieldGet(this, _WorkPoller_controller, "f")), "f");
      }
      /** Read-only view of this iterator's abort signal. */
      get signal() {
        return tslib_1.__classPrivateFieldGet(this, _WorkPoller_controller, "f").signal;
      }
      /** Abort the iterator. The current `for await` will exit cleanly. */
      abort() {
        tslib_1.__classPrivateFieldGet(this, _WorkPoller_controller, "f").abort();
      }
      async *[(_WorkPoller_runnerClient = /* @__PURE__ */ new WeakMap(), _WorkPoller_consumed = /* @__PURE__ */ new WeakMap(), _WorkPoller_controller = /* @__PURE__ */ new WeakMap(), _WorkPoller_detachExternal = /* @__PURE__ */ new WeakMap(), _WorkPoller_autoStop = /* @__PURE__ */ new WeakMap(), _WorkPoller_drain = /* @__PURE__ */ new WeakMap(), _WorkPoller_blockMs = /* @__PURE__ */ new WeakMap(), _WorkPoller_reclaimOlderThanMs = /* @__PURE__ */ new WeakMap(), _WorkPoller_requestOpts = /* @__PURE__ */ new WeakMap(), Symbol.asyncIterator)]() {
        if (tslib_1.__classPrivateFieldGet(this, _WorkPoller_consumed, "f")) {
          throw new error_1.AnthropicError("Cannot iterate over a consumed WorkPoller");
        }
        tslib_1.__classPrivateFieldSet(this, _WorkPoller_consumed, true, "f");
        const log = (0, log_1.loggerFor)(this.client);
        log.info("poller starting", {
          component: "work-poller",
          environment_id: this.environmentId
        });
        try {
          let attempt = 0;
          while (!tslib_1.__classPrivateFieldGet(this, _WorkPoller_controller, "f").signal.aborted) {
            let work;
            try {
              work = await tslib_1.__classPrivateFieldGet(this, _WorkPoller_runnerClient, "f").beta.environments.work.poll(this.environmentId, {
                "Anthropic-Worker-ID": this.workerId,
                ...tslib_1.__classPrivateFieldGet(this, _WorkPoller_blockMs, "f") !== null ? { block_ms: tslib_1.__classPrivateFieldGet(this, _WorkPoller_blockMs, "f") } : {},
                ...tslib_1.__classPrivateFieldGet(this, _WorkPoller_reclaimOlderThanMs, "f") !== null ? { reclaim_older_than_ms: tslib_1.__classPrivateFieldGet(this, _WorkPoller_reclaimOlderThanMs, "f") } : {}
              }, { headers: (0, headers_1.buildHeaders)([tslib_1.__classPrivateFieldGet(this, _WorkPoller_requestOpts, "f")?.headers]), signal: tslib_1.__classPrivateFieldGet(this, _WorkPoller_controller, "f").signal });
            } catch (e) {
              if (tslib_1.__classPrivateFieldGet(this, _WorkPoller_controller, "f").signal.aborted)
                return;
              if ((0, backoff_1.isFatal4xx)(e)) {
                log.error("poll failed permanently, stopping poller", { error: String(e) });
                throw e;
              }
              const wait = (0, backoff_1.applyJitter)(backoff(attempt));
              log.warn("poll failed, backing off", { error: String(e), backoff_ms: wait });
              attempt++;
              await (0, sleep_1.sleep)(wait, tslib_1.__classPrivateFieldGet(this, _WorkPoller_controller, "f").signal);
              continue;
            }
            attempt = 0;
            if (work == null) {
              if (tslib_1.__classPrivateFieldGet(this, _WorkPoller_drain, "f"))
                return;
              await (0, sleep_1.sleep)((0, backoff_1.jitter)(1e3, 3e3), tslib_1.__classPrivateFieldGet(this, _WorkPoller_controller, "f").signal);
              continue;
            }
            log.info("claimed work", {
              component: "work-poller",
              environment_id: this.environmentId,
              work_id: work.id,
              work_type: work.data.type
            });
            try {
              await tslib_1.__classPrivateFieldGet(this, _WorkPoller_runnerClient, "f").beta.environments.work.ack(work.id, { environment_id: work.environment_id }, { headers: (0, headers_1.buildHeaders)([tslib_1.__classPrivateFieldGet(this, _WorkPoller_requestOpts, "f")?.headers]), signal: tslib_1.__classPrivateFieldGet(this, _WorkPoller_controller, "f").signal });
            } catch (e) {
              log.error("ack failed", { work_id: work.id, error: String(e) });
              continue;
            }
            try {
              yield work;
            } finally {
              if (tslib_1.__classPrivateFieldGet(this, _WorkPoller_autoStop, "f")) {
                try {
                  await tslib_1.__classPrivateFieldGet(this, _WorkPoller_runnerClient, "f").beta.environments.work.stop(work.id, { environment_id: work.environment_id }, { headers: (0, headers_1.buildHeaders)([tslib_1.__classPrivateFieldGet(this, _WorkPoller_requestOpts, "f")?.headers]) });
                } catch (e) {
                  if (!(0, backoff_1.isStatus)(e, 409))
                    log.warn("stop failed", { work_id: work.id, error: String(e) });
                }
              }
            }
          }
        } finally {
          tslib_1.__classPrivateFieldGet(this, _WorkPoller_detachExternal, "f").call(this);
        }
      }
    };
    exports2.WorkPoller = WorkPoller;
    function backoff(attempt) {
      return (0, backoff_1.backoff)(attempt, POLL_BACKOFF_BASE_MS, POLL_BACKOFF_CAP_MS);
    }
    function defaultWorkerId() {
      const env = globalThis.process?.env;
      const host = env?.["HOSTNAME"];
      return host ? `${host}-${(0, uuid_1.uuid4)()}` : (0, uuid_1.uuid4)();
    }
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/async-queue.js
var require_async_queue = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/async-queue.js"(exports2) {
    "use strict";
    var _AsyncQueue_items;
    var _AsyncQueue_waiters;
    var _AsyncQueue_closed;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.AsyncQueue = void 0;
    var tslib_1 = require_tslib();
    var AsyncQueue = class {
      constructor() {
        _AsyncQueue_items.set(this, []);
        _AsyncQueue_waiters.set(this, []);
        _AsyncQueue_closed.set(this, false);
      }
      /** Enqueue an item, or hand it directly to a waiting reader. Returns `false` once closed. */
      push(item) {
        if (tslib_1.__classPrivateFieldGet(this, _AsyncQueue_closed, "f"))
          return false;
        const w = tslib_1.__classPrivateFieldGet(this, _AsyncQueue_waiters, "f").shift();
        if (w)
          w({ done: false, value: item });
        else
          tslib_1.__classPrivateFieldGet(this, _AsyncQueue_items, "f").push(item);
        return true;
      }
      /** Mark the queue done. Idempotent; wakes every pending reader with `done: true`. */
      close() {
        if (tslib_1.__classPrivateFieldGet(this, _AsyncQueue_closed, "f"))
          return;
        tslib_1.__classPrivateFieldSet(this, _AsyncQueue_closed, true, "f");
        while (tslib_1.__classPrivateFieldGet(this, _AsyncQueue_waiters, "f").length > 0) {
          const w = tslib_1.__classPrivateFieldGet(this, _AsyncQueue_waiters, "f").shift();
          w({ done: true, value: void 0 });
        }
      }
      /**
       * Resolve with the next item, or `done: true` once the queue is closed and
       * drained. When `signal` is supplied, aborting it resolves a pending read
       * with `done: true` (cancellation is pushed down here rather than handled by
       * an outer `Promise.race`).
       */
      next(signal) {
        if (tslib_1.__classPrivateFieldGet(this, _AsyncQueue_items, "f").length > 0) {
          return Promise.resolve({ done: false, value: tslib_1.__classPrivateFieldGet(this, _AsyncQueue_items, "f").shift() });
        }
        if (tslib_1.__classPrivateFieldGet(this, _AsyncQueue_closed, "f") || signal?.aborted) {
          return Promise.resolve({ done: true, value: void 0 });
        }
        return new Promise((resolve) => {
          const waiter = (r) => {
            signal?.removeEventListener("abort", onAbort);
            resolve(r);
          };
          const onAbort = () => {
            const idx = tslib_1.__classPrivateFieldGet(this, _AsyncQueue_waiters, "f").indexOf(waiter);
            if (idx >= 0)
              tslib_1.__classPrivateFieldGet(this, _AsyncQueue_waiters, "f").splice(idx, 1);
            resolve({ done: true, value: void 0 });
          };
          tslib_1.__classPrivateFieldGet(this, _AsyncQueue_waiters, "f").push(waiter);
          signal?.addEventListener("abort", onAbort, { once: true });
        });
      }
      /** Synchronously remove and return the next buffered item, or `undefined` if empty. */
      tryShift() {
        return tslib_1.__classPrivateFieldGet(this, _AsyncQueue_items, "f").shift();
      }
    };
    exports2.AsyncQueue = AsyncQueue;
    _AsyncQueue_items = /* @__PURE__ */ new WeakMap(), _AsyncQueue_waiters = /* @__PURE__ */ new WeakMap(), _AsyncQueue_closed = /* @__PURE__ */ new WeakMap();
  }
});

// node_modules/@anthropic-ai/sdk/lib/tools/ToolError.js
var require_ToolError = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/tools/ToolError.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ToolError = void 0;
    var ToolError = class extends Error {
      constructor(content) {
        const message = typeof content === "string" ? content : content.map((block) => {
          if (block.type === "text")
            return block.text;
          return `[${block.type}]`;
        }).join(" ");
        super(message);
        this.name = "ToolError";
        this.content = content;
      }
    };
    exports2.ToolError = ToolError;
  }
});

// node_modules/@anthropic-ai/sdk/lib/tools/BetaRunnableTool.js
var require_BetaRunnableTool = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/tools/BetaRunnableTool.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.toolName = toolName;
    exports2.toolErrorContent = toolErrorContent;
    exports2.runRunnableTool = runRunnableTool;
    var ToolError_1 = require_ToolError();
    function toolName(tool) {
      return "name" in tool ? tool.name : tool.mcp_server_name;
    }
    function toolErrorContent(e) {
      return e instanceof ToolError_1.ToolError ? e.content : `Error: ${e instanceof Error ? e.message : String(e)}`;
    }
    async function runRunnableTool(tool, rawInput, context) {
      try {
        const input = tool.parse ? tool.parse(rawInput) : rawInput;
        const content = await tool.run(input, context);
        return { content, isError: false };
      } catch (e) {
        return { content: toolErrorContent(e), isError: true };
      }
    }
  }
});

// node_modules/@anthropic-ai/sdk/lib/tools/SessionToolRunner.js
var require_SessionToolRunner = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/tools/SessionToolRunner.js"(exports2) {
    "use strict";
    var _SessionToolRunner_instances;
    var _SessionToolRunner_consumed;
    var _SessionToolRunner_controller;
    var _SessionToolRunner_detachExternal;
    var _SessionToolRunner_requestOpts;
    var _SessionToolRunner_toolByName;
    var _SessionToolRunner_logger;
    var _SessionToolRunner_seen;
    var _SessionToolRunner_answered;
    var _SessionToolRunner_results;
    var _SessionToolRunner_inFlightCount;
    var _SessionToolRunner_onIdle;
    var _SessionToolRunner_idleTimer;
    var _SessionToolRunner_requestOptions;
    var _SessionToolRunner_streamLoop;
    var _SessionToolRunner_reconcile;
    var _SessionToolRunner_ingestHistory;
    var _SessionToolRunner_handleStreamEvent;
    var _SessionToolRunner_armIdleTimer;
    var _SessionToolRunner_disarmIdleTimer;
    var _SessionToolRunner_execute;
    var _SessionToolRunner_sendResult;
    var _SessionToolRunner_drain;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.SessionToolRunner = exports2.DEFAULT_MAX_IDLE_MS = exports2.MANAGED_AGENTS_BETA = void 0;
    var tslib_1 = require_tslib();
    var error_1 = require_error();
    var log_1 = require_log();
    var sleep_1 = require_sleep();
    var backoff_1 = require_backoff();
    var abort_1 = require_abort();
    var async_queue_1 = require_async_queue();
    var headers_1 = require_headers();
    var BetaRunnableTool_1 = require_BetaRunnableTool();
    exports2.MANAGED_AGENTS_BETA = "managed-agents-2026-04-01";
    var HELPER_NAME = "SessionToolRunner";
    var STREAM_BACKOFF_START_MS = 500;
    var STREAM_BACKOFF_CAP_MS = 1e4;
    var TOOL_TIMEOUT_MS = 12e4;
    var DRAIN_TIMEOUT_MS = 3e4;
    var SEND_RETRIES = 3;
    exports2.DEFAULT_MAX_IDLE_MS = 6e4;
    function isEndTurnIdle(ev) {
      return ev.type === "session.status_idle" && ev.stop_reason?.type === "end_turn";
    }
    var SessionToolRunner = class {
      constructor(sessionId, opts) {
        _SessionToolRunner_instances.add(this);
        _SessionToolRunner_consumed.set(this, false);
        _SessionToolRunner_controller.set(this, void 0);
        _SessionToolRunner_detachExternal.set(this, void 0);
        _SessionToolRunner_requestOpts.set(this, void 0);
        _SessionToolRunner_toolByName.set(this, void 0);
        _SessionToolRunner_logger.set(this, void 0);
        _SessionToolRunner_seen.set(this, /* @__PURE__ */ new Set());
        _SessionToolRunner_answered.set(this, /* @__PURE__ */ new Set());
        _SessionToolRunner_results.set(this, new async_queue_1.AsyncQueue());
        _SessionToolRunner_inFlightCount.set(this, 0);
        _SessionToolRunner_onIdle.set(this, null);
        _SessionToolRunner_idleTimer.set(this, void 0);
        this.client = opts.client;
        this.sessionId = sessionId;
        this.tools = opts.tools;
        this.maxIdleMs = opts.maxIdleMs ?? exports2.DEFAULT_MAX_IDLE_MS;
        tslib_1.__classPrivateFieldSet(this, _SessionToolRunner_logger, (0, log_1.loggerFor)(opts.client), "f");
        tslib_1.__classPrivateFieldSet(this, _SessionToolRunner_toolByName, new Map(opts.tools.map((t) => [(0, BetaRunnableTool_1.toolName)(t), t])), "f");
        tslib_1.__classPrivateFieldSet(this, _SessionToolRunner_controller, new AbortController(), "f");
        tslib_1.__classPrivateFieldSet(this, _SessionToolRunner_detachExternal, (0, abort_1.linkAbort)(opts.signal, tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f")), "f");
        tslib_1.__classPrivateFieldSet(this, _SessionToolRunner_requestOpts, opts.requestOptions, "f");
      }
      /** Read-only view of this runner's abort signal. */
      get signal() {
        return tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f").signal;
      }
      /** Abort the runner. Background tasks will wind down and `for await` will exit cleanly. */
      abort() {
        tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f").abort();
      }
      async *[(_SessionToolRunner_consumed = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_controller = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_detachExternal = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_requestOpts = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_toolByName = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_logger = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_seen = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_answered = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_results = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_inFlightCount = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_onIdle = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_idleTimer = /* @__PURE__ */ new WeakMap(), _SessionToolRunner_instances = /* @__PURE__ */ new WeakSet(), Symbol.asyncIterator)]() {
        if (tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_consumed, "f")) {
          throw new error_1.AnthropicError("Cannot iterate over a consumed SessionToolRunner");
        }
        tslib_1.__classPrivateFieldSet(this, _SessionToolRunner_consumed, true, "f");
        tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").info("session tool runner starting", {
          component: "session-tool-runner",
          session_id: this.sessionId
        });
        const streamPromise = tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_streamLoop).call(this).catch((e) => {
          if (!tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f").signal.aborted) {
            tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").error("stream loop failed", { error: String(e) });
          }
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f").abort();
        });
        try {
          while (true) {
            const next = await tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_results, "f").next(tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f").signal);
            if (next.done)
              break;
            yield next.value;
          }
          await streamPromise;
          let pending;
          while ((pending = tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_results, "f").tryShift()) !== void 0) {
            yield pending;
          }
        } finally {
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f").abort();
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_disarmIdleTimer).call(this);
          await streamPromise;
          try {
            await tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_drain).call(this);
          } catch (e) {
            tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").warn("drain failed", { error: String(e) });
          }
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_results, "f").close();
          for (const t of this.tools) {
            try {
              await t.close?.();
            } catch (e) {
              tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").warn("tool.close failed", { tool: (0, BetaRunnableTool_1.toolName)(t), error: String(e) });
            }
          }
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_detachExternal, "f").call(this);
        }
      }
    };
    exports2.SessionToolRunner = SessionToolRunner;
    _SessionToolRunner_requestOptions = function _SessionToolRunner_requestOptions2() {
      return {
        ...tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_requestOpts, "f"),
        headers: (0, headers_1.buildHeaders)([{ "x-stainless-helper": HELPER_NAME }, tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_requestOpts, "f")?.headers]),
        signal: tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f").signal
      };
    }, _SessionToolRunner_streamLoop = // ===== event stream =====
    async function _SessionToolRunner_streamLoop2() {
      const ctrl = tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f");
      let backoff = STREAM_BACKOFF_START_MS;
      while (!ctrl.signal.aborted) {
        try {
          const stream = await this.client.beta.sessions.events.stream(this.sessionId, {}, tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_requestOptions).call(this));
          await tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_reconcile).call(this);
          for await (const ev of stream) {
            backoff = STREAM_BACKOFF_START_MS;
            if (await tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_handleStreamEvent).call(this, ev))
              return;
          }
        } catch (e) {
          ctrl.signal.throwIfAborted();
          if ((0, backoff_1.isFatal4xx)(e)) {
            tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").error("permanent stream failure, shutting down", { error: String(e) });
            ctrl.abort();
            throw e;
          }
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").warn("stream disconnected, reconnecting", {
            error: String(e),
            backoff_ms: backoff
          });
        }
        ctrl.signal.throwIfAborted();
        await (0, sleep_1.sleep)(backoff, ctrl.signal);
        backoff = Math.min(backoff * 2, STREAM_BACKOFF_CAP_MS);
      }
    }, _SessionToolRunner_reconcile = /**
     * Read full history before dispatching so a `tool_use` whose result appears
     * later in the same history is not re-executed. Runs after the live stream is
     * already attached (see {@link SessionToolRunner.#streamLoop}).
     */
    async function _SessionToolRunner_reconcile2() {
      const ctrl = tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f");
      const pending = [];
      let lastWasEndTurn = false;
      try {
        for await (const ev of this.client.beta.sessions.events.list(this.sessionId, { limit: 1e3 }, tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_requestOptions).call(this))) {
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_ingestHistory).call(this, ev, pending);
          lastWasEndTurn = isEndTurnIdle(ev);
        }
      } catch (e) {
        ctrl.signal.throwIfAborted();
        tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").warn("reconcile list failed", { error: String(e) });
        for (const ev of pending)
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_seen, "f").delete(ev.id);
        return;
      }
      const unanswered = pending.filter((ev) => !tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_answered, "f").has(ev.id));
      if (lastWasEndTurn && unanswered.length === 0)
        tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_armIdleTimer).call(this);
      else
        tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_disarmIdleTimer).call(this);
      for (const ev of unanswered)
        await tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_execute).call(this, ev);
    }, _SessionToolRunner_ingestHistory = function _SessionToolRunner_ingestHistory2(ev, pending) {
      if (ev.type === "agent.tool_use" || ev.type === "agent.custom_tool_use") {
        tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_seen, "f").add(ev.id);
        if (!tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_answered, "f").has(ev.id))
          pending.push(ev);
      } else if (ev.type === "user.tool_result") {
        tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_answered, "f").add(ev.tool_use_id);
      } else if (ev.type === "user.custom_tool_result") {
        tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_answered, "f").add(ev.custom_tool_use_id);
      }
    }, _SessionToolRunner_handleStreamEvent = /** Returns true when the runner should exit. */
    async function _SessionToolRunner_handleStreamEvent2(ev) {
      if (isEndTurnIdle(ev))
        tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_armIdleTimer).call(this);
      else
        tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_disarmIdleTimer).call(this);
      switch (ev.type) {
        case "agent.tool_use":
        case "agent.custom_tool_use":
          if (!tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_seen, "f").has(ev.id)) {
            tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_seen, "f").add(ev.id);
            await tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_execute).call(this, ev);
          }
          return false;
        case "user.tool_result":
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_answered, "f").add(ev.tool_use_id);
          return false;
        case "user.custom_tool_result":
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_answered, "f").add(ev.custom_tool_use_id);
          return false;
        case "session.status_terminated":
        case "session.deleted":
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").info("session terminated", {
            component: "session-tool-runner",
            session_id: this.sessionId
          });
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f").abort();
          return true;
        default:
          return false;
      }
    }, _SessionToolRunner_armIdleTimer = function _SessionToolRunner_armIdleTimer2() {
      tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_disarmIdleTimer).call(this);
      if (this.maxIdleMs <= 0)
        return;
      tslib_1.__classPrivateFieldSet(this, _SessionToolRunner_idleTimer, setTimeout(() => {
        tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").info("session idle after end_turn; stopping", {
          component: "session-tool-runner",
          session_id: this.sessionId,
          max_idle_ms: this.maxIdleMs
        });
        tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f").abort();
      }, this.maxIdleMs), "f");
    }, _SessionToolRunner_disarmIdleTimer = function _SessionToolRunner_disarmIdleTimer2() {
      if (tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_idleTimer, "f") !== void 0) {
        clearTimeout(tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_idleTimer, "f"));
        tslib_1.__classPrivateFieldSet(this, _SessionToolRunner_idleTimer, void 0, "f");
      }
    }, _SessionToolRunner_execute = // ===== tool execution =====
    async function _SessionToolRunner_execute2(ev) {
      var _a, _b;
      if (tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_answered, "f").has(ev.id))
        return;
      tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").info("executing tool", {
        component: "session-tool-runner",
        session_id: this.sessionId,
        tool: ev.name,
        tool_use_id: ev.id
      });
      tslib_1.__classPrivateFieldSet(this, _SessionToolRunner_inFlightCount, (_a = tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_inFlightCount, "f"), _a++, _a), "f");
      try {
        const tool = tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_toolByName, "f").get(ev.name);
        if (!tool) {
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").info("tool not owned by this runner; leaving the tool_use_id pending for its owner", {
            component: "session-tool-runner",
            session_id: this.sessionId,
            tool: ev.name,
            tool_use_id: ev.id
          });
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_results, "f").push({ event: ev, toolUseId: ev.id, name: ev.name, isError: false, posted: false });
          return;
        }
        let content;
        let isError;
        const toolCtrl = new AbortController();
        const detachTool = (0, abort_1.linkAbort)(tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f").signal, toolCtrl);
        const timer = setTimeout(() => toolCtrl.abort(), TOOL_TIMEOUT_MS);
        try {
          const outcome = await (0, BetaRunnableTool_1.runRunnableTool)(tool, ev.input, {
            toolUse: ev,
            toolUseBlock: ev,
            signal: toolCtrl.signal
          });
          content = outcome.content;
          isError = outcome.isError;
        } finally {
          clearTimeout(timer);
          detachTool();
        }
        const result = buildResultEvent(ev, isError, toSessionContent(content));
        const posted = await tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_sendResult).call(this, result, ev.id);
        tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_results, "f").push({
          event: ev,
          result,
          toolUseId: ev.id,
          name: ev.name,
          isError,
          posted
        });
      } finally {
        tslib_1.__classPrivateFieldSet(this, _SessionToolRunner_inFlightCount, (_b = tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_inFlightCount, "f"), _b--, _b), "f");
        if (tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_inFlightCount, "f") === 0)
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_onIdle, "f")?.call(this);
      }
    }, _SessionToolRunner_sendResult = async function _SessionToolRunner_sendResult2(result, toolUseId) {
      const ctrl = tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_controller, "f");
      let lastErr;
      for (let i = 0; i < SEND_RETRIES; i++) {
        ctrl.signal.throwIfAborted();
        try {
          await this.client.beta.sessions.events.send(this.sessionId, { events: [result] }, tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_instances, "m", _SessionToolRunner_requestOptions).call(this));
          tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_answered, "f").add(toolUseId);
          return true;
        } catch (e) {
          lastErr = e;
          if ((0, backoff_1.isFatal4xx)(e))
            break;
          if (i < SEND_RETRIES - 1)
            await (0, sleep_1.sleep)((i + 1) * 1e3, ctrl.signal);
        }
      }
      tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").error("failed to send tool result", {
        tool_use_id: toolUseId,
        error: String(lastErr)
      });
      return false;
    }, _SessionToolRunner_drain = /** Wait (bounded) for in-flight tool executions to finish during teardown. */
    async function _SessionToolRunner_drain2() {
      if (tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_inFlightCount, "f") === 0)
        return;
      await Promise.race([new Promise((r) => tslib_1.__classPrivateFieldSet(this, _SessionToolRunner_onIdle, r, "f")), (0, sleep_1.sleep)(DRAIN_TIMEOUT_MS)]);
      tslib_1.__classPrivateFieldSet(this, _SessionToolRunner_onIdle, null, "f");
      if (tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_inFlightCount, "f") > 0) {
        tslib_1.__classPrivateFieldGet(this, _SessionToolRunner_logger, "f").warn("drain timeout exceeded");
      }
    };
    function buildResultEvent(ev, isError, content) {
      if (ev.type === "agent.custom_tool_use") {
        return { type: "user.custom_tool_result", custom_tool_use_id: ev.id, is_error: isError, content };
      }
      return { type: "user.tool_result", tool_use_id: ev.id, is_error: isError, content };
    }
    function toSessionContent(content) {
      if (typeof content === "string")
        return [{ type: "text", text: content || "(no output)" }];
      const out = content.map((b) => {
        if (b.type === "text")
          return { type: "text", text: b.text || "(no output)" };
        if (b.type === "image" || b.type === "document")
          return b;
        if (b.type === "search_result") {
          return {
            type: "search_result",
            source: b.source,
            title: b.title,
            content: b.content.map((c) => ({ type: "text", text: c.text })),
            citations: { enabled: b.citations?.enabled ?? false }
          };
        }
        return { type: "text", text: JSON.stringify(b) };
      });
      return out.length > 0 ? out : [{ type: "text", text: "(no output)" }];
    }
  }
});

// node_modules/@anthropic-ai/sdk/lib/transform-json-schema.js
var require_transform_json_schema = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/transform-json-schema.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.transformJSONSchema = transformJSONSchema;
    var utils_1 = require_utils2();
    var SUPPORTED_STRING_FORMATS = /* @__PURE__ */ new Set([
      "date-time",
      "time",
      "date",
      "duration",
      "email",
      "hostname",
      "uri",
      "ipv4",
      "ipv6",
      "uuid"
    ]);
    function deepClone(obj) {
      return JSON.parse(JSON.stringify(obj));
    }
    function transformJSONSchema(jsonSchema) {
      const workingCopy = deepClone(jsonSchema);
      return _transformJSONSchema(workingCopy);
    }
    function _transformJSONSchema(jsonSchema) {
      const strictSchema = {};
      const ref = (0, utils_1.pop)(jsonSchema, "$ref");
      if (ref !== void 0) {
        strictSchema["$ref"] = ref;
        return strictSchema;
      }
      const defs = (0, utils_1.pop)(jsonSchema, "$defs");
      if (defs !== void 0) {
        const strictDefs = {};
        strictSchema["$defs"] = strictDefs;
        for (const [name, defSchema] of Object.entries(defs)) {
          strictDefs[name] = _transformJSONSchema(defSchema);
        }
      }
      const type = (0, utils_1.pop)(jsonSchema, "type");
      const anyOf = (0, utils_1.pop)(jsonSchema, "anyOf");
      const oneOf = (0, utils_1.pop)(jsonSchema, "oneOf");
      const allOf = (0, utils_1.pop)(jsonSchema, "allOf");
      if (Array.isArray(anyOf)) {
        strictSchema["anyOf"] = anyOf.map((variant) => _transformJSONSchema(variant));
      } else if (Array.isArray(oneOf)) {
        strictSchema["anyOf"] = oneOf.map((variant) => _transformJSONSchema(variant));
      } else if (Array.isArray(allOf)) {
        strictSchema["allOf"] = allOf.map((entry) => _transformJSONSchema(entry));
      } else {
        if (type === void 0) {
          throw new Error("JSON schema must have a type defined if anyOf/oneOf/allOf are not used");
        }
        strictSchema["type"] = type;
      }
      const description = (0, utils_1.pop)(jsonSchema, "description");
      if (description !== void 0) {
        strictSchema["description"] = description;
      }
      const title = (0, utils_1.pop)(jsonSchema, "title");
      if (title !== void 0) {
        strictSchema["title"] = title;
      }
      if (type === "object") {
        const properties = (0, utils_1.pop)(jsonSchema, "properties") || {};
        strictSchema["properties"] = Object.fromEntries(Object.entries(properties).map(([key, propSchema]) => [
          key,
          _transformJSONSchema(propSchema)
        ]));
        (0, utils_1.pop)(jsonSchema, "additionalProperties");
        strictSchema["additionalProperties"] = false;
        const required = (0, utils_1.pop)(jsonSchema, "required");
        if (required !== void 0) {
          strictSchema["required"] = required;
        }
      } else if (type === "string") {
        const format = (0, utils_1.pop)(jsonSchema, "format");
        if (format !== void 0 && SUPPORTED_STRING_FORMATS.has(format)) {
          strictSchema["format"] = format;
        } else if (format !== void 0) {
          jsonSchema["format"] = format;
        }
      } else if (type === "array") {
        const items = (0, utils_1.pop)(jsonSchema, "items");
        if (items !== void 0) {
          strictSchema["items"] = _transformJSONSchema(items);
        }
        const minItems = (0, utils_1.pop)(jsonSchema, "minItems");
        if (minItems !== void 0 && (minItems === 0 || minItems === 1)) {
          strictSchema["minItems"] = minItems;
        } else if (minItems !== void 0) {
          jsonSchema["minItems"] = minItems;
        }
      }
      if (Object.keys(jsonSchema).length > 0) {
        const existingDescription = strictSchema["description"];
        strictSchema["description"] = (existingDescription ? existingDescription + "\n\n" : "") + "{" + Object.entries(jsonSchema).map(([key, value]) => `${key}: ${JSON.stringify(value)}`).join(", ") + "}";
      }
      return strictSchema;
    }
  }
});

// node_modules/@anthropic-ai/sdk/helpers/beta/json-schema.js
var require_json_schema = __commonJS({
  "node_modules/@anthropic-ai/sdk/helpers/beta/json-schema.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.betaTool = betaTool;
    exports2.betaJSONSchemaOutputFormat = betaJSONSchemaOutputFormat;
    var __1 = require_sdk();
    var transform_json_schema_1 = require_transform_json_schema();
    function betaTool(options) {
      if (options.inputSchema.type !== "object") {
        throw new Error(`JSON schema for tool "${options.name}" must be an object, but got ${options.inputSchema.type}`);
      }
      return {
        type: "custom",
        name: options.name,
        input_schema: options.inputSchema,
        description: options.description,
        run: options.run,
        parse: (content) => content,
        ...options.close ? { close: options.close } : {}
      };
    }
    function betaJSONSchemaOutputFormat(jsonSchema, options) {
      if (jsonSchema.type !== "object") {
        throw new Error(`JSON schema for tool must be an object, but got ${jsonSchema.type}`);
      }
      const transform = options?.transform ?? true;
      if (transform) {
        jsonSchema = (0, transform_json_schema_1.transformJSONSchema)(jsonSchema);
      }
      return {
        type: "json_schema",
        schema: {
          ...jsonSchema
        },
        parse: (content) => {
          try {
            return JSON.parse(content);
          } catch (error) {
            throw new __1.AnthropicError(`Failed to parse structured output: ${error}`);
          }
        }
      };
    }
  }
});

// node_modules/@anthropic-ai/sdk/internal/utils/promise.js
var require_promise = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/utils/promise.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.promiseWithResolvers = promiseWithResolvers;
    function promiseWithResolvers() {
      let resolve;
      let reject;
      const promise = new Promise((res, rej) => {
        resolve = res;
        reject = rej;
      });
      return { promise, resolve, reject };
    }
  }
});

// node_modules/@anthropic-ai/sdk/tools/agent-toolset/fs-util.js
var require_fs_util = __commonJS({
  "node_modules/@anthropic-ai/sdk/tools/agent-toolset/fs-util.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.FILE_CREATE_MODE = exports2.DIR_CREATE_MODE = void 0;
    exports2.canonicalize = canonicalize;
    exports2.confineToRoot = confineToRoot;
    exports2.atomicWriteFile = atomicWriteFile;
    exports2.fsErrorMessage = fsErrorMessage;
    var tslib_1 = require_tslib();
    var fs = tslib_1.__importStar(require("fs/promises"));
    var path = tslib_1.__importStar(require("path"));
    var node_crypto_1 = require("crypto");
    var ToolError_1 = require_ToolError();
    exports2.DIR_CREATE_MODE = 493;
    exports2.FILE_CREATE_MODE = 420;
    async function realpathOrSelf(p) {
      try {
        return await fs.realpath(p);
      } catch {
        return p;
      }
    }
    async function canonicalize(abs) {
      const tail = [];
      let prefix = abs;
      for (; ; ) {
        let real;
        try {
          real = await fs.realpath(prefix);
        } catch {
          let isLink = false;
          try {
            isLink = (await fs.lstat(prefix)).isSymbolicLink();
          } catch {
          }
          if (isLink) {
            prefix = path.resolve(path.dirname(prefix), await fs.readlink(prefix));
            continue;
          }
          const parent = path.dirname(prefix);
          if (parent === prefix)
            return abs;
          tail.push(path.basename(prefix));
          prefix = parent;
          continue;
        }
        return tail.length ? path.join(real, ...tail.reverse()) : real;
      }
    }
    async function confineToRoot(root, p, opts) {
      const allowOutside = opts?.allowOutside ?? false;
      if (path.isAbsolute(p)) {
        if (!allowOutside) {
          throw new ToolError_1.ToolError(`absolute path ${JSON.stringify(p)} not permitted`);
        }
        return path.resolve(p);
      }
      const realRoot = await realpathOrSelf(path.resolve(root));
      const abs = path.resolve(realRoot, p);
      if (allowOutside)
        return abs;
      const real = await canonicalize(abs);
      const rootSep = realRoot.endsWith(path.sep) ? realRoot : realRoot + path.sep;
      if (real !== realRoot && !real.startsWith(rootSep)) {
        throw new ToolError_1.ToolError(`path ${JSON.stringify(p)} escapes workdir`);
      }
      return real;
    }
    async function atomicWriteFile(targetPath, content) {
      const dir = path.dirname(targetPath);
      const tempPath = path.join(dir, `.tmp-${process.pid}-${(0, node_crypto_1.randomUUID)()}`);
      let handle;
      try {
        handle = await fs.open(tempPath, "wx", exports2.FILE_CREATE_MODE);
        await handle.writeFile(content, "utf-8");
        await handle.sync();
        await handle.close();
        handle = void 0;
        await fs.rename(tempPath, targetPath);
      } catch (err) {
        if (handle)
          await handle.close().catch(() => {
          });
        await fs.unlink(tempPath).catch(() => {
        });
        throw err;
      }
    }
    function fsErrorMessage(err, file) {
      const code = err?.code;
      switch (code) {
        case "ENOENT":
          return `${file}: no such file or directory`;
        case "EACCES":
        case "EPERM":
          return `${file}: permission denied`;
        case "ENOTDIR":
          return `${file}: not a directory`;
        case "EISDIR":
          return `${file}: is a directory`;
        case "ELOOP":
          return `${file}: too many levels of symbolic links`;
        case "ENAMETOOLONG":
          return `${file}: file name too long`;
        case "ENOSPC":
          return `${file}: no space left on device`;
        case "EMFILE":
        case "ENFILE":
          return `${file}: too many open files`;
        default:
          return `${file}: ${err instanceof Error ? err.message : String(err)}`;
      }
    }
  }
});

// node_modules/@anthropic-ai/sdk/tools/agent-toolset/skills.js
var require_skills = __commonJS({
  "node_modules/@anthropic-ai/sdk/tools/agent-toolset/skills.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.setupSkills = setupSkills;
    exports2.resolveSkillVersion = resolveSkillVersion;
    exports2.extractSkillArchive = extractSkillArchive;
    var tslib_1 = require_tslib();
    var fs = tslib_1.__importStar(require("fs/promises"));
    var fssync = tslib_1.__importStar(require("fs"));
    var path = tslib_1.__importStar(require("path"));
    var node_child_process_1 = require("child_process");
    var node_util_1 = require("util");
    var node_stream_1 = require("stream");
    var promises_1 = require("stream/promises");
    var error_1 = require_error();
    var log_1 = require_log();
    var fs_util_1 = require_fs_util();
    var execFileAsync = (0, node_util_1.promisify)(node_child_process_1.execFile);
    async function setupSkills(ctx) {
      const { client, sessionId } = ctx;
      if (!client || !sessionId)
        return async () => {
        };
      const log = (0, log_1.loggerFor)(client);
      const session = await client.beta.sessions.retrieve(sessionId);
      const skillsRoot = path.resolve(ctx.workdir, "skills");
      const created = [];
      for (const skill of session.agent.skills) {
        try {
          const versionId = await resolveSkillVersion(client, skill.skill_id, skill.version);
          const version = await client.beta.skills.versions.retrieve(versionId, { skill_id: skill.skill_id });
          let dirname = path.basename(version.name.trim());
          if (dirname === "" || dirname === "." || dirname === "..")
            dirname = skill.skill_id;
          const dest = path.resolve(skillsRoot, dirname);
          if (dest !== skillsRoot && !dest.startsWith(skillsRoot + path.sep)) {
            log.warn("skill name escapes the skills dir; skipping", {
              component: "agent-tool-context",
              name: version.name
            });
            continue;
          }
          const resp = await client.beta.skills.versions.download(versionId, { skill_id: skill.skill_id });
          await fs.rm(dest, { recursive: true, force: true });
          await fs.mkdir(dest, { recursive: true, mode: fs_util_1.DIR_CREATE_MODE });
          created.push(dest);
          await extractSkillArchive(resp, dest);
          log.info("downloaded skill", {
            component: "agent-tool-context",
            skill_id: skill.skill_id,
            version: versionId,
            dest
          });
        } catch (e) {
          log.warn("failed to download skill", {
            component: "agent-tool-context",
            skill_id: skill.skill_id,
            error: String(e)
          });
        }
      }
      return async () => {
        for (const dest of created) {
          await fs.rm(dest, { recursive: true, force: true }).catch((e) => {
            log.warn("failed to clean up skill", { component: "agent-tool-context", dest, error: String(e) });
          });
        }
      };
    }
    async function resolveSkillVersion(client, skillId, version) {
      if (/^\d+$/.test(version))
        return version;
      let newest;
      for await (const v of client.beta.skills.versions.list(skillId)) {
        if (/^\d+$/.test(v.version) && (newest === void 0 || BigInt(v.version) > BigInt(newest))) {
          newest = v.version;
        }
      }
      if (newest === void 0) {
        throw new error_1.AnthropicError(`skill ${JSON.stringify(skillId)} has no concrete version to resolve ${JSON.stringify(version)} against`);
      }
      return newest;
    }
    function assertSafeMemberNames(names) {
      for (const raw of names.split("\n")) {
        const entry = raw.trim();
        if (!entry)
          continue;
        if (path.isAbsolute(entry) || entry.split(/[\\/]/).includes("..")) {
          throw new error_1.AnthropicError(`refusing to extract unsafe archive member: ${entry}`);
        }
      }
    }
    function assertNoSpecialMembers(verboseListing) {
      for (const line of verboseListing.split("\n")) {
        const type = line.trimStart()[0];
        if (type === "l" || type === "h" || type === "b" || type === "c" || type === "p" || type === "s") {
          throw new error_1.AnthropicError("refusing to extract archive with symlink/hardlink/device member");
        }
      }
    }
    async function runArchiveTool(cmd, args) {
      try {
        const { stdout } = await execFileAsync(cmd, args);
        return stdout;
      } catch (e) {
        if (e != null && typeof e === "object" && e.code === "ENOENT") {
          throw new error_1.AnthropicError(`skill extraction requires the \`${cmd}\` command, but it was not found on PATH`);
        }
        throw e;
      }
    }
    function archiveTopDir(listing) {
      let top;
      let nested = false;
      for (const raw of listing.split("\n")) {
        const parts = raw.trim().split("/").filter((p) => p !== "" && p !== ".");
        if (parts.length === 0)
          continue;
        const first = parts[0];
        if (top === void 0)
          top = first;
        else if (first !== top)
          return "";
        if (parts.length > 1)
          nested = true;
      }
      return top !== void 0 && nested ? top : "";
    }
    async function extractSkillArchive(resp, dest) {
      const tmp = path.join(dest, `.skill-archive-${process.pid}-${Date.now()}`);
      if (!resp.body) {
        throw new error_1.AnthropicError("skill download response had no body");
      }
      await (0, promises_1.pipeline)(node_stream_1.Readable.fromWeb(resp.body), fssync.createWriteStream(tmp));
      const stage = path.join(path.dirname(dest), `.skill-stage-${process.pid}-${Date.now()}`);
      try {
        const head = await readHead(tmp, 4);
        const isZip = head.length >= 4 && head[0] === 80 && head[1] === 75 && head[2] === 3 && head[3] === 4;
        const archiveCmd = isZip ? "unzip" : "tar";
        const listing = await runArchiveTool(archiveCmd, isZip ? ["-Z1", tmp] : ["-tf", tmp]);
        assertSafeMemberNames(listing);
        assertNoSpecialMembers(await runArchiveTool(archiveCmd, isZip ? ["-Z", tmp] : ["-tvf", tmp]));
        const top = archiveTopDir(listing);
        await fs.mkdir(stage, { recursive: true, mode: fs_util_1.DIR_CREATE_MODE });
        await runArchiveTool(archiveCmd, isZip ? ["-oq", tmp, "-d", stage] : ["-xf", tmp, "-C", stage]);
        const srcRoot = top ? path.join(stage, top) : stage;
        for (const entry of await fs.readdir(srcRoot)) {
          await fs.rename(path.join(srcRoot, entry), path.join(dest, entry));
        }
      } finally {
        await fs.rm(tmp, { force: true });
        await fs.rm(stage, { recursive: true, force: true });
      }
    }
    async function readHead(file, n) {
      const handle = await fs.open(file, "r");
      try {
        const buf = Buffer.alloc(n);
        const { bytesRead } = await handle.read(buf, 0, n, 0);
        return buf.subarray(0, bytesRead);
      } finally {
        await handle.close();
      }
    }
  }
});

// node_modules/@anthropic-ai/sdk/tools/agent-toolset/node.js
var require_node = __commonJS({
  "node_modules/@anthropic-ai/sdk/tools/agent-toolset/node.js"(exports2) {
    "use strict";
    var _BashSession_instances;
    var _BashSession_proc;
    var _BashSession_buf;
    var _BashSession_truncated;
    var _BashSession_closed;
    var _BashSession_waiting;
    var _BashSession_append;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.BashSession = exports2.extractSkillArchive = exports2.resolveSkillVersion = exports2.setupSkills = void 0;
    exports2.betaAgentToolset20260401 = betaAgentToolset20260401;
    exports2.resolvePath = resolvePath;
    exports2.betaBashTool = betaBashTool;
    exports2.betaReadTool = betaReadTool;
    exports2.betaWriteTool = betaWriteTool;
    exports2.betaEditTool = betaEditTool;
    exports2.betaGlobTool = betaGlobTool;
    exports2.betaGrepTool = betaGrepTool;
    var tslib_1 = require_tslib();
    var fs = tslib_1.__importStar(require("fs/promises"));
    var fssync = tslib_1.__importStar(require("fs"));
    var path = tslib_1.__importStar(require("path"));
    var cp = tslib_1.__importStar(require("child_process"));
    var crypto = tslib_1.__importStar(require("crypto"));
    var readline = tslib_1.__importStar(require("readline"));
    var error_1 = require_error();
    var ToolError_1 = require_ToolError();
    var json_schema_1 = require_json_schema();
    var promise_1 = require_promise();
    var fs_util_1 = require_fs_util();
    var skills_1 = require_skills();
    Object.defineProperty(exports2, "setupSkills", { enumerable: true, get: function() {
      return skills_1.setupSkills;
    } });
    Object.defineProperty(exports2, "resolveSkillVersion", { enumerable: true, get: function() {
      return skills_1.resolveSkillVersion;
    } });
    Object.defineProperty(exports2, "extractSkillArchive", { enumerable: true, get: function() {
      return skills_1.extractSkillArchive;
    } });
    var BASH_OUTPUT_LIMIT = 100 * 1024;
    var BASH_DEFAULT_TIMEOUT_MS = 12e4;
    var DEFAULT_MAX_FILE_BYTES = 256 * 1024;
    var GREP_OUTPUT_LIMIT = 100 * 1024;
    var GREP_MAX_LINE_LENGTH = 2e3;
    var GLOB_RESULT_LIMIT = 200;
    var ANSI_RE = /\x1b\[[0-9;?]*[ -/]*[@-~]/g;
    var fsGlob = fs.glob;
    function resolveMaxBytes(configured) {
      return configured === void 0 ? DEFAULT_MAX_FILE_BYTES : configured;
    }
    function betaAgentToolset20260401(ctx) {
      return [
        betaBashTool(ctx),
        betaReadTool(ctx),
        betaWriteTool(ctx),
        betaEditTool(ctx),
        betaGlobTool(ctx),
        betaGrepTool(ctx)
      ];
    }
    function resolvePath(ctx, p) {
      return (0, fs_util_1.confineToRoot)(ctx.workdir, p, { allowOutside: ctx.unrestrictedPaths ?? false });
    }
    function scrubbedShellEnv() {
      const env = {};
      for (const [key, value] of Object.entries(process.env)) {
        if (key.startsWith("ANTHROPIC_"))
          continue;
        env[key] = value;
      }
      return env;
    }
    var BashSession = class {
      constructor(dir, env = scrubbedShellEnv()) {
        _BashSession_instances.add(this);
        _BashSession_proc.set(this, void 0);
        _BashSession_buf.set(this, "");
        _BashSession_truncated.set(this, false);
        _BashSession_closed.set(this, false);
        _BashSession_waiting.set(this, null);
        tslib_1.__classPrivateFieldSet(this, _BashSession_proc, cp.spawn("/bin/bash", ["--noprofile", "--norc"], {
          cwd: dir,
          // `env` is the full base environment (the scrubbed process env by
          // default, or the verbatim replacement from `AgentToolContext.env`).
          // PS1/PS2/TERM are shell-control settings BashSession always applies so
          // the pipe-based sentinel exec parsing works — not part of the
          // user-facing environment.
          env: { ...env, PS1: "", PS2: "", TERM: "dumb" },
          stdio: ["pipe", "pipe", "pipe"],
          detached: true
        }), "f");
        tslib_1.__classPrivateFieldGet(this, _BashSession_proc, "f").stdout.setEncoding("utf8");
        tslib_1.__classPrivateFieldGet(this, _BashSession_proc, "f").stderr.setEncoding("utf8");
        tslib_1.__classPrivateFieldGet(this, _BashSession_proc, "f").stdout.on("data", (d) => tslib_1.__classPrivateFieldGet(this, _BashSession_instances, "m", _BashSession_append).call(this, d));
        tslib_1.__classPrivateFieldGet(this, _BashSession_proc, "f").stderr.on("data", (d) => tslib_1.__classPrivateFieldGet(this, _BashSession_instances, "m", _BashSession_append).call(this, d));
        tslib_1.__classPrivateFieldGet(this, _BashSession_proc, "f").once("close", () => {
          tslib_1.__classPrivateFieldSet(this, _BashSession_closed, true, "f");
          const w = tslib_1.__classPrivateFieldGet(this, _BashSession_waiting, "f");
          tslib_1.__classPrivateFieldSet(this, _BashSession_waiting, null, "f");
          w?.resolve();
        });
      }
      /** Whether the underlying shell process has exited. */
      get closed() {
        return tslib_1.__classPrivateFieldGet(this, _BashSession_closed, "f");
      }
      async exec(command, opts = {}) {
        if (tslib_1.__classPrivateFieldGet(this, _BashSession_closed, "f")) {
          throw new error_1.AnthropicError("bash session terminated");
        }
        const timeoutMs = opts.timeoutMs ?? BASH_DEFAULT_TIMEOUT_MS;
        const signal = opts.signal;
        if (signal?.aborted) {
          throw new error_1.AnthropicError("bash command aborted");
        }
        tslib_1.__classPrivateFieldSet(this, _BashSession_buf, "", "f");
        tslib_1.__classPrivateFieldSet(this, _BashSession_truncated, false, "f");
        const sentinel = `__ANT_CMD_${crypto.randomUUID()}_DONE__`;
        const sentinelSplit = `${sentinel.slice(0, 8)}''${sentinel.slice(8)}`;
        const wrapped = `{ ${command}
} </dev/null 2>&1; printf '\\n${sentinelSplit}%d\\n' $?
`;
        tslib_1.__classPrivateFieldGet(this, _BashSession_proc, "f").stdin.write(wrapped);
        if (tslib_1.__classPrivateFieldGet(this, _BashSession_buf, "f").indexOf(sentinel) < 0) {
          const { promise: sentinelSeen, resolve } = (0, promise_1.promiseWithResolvers)();
          tslib_1.__classPrivateFieldSet(this, _BashSession_waiting, { sentinel, resolve }, "f");
          let timer;
          let onAbort;
          try {
            await Promise.race([
              sentinelSeen,
              new Promise((_, reject) => {
                timer = setTimeout(() => reject(new error_1.AnthropicError(`bash command timed out after ${timeoutMs}ms`)), timeoutMs);
              }),
              new Promise((_, reject) => {
                if (!signal)
                  return;
                onAbort = () => reject(new error_1.AnthropicError("bash command aborted"));
                signal.addEventListener("abort", onAbort, { once: true });
              })
            ]);
          } finally {
            if (timer)
              clearTimeout(timer);
            if (onAbort && signal)
              signal.removeEventListener("abort", onAbort);
            tslib_1.__classPrivateFieldSet(this, _BashSession_waiting, null, "f");
          }
        }
        const idx = tslib_1.__classPrivateFieldGet(this, _BashSession_buf, "f").indexOf(sentinel);
        if (idx < 0) {
          throw new error_1.AnthropicError("bash session terminated");
        }
        const tail = tslib_1.__classPrivateFieldGet(this, _BashSession_buf, "f").slice(idx + sentinel.length);
        const m = tail.match(/^(-?\d+)/);
        const exitCode = m ? parseInt(m[1], 10) : -1;
        let out = tslib_1.__classPrivateFieldGet(this, _BashSession_buf, "f").slice(0, idx).replace(ANSI_RE, "").replace(/\n+$/, "");
        if (tslib_1.__classPrivateFieldGet(this, _BashSession_truncated, "f")) {
          out = `[output truncated]
${out}`;
        }
        return { output: out, exitCode };
      }
      close() {
        if (tslib_1.__classPrivateFieldGet(this, _BashSession_closed, "f"))
          return;
        tslib_1.__classPrivateFieldSet(this, _BashSession_closed, true, "f");
        const w = tslib_1.__classPrivateFieldGet(this, _BashSession_waiting, "f");
        tslib_1.__classPrivateFieldSet(this, _BashSession_waiting, null, "f");
        w?.resolve();
        tslib_1.__classPrivateFieldGet(this, _BashSession_proc, "f").stdout.destroy();
        tslib_1.__classPrivateFieldGet(this, _BashSession_proc, "f").stderr.destroy();
        tslib_1.__classPrivateFieldGet(this, _BashSession_proc, "f").stdin.destroy();
        try {
          process.kill(-tslib_1.__classPrivateFieldGet(this, _BashSession_proc, "f").pid, "SIGKILL");
        } catch {
          tslib_1.__classPrivateFieldGet(this, _BashSession_proc, "f").kill("SIGKILL");
        }
        tslib_1.__classPrivateFieldGet(this, _BashSession_proc, "f").unref();
      }
    };
    exports2.BashSession = BashSession;
    _BashSession_proc = /* @__PURE__ */ new WeakMap(), _BashSession_buf = /* @__PURE__ */ new WeakMap(), _BashSession_truncated = /* @__PURE__ */ new WeakMap(), _BashSession_closed = /* @__PURE__ */ new WeakMap(), _BashSession_waiting = /* @__PURE__ */ new WeakMap(), _BashSession_instances = /* @__PURE__ */ new WeakSet(), _BashSession_append = function _BashSession_append2(d) {
      tslib_1.__classPrivateFieldSet(this, _BashSession_buf, tslib_1.__classPrivateFieldGet(this, _BashSession_buf, "f") + d, "f");
      if (tslib_1.__classPrivateFieldGet(this, _BashSession_buf, "f").length > BASH_OUTPUT_LIMIT) {
        tslib_1.__classPrivateFieldSet(this, _BashSession_buf, tslib_1.__classPrivateFieldGet(this, _BashSession_buf, "f").slice(tslib_1.__classPrivateFieldGet(this, _BashSession_buf, "f").length - BASH_OUTPUT_LIMIT), "f");
        tslib_1.__classPrivateFieldSet(this, _BashSession_truncated, true, "f");
      }
      if (tslib_1.__classPrivateFieldGet(this, _BashSession_waiting, "f") && tslib_1.__classPrivateFieldGet(this, _BashSession_buf, "f").indexOf(tslib_1.__classPrivateFieldGet(this, _BashSession_waiting, "f").sentinel) >= 0) {
        const w = tslib_1.__classPrivateFieldGet(this, _BashSession_waiting, "f");
        tslib_1.__classPrivateFieldSet(this, _BashSession_waiting, null, "f");
        w.resolve();
      }
    };
    function betaBashTool(ctx) {
      let session;
      let tail = Promise.resolve();
      return (0, json_schema_1.betaTool)({
        name: "bash",
        description: "Run a bash command in a persistent shell. State (cwd, env vars) persists across calls.",
        inputSchema: {
          type: "object",
          properties: {
            command: { type: "string", description: "The command to run" },
            restart: { type: "boolean", description: "Restart the persistent shell before running" },
            timeout_ms: { type: "integer", description: "Per-call timeout in milliseconds" }
          }
        },
        run: async ({ command, restart, timeout_ms }, context) => {
          const prev = tail;
          const gate = (0, promise_1.promiseWithResolvers)();
          tail = gate.promise;
          try {
            await prev;
          } catch {
          }
          try {
            if (restart) {
              session?.close();
              session = void 0;
            }
            if (!command) {
              if (restart)
                return "bash session restarted";
              throw new ToolError_1.ToolError("bash: command is required");
            }
            session ?? (session = new BashSession(ctx.workdir, ctx.env));
            try {
              const { output, exitCode } = await session.exec(command, {
                timeoutMs: timeout_ms ?? BASH_DEFAULT_TIMEOUT_MS,
                signal: context?.signal
              });
              if (exitCode !== 0)
                throw new ToolError_1.ToolError(output || `exit ${exitCode}`);
              return output;
            } catch (e) {
              if (e instanceof ToolError_1.ToolError)
                throw e;
              session.close();
              session = void 0;
              throw new ToolError_1.ToolError(`bash: ${e instanceof Error ? e.message : String(e)}`);
            }
          } finally {
            gate.resolve();
          }
        },
        close: () => {
          session?.close();
          session = void 0;
        }
      });
    }
    function betaReadTool(ctx) {
      return (0, json_schema_1.betaTool)({
        name: "read",
        description: "Read a UTF-8 text file relative to the workdir.",
        inputSchema: {
          type: "object",
          properties: {
            file_path: { type: "string" },
            view_range: {
              type: "array",
              items: { type: "integer" },
              description: "[start_line, end_line] 1-indexed inclusive"
            }
          },
          required: ["file_path"]
        },
        run: async ({ file_path, view_range }) => {
          if (!file_path)
            throw new ToolError_1.ToolError("read: file_path is required");
          const abs = await resolvePath(ctx, file_path);
          let data;
          try {
            const st = await fs.stat(abs);
            if (!st.isFile()) {
              throw new ToolError_1.ToolError(`read: ${file_path} is not a regular file`);
            }
            const limit = resolveMaxBytes(ctx.maxFileBytes);
            if (limit !== null && st.size > limit) {
              throw new ToolError_1.ToolError(`read: ${file_path} is ${st.size} bytes, exceeds ${limit}-byte limit. Use bash (head/tail/sed) to read a slice.`);
            }
            data = await fs.readFile(abs, "utf8");
          } catch (e) {
            if (e instanceof ToolError_1.ToolError)
              throw e;
            throw new ToolError_1.ToolError(`read: ${(0, fs_util_1.fsErrorMessage)(e, file_path)}`);
          }
          if (!view_range)
            return data;
          if (view_range.length !== 2)
            throw new ToolError_1.ToolError("read: view_range must be [start_line, end_line]");
          const [startLine, endLine] = view_range;
          const lines = data.split("\n");
          const start = Math.max(0, startLine - 1);
          const end = endLine > 0 ? endLine : lines.length;
          return lines.slice(start, end).join("\n");
        }
      });
    }
    function betaWriteTool(ctx) {
      return (0, json_schema_1.betaTool)({
        name: "write",
        description: "Write a UTF-8 text file relative to the workdir, creating parent directories as needed.",
        inputSchema: {
          type: "object",
          properties: { file_path: { type: "string" }, content: { type: "string" } },
          required: ["file_path", "content"]
        },
        run: async ({ file_path, content }) => {
          if (!file_path)
            throw new ToolError_1.ToolError("write: file_path is required");
          const abs = await resolvePath(ctx, file_path);
          try {
            await fs.mkdir(path.dirname(abs), { recursive: true, mode: fs_util_1.DIR_CREATE_MODE });
            await (0, fs_util_1.atomicWriteFile)(abs, content ?? "");
          } catch (e) {
            throw new ToolError_1.ToolError(`write: ${(0, fs_util_1.fsErrorMessage)(e, file_path)}`);
          }
          return `wrote ${Buffer.byteLength(content ?? "")} bytes to ${file_path}`;
        }
      });
    }
    function betaEditTool(ctx) {
      return (0, json_schema_1.betaTool)({
        name: "edit",
        description: "Replace old_string with new_string in a file. old_string must be unique unless replace_all.",
        inputSchema: {
          type: "object",
          properties: {
            file_path: { type: "string" },
            old_string: { type: "string" },
            new_string: { type: "string" },
            replace_all: { type: "boolean" }
          },
          required: ["file_path", "old_string", "new_string"]
        },
        run: async ({ file_path, old_string, new_string, replace_all }) => {
          if (!file_path)
            throw new ToolError_1.ToolError("edit: file_path is required");
          if (!old_string)
            throw new ToolError_1.ToolError("edit: old_string is required");
          const abs = await resolvePath(ctx, file_path);
          let data;
          try {
            const st = await fs.stat(abs);
            if (!st.isFile()) {
              throw new ToolError_1.ToolError(`edit: ${file_path} is not a regular file`);
            }
            const limit = resolveMaxBytes(ctx.maxFileBytes);
            if (limit !== null && st.size > limit) {
              throw new ToolError_1.ToolError(`edit: ${file_path} is ${st.size} bytes, exceeds ${limit}-byte limit. Use bash (sed/awk) to edit a large file.`);
            }
            data = await fs.readFile(abs, "utf8");
          } catch (e) {
            if (e instanceof ToolError_1.ToolError)
              throw e;
            throw new ToolError_1.ToolError(`edit: ${(0, fs_util_1.fsErrorMessage)(e, file_path)}`);
          }
          const count = data.split(old_string).length - 1;
          if (count === 0)
            throw new ToolError_1.ToolError(`edit: old_string not found in ${file_path}`);
          let updated;
          if (replace_all) {
            updated = data.split(old_string).join(new_string);
          } else {
            if (count > 1)
              throw new ToolError_1.ToolError(`edit: old_string appears ${count} times in ${file_path} (must be unique)`);
            updated = data.replace(old_string, () => new_string);
          }
          try {
            await (0, fs_util_1.atomicWriteFile)(abs, updated);
          } catch (e) {
            throw new ToolError_1.ToolError(`edit: write: ${(0, fs_util_1.fsErrorMessage)(e, file_path)}`);
          }
          return `edited ${file_path} (${replace_all ? count : 1} replacement(s))`;
        }
      });
    }
    function betaGlobTool(ctx) {
      return (0, json_schema_1.betaTool)({
        name: "glob",
        description: "Match files under the workdir against a glob pattern. Results are mtime-sorted, newest first.",
        inputSchema: {
          type: "object",
          properties: {
            pattern: { type: "string" },
            path: { type: "string", description: "Directory to search in. Defaults to the workdir." }
          },
          required: ["pattern"]
        },
        run: async ({ pattern, path: searchPath }) => {
          if (!pattern)
            throw new ToolError_1.ToolError("glob: pattern is required");
          let root = path.resolve(ctx.workdir);
          let pat = pattern;
          if (path.isAbsolute(pattern)) {
            if (!ctx.unrestrictedPaths)
              throw new ToolError_1.ToolError("glob: absolute pattern not permitted");
            root = path.parse(pattern).root;
            pat = path.relative(root, pattern);
          } else if (searchPath) {
            root = await resolvePath(ctx, searchPath);
          }
          if (!ctx.unrestrictedPaths && pat.split(/[\\/]/).includes("..")) {
            throw new ToolError_1.ToolError('glob: ".." is not permitted in the pattern');
          }
          const matches = [];
          try {
            for await (const entry of fsGlob(pat, {
              cwd: root,
              withFileTypes: true,
              exclude: (d) => d.name === ".git" || d.name === "node_modules"
            })) {
              if (!entry.isFile())
                continue;
              const full = path.join(entry.parentPath, entry.name);
              if (!ctx.unrestrictedPaths && !isWithin(root, full))
                continue;
              let mtime = 0;
              try {
                mtime = (await fs.stat(full)).mtimeMs;
              } catch {
              }
              matches.push({ path: full, mtime });
            }
          } catch (e) {
            throw new ToolError_1.ToolError(`glob: ${e instanceof Error ? e.message : String(e)}`);
          }
          if (matches.length === 0)
            return "no matches";
          matches.sort((a, b) => b.mtime - a.mtime);
          return matches.slice(0, GLOB_RESULT_LIMIT).map((m) => m.path).join("\n");
        }
      });
    }
    function betaGrepTool(ctx) {
      return (0, json_schema_1.betaTool)({
        name: "grep",
        description: "Search file contents for a regex. Uses ripgrep if available, otherwise a built-in walker.",
        inputSchema: {
          type: "object",
          properties: { pattern: { type: "string" }, path: { type: "string" } },
          required: ["pattern"]
        },
        run: async ({ pattern, path: p }, context) => {
          if (!pattern)
            throw new ToolError_1.ToolError("grep: pattern is required");
          let searchPath = path.resolve(ctx.workdir);
          if (p)
            searchPath = await resolvePath(ctx, p);
          const rg = await findRg();
          return rg ? runRipgrep(rg, pattern, searchPath, context?.signal) : runWalkGrep(pattern, searchPath, context?.signal);
        }
      });
    }
    function runRipgrep(rg, pattern, searchPath, signal) {
      return new Promise((resolve, reject) => {
        const proc = cp.spawn(rg, ["-n", "--no-heading", "-e", pattern, "--", searchPath], {
          ...signal ? { signal } : {}
        });
        let out = "";
        let errOut = "";
        let truncated = false;
        proc.stdout.on("data", (d) => {
          if (truncated)
            return;
          out += d;
          if (out.length > GREP_OUTPUT_LIMIT) {
            truncated = true;
            out = out.slice(0, GREP_OUTPUT_LIMIT);
            proc.kill("SIGKILL");
          }
        });
        proc.stderr.on("data", (d) => errOut += d);
        proc.on("close", (code) => {
          if (signal?.aborted)
            return reject(new ToolError_1.ToolError("grep: aborted"));
          if (truncated)
            return resolve(out + `
[output truncated at ${GREP_OUTPUT_LIMIT} bytes]`);
          if (code === 0)
            return resolve(out);
          if (code === 1)
            return resolve("no matches");
          reject(new ToolError_1.ToolError(`grep: rg failed: ${errOut || `exit ${code}`}`));
        });
        proc.on("error", (e) => {
          if (signal?.aborted)
            return reject(new ToolError_1.ToolError("grep: aborted"));
          reject(new ToolError_1.ToolError(`grep: rg failed: ${e.message}`));
        });
      });
    }
    async function runWalkGrep(pattern, root, signal) {
      let re;
      try {
        re = new RegExp(pattern);
      } catch (e) {
        throw new ToolError_1.ToolError(`grep: invalid regex: ${e instanceof Error ? e.message : String(e)}`);
      }
      const hits = [];
      let budget = GREP_OUTPUT_LIMIT;
      const push = (line) => {
        budget -= line.length + 1;
        if (budget < 0) {
          hits.push(`[output truncated at ${GREP_OUTPUT_LIMIT} bytes]`);
          return false;
        }
        hits.push(line);
        return true;
      };
      const stat = await fs.stat(root).catch(() => null);
      if (stat?.isFile()) {
        await grepFile(root, re, push);
      } else {
        await walk(root, "", (rel) => grepFile(path.join(root, rel), re, push), signal);
      }
      if (signal?.aborted)
        throw new ToolError_1.ToolError("grep: aborted");
      if (hits.length === 0)
        return "no matches";
      return hits.join("\n");
    }
    async function grepFile(file, re, push) {
      const stream = fssync.createReadStream(file, { encoding: "utf8" });
      const rl = readline.createInterface({ input: stream, crlfDelay: Infinity });
      let i = 0;
      try {
        for await (const line of rl) {
          i++;
          if (line.length > GREP_MAX_LINE_LENGTH)
            continue;
          if (re.test(line) && !push(`${file}:${i}:${line}`))
            return false;
        }
      } catch {
      } finally {
        stream.destroy();
      }
      return true;
    }
    function isWithin(root, p) {
      const rel = path.relative(root, p);
      return rel === "" || !rel.startsWith(".." + path.sep) && rel !== ".." && !path.isAbsolute(rel);
    }
    var WALK_MAX_DEPTH = 40;
    var WALK_MAX_ENTRIES = 5e4;
    async function walk(root, rel, fn, signal) {
      let remaining = WALK_MAX_ENTRIES;
      async function inner(rel2, depth) {
        if (depth > WALK_MAX_DEPTH)
          return true;
        if (signal?.aborted)
          return false;
        let entries;
        try {
          entries = await fs.readdir(path.join(root, rel2), { withFileTypes: true });
        } catch {
          return true;
        }
        for (const e of entries) {
          if (e.name === ".git" || e.name === "node_modules")
            continue;
          if (remaining-- <= 0)
            return false;
          if (signal?.aborted)
            return false;
          const childRel = rel2 ? path.join(rel2, e.name) : e.name;
          if (e.isDirectory()) {
            if (!await inner(childRel, depth + 1))
              return false;
          } else if (e.isFile()) {
            if (await fn(childRel) === false)
              return false;
          }
        }
        return true;
      }
      await inner(rel, 0);
    }
    async function findRg() {
      const dirs = (process.env["PATH"] ?? "").split(path.delimiter);
      for (const d of dirs) {
        const candidate = path.join(d, "rg");
        try {
          await fs.access(candidate, fssync.constants.X_OK);
          return candidate;
        } catch {
        }
      }
      return null;
    }
  }
});

// node_modules/@anthropic-ai/sdk/lib/environments/worker.js
var require_worker = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/environments/worker.js"(exports2) {
    "use strict";
    var _EnvironmentWorker_instances;
    var _EnvironmentWorker_signal;
    var _EnvironmentWorker_handleItem;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.EnvironmentWorker = void 0;
    var tslib_1 = require_tslib();
    var error_1 = require_error();
    var log_1 = require_log();
    var env_1 = require_env();
    var sleep_1 = require_sleep();
    var backoff_1 = require_backoff();
    var abort_1 = require_abort();
    var headers_1 = require_headers();
    var SessionToolRunner_1 = require_SessionToolRunner();
    var poller_1 = require_poller();
    var helper_client_1 = require_helper_client();
    var HEARTBEAT_DEFAULT_MS = 3e4;
    var NO_HEARTBEAT_SENTINEL = "NO_HEARTBEAT";
    var EnvironmentWorker = class {
      constructor(opts) {
        _EnvironmentWorker_instances.add(this);
        _EnvironmentWorker_signal.set(this, void 0);
        this.client = opts.client;
        this.environmentId = opts.environmentId;
        this.environmentKey = opts.environmentKey;
        this.tools = opts.tools;
        this.workdir = opts.workdir ?? process.cwd();
        this.unrestrictedPaths = opts.unrestrictedPaths;
        this.maxFileBytes = opts.maxFileBytes;
        this.maxIdleMs = opts.maxIdleMs;
        this.workerId = opts.workerId;
        this.requestOptions = opts.requestOptions;
        tslib_1.__classPrivateFieldSet(this, _EnvironmentWorker_signal, opts.signal, "f");
      }
      /**
       * Poll the environment and service each claimed session until the supplied
       * signal (or the one passed to the constructor) aborts. Throws if
       * `environmentId` / `environmentKey` were not provided to the constructor.
       */
      async run(signal) {
        const { environmentId, environmentKey } = this;
        if (environmentId === void 0 || environmentKey === void 0) {
          throw new error_1.AnthropicError("EnvironmentWorker.run: environmentId and environmentKey are required to poll for work");
        }
        const externalSignal = signal ?? tslib_1.__classPrivateFieldGet(this, _EnvironmentWorker_signal, "f");
        const poller = new poller_1.WorkPoller({
          client: this.client,
          environmentId,
          environmentKey,
          ...this.workerId !== void 0 ? { workerId: this.workerId } : {},
          ...externalSignal ? { signal: externalSignal } : {},
          ...this.requestOptions !== void 0 ? { requestOptions: this.requestOptions } : {},
          // The per-item handler force-stops every work item on exit; let it be the
          // single owner of `work.stop` rather than double-posting from the poller.
          autoStop: false
        });
        for await (const work of poller) {
          await tslib_1.__classPrivateFieldGet(this, _EnvironmentWorker_instances, "m", _EnvironmentWorker_handleItem).call(this, work, environmentKey, poller.signal);
        }
      }
      /**
       * Service a single, already-claimed work item without the poll loop: build the
       * per-session {@link AgentToolContext} (workdir from this worker's options),
       * download the session agent's skills (`setupSkills`), run a
       * {@link SessionToolRunner} for the session while heartbeating the work-item
       * lease in parallel, and force-stop the work item on exit (whether the runner
       * finishes normally, throws, or the heartbeat loop signals shutdown).
       *
       * Use this when something else does the claiming — e.g. a `worker poll
       * --on-work` script that hands an already-claimed item to a fresh process. The
       * work id / environment id / session id each fall back to `ANTHROPIC_WORK_ID` /
       * `ANTHROPIC_ENVIRONMENT_ID` / `ANTHROPIC_SESSION_ID` (the env vars that
       * command sets) when not passed; the environment key resolves from this
       * option, then the worker's own `environmentKey`, then
       * `ANTHROPIC_ENVIRONMENT_KEY`. With no arguments inside that command it just
       * works. Throws a clear error naming the first of the four required values
       * still missing after resolution.
       */
      async handleItem(opts) {
        const workId = opts?.workId ?? (0, env_1.readEnv)("ANTHROPIC_WORK_ID");
        const environmentId = opts?.environmentId ?? (0, env_1.readEnv)("ANTHROPIC_ENVIRONMENT_ID");
        const sessionId = opts?.sessionId ?? (0, env_1.readEnv)("ANTHROPIC_SESSION_ID");
        const environmentKey = opts?.environmentKey ?? this.environmentKey ?? (0, env_1.readEnv)("ANTHROPIC_ENVIRONMENT_KEY");
        if (!workId) {
          throw new error_1.AnthropicError("handleItem: workId is required \u2014 pass it or set ANTHROPIC_WORK_ID");
        }
        if (!environmentId) {
          throw new error_1.AnthropicError("handleItem: environmentId is required \u2014 pass it or set ANTHROPIC_ENVIRONMENT_ID");
        }
        if (!sessionId) {
          throw new error_1.AnthropicError("handleItem: sessionId is required \u2014 pass it or set ANTHROPIC_SESSION_ID");
        }
        if (!environmentKey) {
          throw new error_1.AnthropicError("handleItem: environmentKey is required \u2014 pass it, construct the worker with it, or set ANTHROPIC_ENVIRONMENT_KEY");
        }
        const work = {
          id: workId,
          environment_id: environmentId,
          data: { type: "session", id: sessionId }
        };
        await tslib_1.__classPrivateFieldGet(this, _EnvironmentWorker_instances, "m", _EnvironmentWorker_handleItem).call(this, work, environmentKey, opts?.signal ?? tslib_1.__classPrivateFieldGet(this, _EnvironmentWorker_signal, "f"));
      }
    };
    exports2.EnvironmentWorker = EnvironmentWorker;
    _EnvironmentWorker_signal = /* @__PURE__ */ new WeakMap(), _EnvironmentWorker_instances = /* @__PURE__ */ new WeakSet(), _EnvironmentWorker_handleItem = /**
     * The per-item body shared by {@link EnvironmentWorker.run}'s poll loop and
     * {@link EnvironmentWorker.handleItem}: run a {@link SessionToolRunner} for the
     * work item's session while heartbeating its lease, force-stopping on exit.
     * Non-session work items are ignored.
     */
    async function _EnvironmentWorker_handleItem2(work, environmentKey, externalSignal) {
      const log = (0, log_1.loggerFor)(this.client);
      const sessionClient = (0, helper_client_1.copyClientForHelper)(this.client, {
        authToken: environmentKey,
        helper: "environments-worker"
      });
      const sessionId = work.data.id;
      const ctx = {
        workdir: this.workdir,
        client: this.client,
        sessionId,
        ...this.unrestrictedPaths !== void 0 ? { unrestrictedPaths: this.unrestrictedPaths } : {},
        ...this.maxFileBytes !== void 0 ? { maxFileBytes: this.maxFileBytes } : {}
      };
      const agentToolset = await Promise.resolve().then(() => tslib_1.__importStar(require_node()));
      let cleanupSkills = async () => {
      };
      try {
        cleanupSkills = await agentToolset.setupSkills(ctx);
      } catch (e) {
        log.warn("skill setup failed", { session_id: sessionId, work_id: work.id, error: String(e) });
      }
      const tools = typeof this.tools === "function" ? this.tools(ctx) : this.tools ?? agentToolset.betaAgentToolset20260401(ctx);
      const ctrl = new AbortController();
      const detachExternal = (0, abort_1.linkAbort)(externalSignal, ctrl);
      const heartbeatPromise = heartbeatLoop(sessionClient, work, ctrl, log, this.requestOptions).catch((e) => {
        if (!ctrl.signal.aborted)
          log.error("heartbeat loop failed", { work_id: work.id, error: String(e) });
        ctrl.abort();
      });
      try {
        const runner = new SessionToolRunner_1.SessionToolRunner(sessionId, {
          client: sessionClient,
          tools,
          ...this.maxIdleMs !== void 0 ? { maxIdleMs: this.maxIdleMs } : {},
          ...this.requestOptions !== void 0 ? { requestOptions: this.requestOptions } : {},
          signal: ctrl.signal
        });
        for await (const _ of runner) {
        }
      } finally {
        ctrl.abort();
        detachExternal();
        await heartbeatPromise;
        await cleanupSkills().catch((e) => {
          log.warn("skill cleanup failed", { session_id: sessionId, work_id: work.id, error: String(e) });
        });
        await forceStop(sessionClient, work, log, this.requestOptions);
      }
    };
    async function forceStop(client, work, log, requestOptions) {
      try {
        await client.beta.environments.work.stop(
          work.id,
          { environment_id: work.environment_id, force: true },
          // Caller's headers pass through; the helper-tag header is on the scoped
          // sub-client's default_headers via copyClientForHelper, so no per-call
          // re-stamping needed.
          { ...requestOptions, headers: (0, headers_1.buildHeaders)([requestOptions?.headers]) }
        );
      } catch (e) {
        if (!(0, backoff_1.isStatus)(e, 409)) {
          log.error("force-stop on exit failed", { work_id: work.id, error: String(e) });
        }
      }
    }
    async function heartbeatLoop(client, work, ctrl, logger, requestOptions) {
      let intervalMs = HEARTBEAT_DEFAULT_MS;
      let last = NO_HEARTBEAT_SENTINEL;
      const beat = async () => {
        try {
          const resp = await client.beta.environments.work.heartbeat(work.id, { environment_id: work.environment_id, expected_last_heartbeat: last }, { ...requestOptions, headers: (0, headers_1.buildHeaders)([requestOptions?.headers]), signal: ctrl.signal });
          last = resp.last_heartbeat;
          if (resp.ttl_seconds > 0) {
            intervalMs = Math.max(1e3, Math.min(resp.ttl_seconds * 1e3 / 2, HEARTBEAT_DEFAULT_MS));
          }
          if (resp.state === "stopping" || resp.state === "stopped") {
            logger.info("heartbeat signals shutdown", { work_id: work.id, state: resp.state });
            ctrl.abort();
          }
          if (!resp.lease_extended) {
            logger.warn("lease not extended, shutting down", { work_id: work.id });
            ctrl.abort();
          }
        } catch (e) {
          ctrl.signal.throwIfAborted();
          if ((0, backoff_1.isFatal4xx)(e)) {
            logger.error("permanent heartbeat failure", { work_id: work.id, error: String(e) });
            ctrl.abort();
            throw e;
          }
          logger.warn("transient heartbeat failure", { work_id: work.id, error: String(e) });
        }
      };
      await beat();
      while (!ctrl.signal.aborted) {
        await (0, sleep_1.sleep)(intervalMs, ctrl.signal);
        ctrl.signal.throwIfAborted();
        await beat();
      }
    }
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/environments/work.js
var require_work = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/environments/work.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.EnvironmentWorker = exports2.WorkPoller = exports2.Work = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var poller_1 = require_poller();
    var worker_1 = require_worker();
    var Work = class extends resource_1.APIResource {
      /**
       * Note: these endpoints are called automatically by the pre-built environment
       * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
       * sandbox environments. They are included here as a reference; you do not need to
       * invoke them directly.
       *
       * Retrieve detailed information about a specific work item.
       *
       * @example
       * ```ts
       * const betaSelfHostedWork =
       *   await client.beta.environments.work.retrieve('work_id', {
       *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
       *   });
       * ```
       */
      retrieve(workID, params, options) {
        const { environment_id, betas } = params;
        return this._client.get((0, path_1.path)`/v1/environments/${environment_id}/work/${workID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Note: these endpoints are called automatically by the pre-built environment
       * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
       * sandbox environments. They are included here as a reference; you do not need to
       * invoke them directly.
       *
       * Update work item metadata with merge semantics.
       *
       * @example
       * ```ts
       * const betaSelfHostedWork =
       *   await client.beta.environments.work.update('work_id', {
       *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
       *     metadata: { foo: 'string' },
       *   });
       * ```
       */
      update(workID, params, options) {
        const { environment_id, betas, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/environments/${environment_id}/work/${workID}?beta=true`, {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Note: these endpoints are called automatically by the pre-built environment
       * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
       * sandbox environments. They are included here as a reference; you do not need to
       * invoke them directly.
       *
       * List work items in an environment.
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaSelfHostedWork of client.beta.environments.work.list(
       *   'env_011CZkZ9X2dpNyB7HsEFoRfW',
       * )) {
       *   // ...
       * }
       * ```
       */
      list(environmentID, params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList((0, path_1.path)`/v1/environments/${environmentID}/work?beta=true`, pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Note: these endpoints are called automatically by the pre-built environment
       * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
       * sandbox environments. They are included here as a reference; you do not need to
       * invoke them directly.
       *
       * Acknowledge receipt of a work item, transitioning it from 'queued' to 'starting'
       * and removing it from the queue.
       *
       * @example
       * ```ts
       * const betaSelfHostedWork =
       *   await client.beta.environments.work.ack('work_id', {
       *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
       *   });
       * ```
       */
      ack(workID, params, options) {
        const { environment_id, betas } = params;
        return this._client.post((0, path_1.path)`/v1/environments/${environment_id}/work/${workID}/ack?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Note: these endpoints are called automatically by the pre-built environment
       * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
       * sandbox environments. They are included here as a reference; you do not need to
       * invoke them directly.
       *
       * Record a heartbeat for a work item to maintain the lease.
       *
       * @example
       * ```ts
       * const betaSelfHostedWorkHeartbeatResponse =
       *   await client.beta.environments.work.heartbeat('work_id', {
       *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
       *   });
       * ```
       */
      heartbeat(workID, params, options) {
        const { environment_id, desired_ttl_seconds, expected_last_heartbeat, betas } = params;
        return this._client.post((0, path_1.path)`/v1/environments/${environment_id}/work/${workID}/heartbeat?beta=true`, {
          query: { desired_ttl_seconds, expected_last_heartbeat },
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Note: these endpoints are called automatically by the pre-built environment
       * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
       * sandbox environments. They are included here as a reference; you do not need to
       * invoke them directly.
       *
       * Long poll for work items in the queue.
       *
       * @example
       * ```ts
       * const betaSelfHostedWork =
       *   await client.beta.environments.work.poll(
       *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
       *   );
       * ```
       */
      poll(environmentID, params = {}, options) {
        const { betas, "Anthropic-Worker-ID": anthropicWorkerID, ...query } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/environments/${environmentID}/work/poll?beta=true`, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString(),
              ...anthropicWorkerID != null ? { "Anthropic-Worker-ID": anthropicWorkerID } : void 0
            },
            options?.headers
          ])
        });
      }
      /**
       * Get statistics about the work queue for an environment.
       *
       * @example
       * ```ts
       * const betaSelfHostedWorkQueueStats =
       *   await client.beta.environments.work.stats(
       *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
       *   );
       * ```
       */
      stats(environmentID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/environments/${environmentID}/work/stats?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Note: these endpoints are called automatically by the pre-built environment
       * worker provided in the SDKs and CLI, for orchestrating sessions with self-hosted
       * sandbox environments. They are included here as a reference; you do not need to
       * invoke them directly.
       *
       * Stop a work item, initiating graceful or forced shutdown.
       *
       * @example
       * ```ts
       * const betaSelfHostedWork =
       *   await client.beta.environments.work.stop('work_id', {
       *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
       *   });
       * ```
       */
      stop(workID, params, options) {
        const { environment_id, betas, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/environments/${environment_id}/work/${workID}/stop?beta=true`, {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Continuously claim work from a self-hosted environment, ack each item,
       * and yield it. Posts `stop` automatically when the consumer's loop body
       * returns or when iteration ends.
       *
       * @example
       * ```ts
       * for await (const work of client.beta.environments.work.poller({
       *   environmentId,
       *   environmentKey,
       * })) {
       *   if (work.data.type !== 'session') continue;
       *   // ...service the work...
       * }
       * ```
       */
      poller(opts) {
        return new poller_1.WorkPoller({ ...opts, client: this._client });
      }
      /**
       * The self-hosted environment runner: poll for work, and for each claimed
       * session set up the workdir, download the agent's skills, run the tools while
       * heartbeating the lease, and force-stop on exit.
       *
       * @example
       * ```ts
       * // Long-running daemon — poll, serve each session, loop:
       * await client.beta.environments.work
       *   .worker({ environmentId, environmentKey, workdir: '/workspace' })
       *   .run();
       *
       * // Or service one already-claimed work item (e.g. inside a sandbox spawned
       * // by `ant worker poll --on-work`) — handleItem() reads the ANTHROPIC_* env vars:
       * await client.beta.environments.work.worker({ workdir: '/workspace' }).handleItem();
       * ```
       */
      worker(opts) {
        return new worker_1.EnvironmentWorker({ ...opts, client: this._client });
      }
    };
    exports2.Work = Work;
    var poller_2 = require_poller();
    Object.defineProperty(exports2, "WorkPoller", { enumerable: true, get: function() {
      return poller_2.WorkPoller;
    } });
    var worker_2 = require_worker();
    Object.defineProperty(exports2, "EnvironmentWorker", { enumerable: true, get: function() {
      return worker_2.EnvironmentWorker;
    } });
    Work.WorkPoller = poller_1.WorkPoller;
    Work.EnvironmentWorker = worker_1.EnvironmentWorker;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/environments/environments.js
var require_environments = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/environments/environments.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Environments = void 0;
    var tslib_1 = require_tslib();
    var resource_1 = require_resource();
    var WorkAPI = tslib_1.__importStar(require_work());
    var work_1 = require_work();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Environments = class extends resource_1.APIResource {
      constructor() {
        super(...arguments);
        this.work = new WorkAPI.Work(this._client);
      }
      /**
       * Create a new environment with the specified configuration.
       *
       * @example
       * ```ts
       * const betaEnvironment =
       *   await client.beta.environments.create({
       *     name: 'python-data-analysis',
       *   });
       * ```
       */
      create(params, options) {
        const { betas, ...body } = params;
        return this._client.post("/v1/environments?beta=true", {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Retrieve a specific environment by ID.
       *
       * @example
       * ```ts
       * const betaEnvironment =
       *   await client.beta.environments.retrieve(
       *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
       *   );
       * ```
       */
      retrieve(environmentID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/environments/${environmentID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Update an existing environment's configuration.
       *
       * @example
       * ```ts
       * const betaEnvironment =
       *   await client.beta.environments.update(
       *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
       *   );
       * ```
       */
      update(environmentID, params, options) {
        const { betas, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/environments/${environmentID}?beta=true`, {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * List environments with pagination support.
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaEnvironment of client.beta.environments.list()) {
       *   // ...
       * }
       * ```
       */
      list(params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList("/v1/environments?beta=true", pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Delete an environment by ID. Returns a confirmation of the deletion.
       *
       * @example
       * ```ts
       * const betaEnvironmentDeleteResponse =
       *   await client.beta.environments.delete(
       *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
       *   );
       * ```
       */
      delete(environmentID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.delete((0, path_1.path)`/v1/environments/${environmentID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Archive an environment by ID. Archived environments cannot be used to create new
       * sessions.
       *
       * @example
       * ```ts
       * const betaEnvironment =
       *   await client.beta.environments.archive(
       *     'env_011CZkZ9X2dpNyB7HsEFoRfW',
       *   );
       * ```
       */
      archive(environmentID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.post((0, path_1.path)`/v1/environments/${environmentID}/archive?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
    };
    exports2.Environments = Environments;
    Environments.Work = work_1.Work;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/memory-stores/memories.js
var require_memories = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/memory-stores/memories.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Memories = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Memories = class extends resource_1.APIResource {
      /**
       * Create a memory
       *
       * @example
       * ```ts
       * const betaManagedAgentsMemory =
       *   await client.beta.memoryStores.memories.create(
       *     'memory_store_id',
       *     { content: 'content', path: 'xx' },
       *   );
       * ```
       */
      create(memoryStoreID, params, options) {
        const { view, betas, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/memory_stores/${memoryStoreID}/memories?beta=true`, {
          query: { view },
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Retrieve a memory
       *
       * @example
       * ```ts
       * const betaManagedAgentsMemory =
       *   await client.beta.memoryStores.memories.retrieve(
       *     'memory_id',
       *     { memory_store_id: 'memory_store_id' },
       *   );
       * ```
       */
      retrieve(memoryID, params, options) {
        const { memory_store_id, betas, ...query } = params;
        return this._client.get((0, path_1.path)`/v1/memory_stores/${memory_store_id}/memories/${memoryID}?beta=true`, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Update a memory
       *
       * @example
       * ```ts
       * const betaManagedAgentsMemory =
       *   await client.beta.memoryStores.memories.update(
       *     'memory_id',
       *     { memory_store_id: 'memory_store_id' },
       *   );
       * ```
       */
      update(memoryID, params, options) {
        const { memory_store_id, view, betas, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/memory_stores/${memory_store_id}/memories/${memoryID}?beta=true`, {
          query: { view },
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * List memories
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaManagedAgentsMemoryListItem of client.beta.memoryStores.memories.list(
       *   'memory_store_id',
       * )) {
       *   // ...
       * }
       * ```
       */
      list(memoryStoreID, params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList((0, path_1.path)`/v1/memory_stores/${memoryStoreID}/memories?beta=true`, pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Delete a memory
       *
       * @example
       * ```ts
       * const betaManagedAgentsDeletedMemory =
       *   await client.beta.memoryStores.memories.delete(
       *     'memory_id',
       *     { memory_store_id: 'memory_store_id' },
       *   );
       * ```
       */
      delete(memoryID, params, options) {
        const { memory_store_id, expected_content_sha256, betas } = params;
        return this._client.delete((0, path_1.path)`/v1/memory_stores/${memory_store_id}/memories/${memoryID}?beta=true`, {
          query: { expected_content_sha256 },
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
    };
    exports2.Memories = Memories;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/memory-stores/memory-versions.js
var require_memory_versions = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/memory-stores/memory-versions.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.MemoryVersions = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var MemoryVersions = class extends resource_1.APIResource {
      /**
       * Retrieve a memory version
       *
       * @example
       * ```ts
       * const betaManagedAgentsMemoryVersion =
       *   await client.beta.memoryStores.memoryVersions.retrieve(
       *     'memory_version_id',
       *     { memory_store_id: 'memory_store_id' },
       *   );
       * ```
       */
      retrieve(memoryVersionID, params, options) {
        const { memory_store_id, betas, ...query } = params;
        return this._client.get((0, path_1.path)`/v1/memory_stores/${memory_store_id}/memory_versions/${memoryVersionID}?beta=true`, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * List memory versions
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaManagedAgentsMemoryVersion of client.beta.memoryStores.memoryVersions.list(
       *   'memory_store_id',
       * )) {
       *   // ...
       * }
       * ```
       */
      list(memoryStoreID, params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList((0, path_1.path)`/v1/memory_stores/${memoryStoreID}/memory_versions?beta=true`, pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Redact a memory version
       *
       * @example
       * ```ts
       * const betaManagedAgentsMemoryVersion =
       *   await client.beta.memoryStores.memoryVersions.redact(
       *     'memory_version_id',
       *     { memory_store_id: 'memory_store_id' },
       *   );
       * ```
       */
      redact(memoryVersionID, params, options) {
        const { memory_store_id, betas } = params;
        return this._client.post((0, path_1.path)`/v1/memory_stores/${memory_store_id}/memory_versions/${memoryVersionID}/redact?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
    };
    exports2.MemoryVersions = MemoryVersions;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/memory-stores/memory-stores.js
var require_memory_stores = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/memory-stores/memory-stores.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.MemoryStores = void 0;
    var tslib_1 = require_tslib();
    var resource_1 = require_resource();
    var MemoriesAPI = tslib_1.__importStar(require_memories());
    var memories_1 = require_memories();
    var MemoryVersionsAPI = tslib_1.__importStar(require_memory_versions());
    var memory_versions_1 = require_memory_versions();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var MemoryStores = class extends resource_1.APIResource {
      constructor() {
        super(...arguments);
        this.memories = new MemoriesAPI.Memories(this._client);
        this.memoryVersions = new MemoryVersionsAPI.MemoryVersions(this._client);
      }
      /**
       * Create a memory store
       *
       * @example
       * ```ts
       * const betaManagedAgentsMemoryStore =
       *   await client.beta.memoryStores.create({ name: 'x' });
       * ```
       */
      create(params, options) {
        const { betas, ...body } = params;
        return this._client.post("/v1/memory_stores?beta=true", {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Retrieve a memory store
       *
       * @example
       * ```ts
       * const betaManagedAgentsMemoryStore =
       *   await client.beta.memoryStores.retrieve(
       *     'memory_store_id',
       *   );
       * ```
       */
      retrieve(memoryStoreID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/memory_stores/${memoryStoreID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Update a memory store
       *
       * @example
       * ```ts
       * const betaManagedAgentsMemoryStore =
       *   await client.beta.memoryStores.update('memory_store_id');
       * ```
       */
      update(memoryStoreID, params, options) {
        const { betas, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/memory_stores/${memoryStoreID}?beta=true`, {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * List memory stores
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaManagedAgentsMemoryStore of client.beta.memoryStores.list()) {
       *   // ...
       * }
       * ```
       */
      list(params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList("/v1/memory_stores?beta=true", pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Delete a memory store
       *
       * @example
       * ```ts
       * const betaManagedAgentsDeletedMemoryStore =
       *   await client.beta.memoryStores.delete('memory_store_id');
       * ```
       */
      delete(memoryStoreID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.delete((0, path_1.path)`/v1/memory_stores/${memoryStoreID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Archive a memory store
       *
       * @example
       * ```ts
       * const betaManagedAgentsMemoryStore =
       *   await client.beta.memoryStores.archive('memory_store_id');
       * ```
       */
      archive(memoryStoreID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.post((0, path_1.path)`/v1/memory_stores/${memoryStoreID}/archive?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
    };
    exports2.MemoryStores = MemoryStores;
    MemoryStores.Memories = memories_1.Memories;
    MemoryStores.MemoryVersions = memory_versions_1.MemoryVersions;
  }
});

// node_modules/@anthropic-ai/sdk/error.js
var require_error2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/error.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    tslib_1.__exportStar(require_error(), exports2);
  }
});

// node_modules/@anthropic-ai/sdk/internal/decoders/jsonl.js
var require_jsonl = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/decoders/jsonl.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.JSONLDecoder = void 0;
    var error_1 = require_error();
    var shims_1 = require_shims();
    var line_1 = require_line();
    var JSONLDecoder = class _JSONLDecoder {
      constructor(iterator, controller) {
        this.iterator = iterator;
        this.controller = controller;
      }
      async *decoder() {
        const lineDecoder = new line_1.LineDecoder();
        for await (const chunk of this.iterator) {
          for (const line of lineDecoder.decode(chunk)) {
            yield JSON.parse(line);
          }
        }
        for (const line of lineDecoder.flush()) {
          yield JSON.parse(line);
        }
      }
      [Symbol.asyncIterator]() {
        return this.decoder();
      }
      static fromResponse(response, controller) {
        if (!response.body) {
          controller.abort();
          if (typeof globalThis.navigator !== "undefined" && globalThis.navigator.product === "ReactNative") {
            throw new error_1.AnthropicError(`The default react-native fetch implementation does not support streaming. Please use expo/fetch: https://docs.expo.dev/versions/latest/sdk/expo/#expofetch-api`);
          }
          throw new error_1.AnthropicError(`Attempted to iterate over a response with no body`);
        }
        return new _JSONLDecoder((0, shims_1.ReadableStreamToAsyncIterable)(response.body), controller);
      }
    };
    exports2.JSONLDecoder = JSONLDecoder;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/messages/batches.js
var require_batches = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/messages/batches.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Batches = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var jsonl_1 = require_jsonl();
    var error_1 = require_error2();
    var path_1 = require_path();
    var Batches = class extends resource_1.APIResource {
      /**
       * Send a batch of Message creation requests.
       *
       * The Message Batches API can be used to process multiple Messages API requests at
       * once. Once a Message Batch is created, it begins processing immediately. Batches
       * can take up to 24 hours to complete.
       *
       * Learn more about the Message Batches API in our
       * [user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
       *
       * @example
       * ```ts
       * const betaMessageBatch =
       *   await client.beta.messages.batches.create({
       *     requests: [
       *       {
       *         custom_id: 'my-custom-id-1',
       *         params: {
       *           max_tokens: 1024,
       *           messages: [
       *             { content: 'Hello, world', role: 'user' },
       *           ],
       *           model: 'claude-opus-4-6',
       *         },
       *       },
       *     ],
       *   });
       * ```
       */
      create(params, options) {
        const { betas, ...body } = params;
        return this._client.post("/v1/messages/batches?beta=true", {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "message-batches-2024-09-24"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * This endpoint is idempotent and can be used to poll for Message Batch
       * completion. To access the results of a Message Batch, make a request to the
       * `results_url` field in the response.
       *
       * Learn more about the Message Batches API in our
       * [user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
       *
       * @example
       * ```ts
       * const betaMessageBatch =
       *   await client.beta.messages.batches.retrieve(
       *     'message_batch_id',
       *   );
       * ```
       */
      retrieve(messageBatchID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/messages/batches/${messageBatchID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "message-batches-2024-09-24"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * List all Message Batches within a Workspace. Most recently created batches are
       * returned first.
       *
       * Learn more about the Message Batches API in our
       * [user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaMessageBatch of client.beta.messages.batches.list()) {
       *   // ...
       * }
       * ```
       */
      list(params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList("/v1/messages/batches?beta=true", pagination_1.Page, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "message-batches-2024-09-24"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Delete a Message Batch.
       *
       * Message Batches can only be deleted once they've finished processing. If you'd
       * like to delete an in-progress batch, you must first cancel it.
       *
       * Learn more about the Message Batches API in our
       * [user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
       *
       * @example
       * ```ts
       * const betaDeletedMessageBatch =
       *   await client.beta.messages.batches.delete(
       *     'message_batch_id',
       *   );
       * ```
       */
      delete(messageBatchID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.delete((0, path_1.path)`/v1/messages/batches/${messageBatchID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "message-batches-2024-09-24"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Batches may be canceled any time before processing ends. Once cancellation is
       * initiated, the batch enters a `canceling` state, at which time the system may
       * complete any in-progress, non-interruptible requests before finalizing
       * cancellation.
       *
       * The number of canceled requests is specified in `request_counts`. To determine
       * which requests were canceled, check the individual results within the batch.
       * Note that cancellation may not result in any canceled requests if they were
       * non-interruptible.
       *
       * Learn more about the Message Batches API in our
       * [user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
       *
       * @example
       * ```ts
       * const betaMessageBatch =
       *   await client.beta.messages.batches.cancel(
       *     'message_batch_id',
       *   );
       * ```
       */
      cancel(messageBatchID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.post((0, path_1.path)`/v1/messages/batches/${messageBatchID}/cancel?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "message-batches-2024-09-24"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Streams the results of a Message Batch as a `.jsonl` file.
       *
       * Each line in the file is a JSON object containing the result of a single request
       * in the Message Batch. Results are not guaranteed to be in the same order as
       * requests. Use the `custom_id` field to match results to requests.
       *
       * Learn more about the Message Batches API in our
       * [user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
       *
       * @example
       * ```ts
       * const betaMessageBatchIndividualResponse =
       *   await client.beta.messages.batches.results(
       *     'message_batch_id',
       *   );
       * ```
       */
      async results(messageBatchID, params = {}, options) {
        const batch = await this.retrieve(messageBatchID);
        if (!batch.results_url) {
          throw new error_1.AnthropicError(`No batch \`results_url\`; Has it finished processing? ${batch.processing_status} - ${batch.id}`);
        }
        const { betas } = params ?? {};
        return this._client.get(batch.results_url, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "message-batches-2024-09-24"].toString(),
              Accept: "application/binary"
            },
            options?.headers
          ]),
          stream: true,
          __binaryResponse: true
        })._thenUnwrap((_, props) => jsonl_1.JSONLDecoder.fromResponse(props.response, props.controller));
      }
    };
    exports2.Batches = Batches;
  }
});

// node_modules/@anthropic-ai/sdk/internal/constants.js
var require_constants = __commonJS({
  "node_modules/@anthropic-ai/sdk/internal/constants.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.MODEL_NONSTREAMING_TOKENS = void 0;
    exports2.MODEL_NONSTREAMING_TOKENS = {
      "claude-opus-4-20250514": 8192,
      "claude-opus-4-0": 8192,
      "claude-4-opus-20250514": 8192,
      "anthropic.claude-opus-4-20250514-v1:0": 8192,
      "claude-opus-4@20250514": 8192,
      "claude-opus-4-1-20250805": 8192,
      "anthropic.claude-opus-4-1-20250805-v1:0": 8192,
      "claude-opus-4-1@20250805": 8192
    };
  }
});

// node_modules/@anthropic-ai/sdk/lib/beta-parser.js
var require_beta_parser = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/beta-parser.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.maybeParseBetaMessage = maybeParseBetaMessage;
    exports2.parseBetaMessage = parseBetaMessage;
    var error_1 = require_error();
    function getOutputFormat(params) {
      return params?.output_format ?? params?.output_config?.format;
    }
    function maybeParseBetaMessage(message, params, opts) {
      const outputFormat = getOutputFormat(params);
      if (!params || !("parse" in (outputFormat ?? {}))) {
        return {
          ...message,
          content: message.content.map((block) => {
            if (block.type === "text") {
              const parsedBlock = Object.defineProperty({ ...block }, "parsed_output", {
                value: null,
                enumerable: false
              });
              return Object.defineProperty(parsedBlock, "parsed", {
                get() {
                  opts.logger.warn("The `parsed` property on `text` blocks is deprecated, please use `parsed_output` instead.");
                  return null;
                },
                enumerable: false
              });
            }
            return block;
          }),
          parsed_output: null
        };
      }
      return parseBetaMessage(message, params, opts);
    }
    function parseBetaMessage(message, params, opts) {
      let firstParsedOutput = null;
      const content = message.content.map((block) => {
        if (block.type === "text") {
          const parsedOutput = parseBetaOutputFormat(params, block.text);
          if (firstParsedOutput === null) {
            firstParsedOutput = parsedOutput;
          }
          const parsedBlock = Object.defineProperty({ ...block }, "parsed_output", {
            value: parsedOutput,
            enumerable: false
          });
          return Object.defineProperty(parsedBlock, "parsed", {
            get() {
              opts.logger.warn("The `parsed` property on `text` blocks is deprecated, please use `parsed_output` instead.");
              return parsedOutput;
            },
            enumerable: false
          });
        }
        return block;
      });
      return {
        ...message,
        content,
        parsed_output: firstParsedOutput
      };
    }
    function parseBetaOutputFormat(params, content) {
      const outputFormat = getOutputFormat(params);
      if (outputFormat?.type !== "json_schema") {
        return null;
      }
      try {
        if ("parse" in outputFormat) {
          return outputFormat.parse(content);
        }
        return JSON.parse(content);
      } catch (error) {
        throw new error_1.AnthropicError(`Failed to parse structured output: ${error}`);
      }
    }
  }
});

// node_modules/@anthropic-ai/sdk/_vendor/partial-json-parser/parser.js
var require_parser = __commonJS({
  "node_modules/@anthropic-ai/sdk/_vendor/partial-json-parser/parser.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.partialParse = void 0;
    var tokenize = (input) => {
      let current = 0;
      let tokens = [];
      while (current < input.length) {
        let char = input[current];
        if (char === "\\") {
          current++;
          continue;
        }
        if (char === "{") {
          tokens.push({
            type: "brace",
            value: "{"
          });
          current++;
          continue;
        }
        if (char === "}") {
          tokens.push({
            type: "brace",
            value: "}"
          });
          current++;
          continue;
        }
        if (char === "[") {
          tokens.push({
            type: "paren",
            value: "["
          });
          current++;
          continue;
        }
        if (char === "]") {
          tokens.push({
            type: "paren",
            value: "]"
          });
          current++;
          continue;
        }
        if (char === ":") {
          tokens.push({
            type: "separator",
            value: ":"
          });
          current++;
          continue;
        }
        if (char === ",") {
          tokens.push({
            type: "delimiter",
            value: ","
          });
          current++;
          continue;
        }
        if (char === '"') {
          let value = "";
          let danglingQuote = false;
          char = input[++current];
          while (char !== '"') {
            if (current === input.length) {
              danglingQuote = true;
              break;
            }
            if (char === "\\") {
              current++;
              if (current === input.length) {
                danglingQuote = true;
                break;
              }
              value += char + input[current];
              char = input[++current];
            } else {
              value += char;
              char = input[++current];
            }
          }
          char = input[++current];
          if (!danglingQuote) {
            tokens.push({
              type: "string",
              value
            });
          }
          continue;
        }
        let WHITESPACE = /\s/;
        if (char && WHITESPACE.test(char)) {
          current++;
          continue;
        }
        let NUMBERS = /[0-9]/;
        if (char && NUMBERS.test(char) || char === "-" || char === ".") {
          let value = "";
          if (char === "-") {
            value += char;
            char = input[++current];
          }
          while (char && NUMBERS.test(char) || char === ".") {
            value += char;
            char = input[++current];
          }
          tokens.push({
            type: "number",
            value
          });
          continue;
        }
        let LETTERS = /[a-z]/i;
        if (char && LETTERS.test(char)) {
          let value = "";
          while (char && LETTERS.test(char)) {
            if (current === input.length) {
              break;
            }
            value += char;
            char = input[++current];
          }
          if (value == "true" || value == "false" || value === "null") {
            tokens.push({
              type: "name",
              value
            });
          } else {
            current++;
            continue;
          }
          continue;
        }
        current++;
      }
      return tokens;
    };
    var strip = (tokens) => {
      if (tokens.length === 0) {
        return tokens;
      }
      let lastToken = tokens[tokens.length - 1];
      switch (lastToken.type) {
        case "separator":
          tokens = tokens.slice(0, tokens.length - 1);
          return strip(tokens);
          break;
        case "number":
          let lastCharacterOfLastToken = lastToken.value[lastToken.value.length - 1];
          if (lastCharacterOfLastToken === "." || lastCharacterOfLastToken === "-") {
            tokens = tokens.slice(0, tokens.length - 1);
            return strip(tokens);
          }
        case "string":
          let tokenBeforeTheLastToken = tokens[tokens.length - 2];
          if (tokenBeforeTheLastToken?.type === "delimiter") {
            tokens = tokens.slice(0, tokens.length - 1);
            return strip(tokens);
          } else if (tokenBeforeTheLastToken?.type === "brace" && tokenBeforeTheLastToken.value === "{") {
            tokens = tokens.slice(0, tokens.length - 1);
            return strip(tokens);
          }
          break;
        case "delimiter":
          tokens = tokens.slice(0, tokens.length - 1);
          return strip(tokens);
          break;
      }
      return tokens;
    };
    var unstrip = (tokens) => {
      let tail = [];
      tokens.map((token) => {
        if (token.type === "brace") {
          if (token.value === "{") {
            tail.push("}");
          } else {
            tail.splice(tail.lastIndexOf("}"), 1);
          }
        }
        if (token.type === "paren") {
          if (token.value === "[") {
            tail.push("]");
          } else {
            tail.splice(tail.lastIndexOf("]"), 1);
          }
        }
      });
      if (tail.length > 0) {
        tail.reverse().map((item) => {
          if (item === "}") {
            tokens.push({
              type: "brace",
              value: "}"
            });
          } else if (item === "]") {
            tokens.push({
              type: "paren",
              value: "]"
            });
          }
        });
      }
      return tokens;
    };
    var generate = (tokens) => {
      let output = "";
      tokens.map((token) => {
        switch (token.type) {
          case "string":
            output += '"' + token.value + '"';
            break;
          default:
            output += token.value;
            break;
        }
      });
      return output;
    };
    var partialParse = (input) => JSON.parse(generate(unstrip(strip(tokenize(input)))));
    exports2.partialParse = partialParse;
  }
});

// node_modules/@anthropic-ai/sdk/streaming.js
var require_streaming2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/streaming.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    var tslib_1 = require_tslib();
    tslib_1.__exportStar(require_streaming(), exports2);
  }
});

// node_modules/@anthropic-ai/sdk/lib/BetaMessageStream.js
var require_BetaMessageStream = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/BetaMessageStream.js"(exports2) {
    "use strict";
    var _BetaMessageStream_instances;
    var _BetaMessageStream_currentMessageSnapshot;
    var _BetaMessageStream_params;
    var _BetaMessageStream_connectedPromise;
    var _BetaMessageStream_resolveConnectedPromise;
    var _BetaMessageStream_rejectConnectedPromise;
    var _BetaMessageStream_endPromise;
    var _BetaMessageStream_resolveEndPromise;
    var _BetaMessageStream_rejectEndPromise;
    var _BetaMessageStream_listeners;
    var _BetaMessageStream_ended;
    var _BetaMessageStream_errored;
    var _BetaMessageStream_aborted;
    var _BetaMessageStream_catchingPromiseCreated;
    var _BetaMessageStream_response;
    var _BetaMessageStream_request_id;
    var _BetaMessageStream_logger;
    var _BetaMessageStream_getFinalMessage;
    var _BetaMessageStream_getFinalText;
    var _BetaMessageStream_handleError;
    var _BetaMessageStream_beginRequest;
    var _BetaMessageStream_addStreamEvent;
    var _BetaMessageStream_endRequest;
    var _BetaMessageStream_accumulateMessage;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.BetaMessageStream = void 0;
    var tslib_1 = require_tslib();
    var parser_1 = require_parser();
    var error_1 = require_error2();
    var errors_1 = require_errors();
    var streaming_1 = require_streaming2();
    var beta_parser_1 = require_beta_parser();
    var JSON_BUF_PROPERTY = "__json_buf";
    function tracksToolInput(content) {
      return content.type === "tool_use" || content.type === "server_tool_use" || content.type === "mcp_tool_use";
    }
    var BetaMessageStream = class _BetaMessageStream {
      constructor(params, opts) {
        _BetaMessageStream_instances.add(this);
        this.messages = [];
        this.receivedMessages = [];
        _BetaMessageStream_currentMessageSnapshot.set(this, void 0);
        _BetaMessageStream_params.set(this, null);
        this.controller = new AbortController();
        _BetaMessageStream_connectedPromise.set(this, void 0);
        _BetaMessageStream_resolveConnectedPromise.set(this, () => {
        });
        _BetaMessageStream_rejectConnectedPromise.set(this, () => {
        });
        _BetaMessageStream_endPromise.set(this, void 0);
        _BetaMessageStream_resolveEndPromise.set(this, () => {
        });
        _BetaMessageStream_rejectEndPromise.set(this, () => {
        });
        _BetaMessageStream_listeners.set(this, {});
        _BetaMessageStream_ended.set(this, false);
        _BetaMessageStream_errored.set(this, false);
        _BetaMessageStream_aborted.set(this, false);
        _BetaMessageStream_catchingPromiseCreated.set(this, false);
        _BetaMessageStream_response.set(this, void 0);
        _BetaMessageStream_request_id.set(this, void 0);
        _BetaMessageStream_logger.set(this, void 0);
        _BetaMessageStream_handleError.set(this, (error) => {
          tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_errored, true, "f");
          if ((0, errors_1.isAbortError)(error)) {
            error = new error_1.APIUserAbortError();
          }
          if (error instanceof error_1.APIUserAbortError) {
            tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_aborted, true, "f");
            return this._emit("abort", error);
          }
          if (error instanceof error_1.AnthropicError) {
            return this._emit("error", error);
          }
          if (error instanceof Error) {
            const anthropicError = new error_1.AnthropicError(error.message);
            anthropicError.cause = error;
            return this._emit("error", anthropicError);
          }
          return this._emit("error", new error_1.AnthropicError(String(error)));
        });
        tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_connectedPromise, new Promise((resolve, reject) => {
          tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_resolveConnectedPromise, resolve, "f");
          tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_rejectConnectedPromise, reject, "f");
        }), "f");
        tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_endPromise, new Promise((resolve, reject) => {
          tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_resolveEndPromise, resolve, "f");
          tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_rejectEndPromise, reject, "f");
        }), "f");
        tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_connectedPromise, "f").catch(() => {
        });
        tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_endPromise, "f").catch(() => {
        });
        tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_params, params, "f");
        tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_logger, opts?.logger ?? console, "f");
      }
      get response() {
        return tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_response, "f");
      }
      get request_id() {
        return tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_request_id, "f");
      }
      /**
       * Returns the `MessageStream` data, the raw `Response` instance and the ID of the request,
       * returned vie the `request-id` header which is useful for debugging requests and resporting
       * issues to Anthropic.
       *
       * This is the same as the `APIPromise.withResponse()` method.
       *
       * This method will raise an error if you created the stream using `MessageStream.fromReadableStream`
       * as no `Response` is available.
       */
      async withResponse() {
        tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_catchingPromiseCreated, true, "f");
        const response = await tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_connectedPromise, "f");
        if (!response) {
          throw new Error("Could not resolve a `Response` object");
        }
        return {
          data: this,
          response,
          request_id: response.headers.get("request-id")
        };
      }
      /**
       * Intended for use on the frontend, consuming a stream produced with
       * `.toReadableStream()` on the backend.
       *
       * Note that messages sent to the model do not appear in `.on('message')`
       * in this context.
       */
      static fromReadableStream(stream) {
        const runner = new _BetaMessageStream(null);
        runner._run(() => runner._fromReadableStream(stream));
        return runner;
      }
      static createMessage(messages, params, options, { logger } = {}) {
        const runner = new _BetaMessageStream(params, { logger });
        for (const message of params.messages) {
          runner._addMessageParam(message);
        }
        tslib_1.__classPrivateFieldSet(runner, _BetaMessageStream_params, { ...params, stream: true }, "f");
        runner._run(() => runner._createMessage(messages, { ...params, stream: true }, { ...options, headers: { ...options?.headers, "X-Stainless-Helper-Method": "stream" } }));
        return runner;
      }
      _run(executor) {
        executor().then(() => {
          this._emitFinal();
          this._emit("end");
        }, tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_handleError, "f"));
      }
      _addMessageParam(message) {
        this.messages.push(message);
      }
      _addMessage(message, emit = true) {
        this.receivedMessages.push(message);
        if (emit) {
          this._emit("message", message);
        }
      }
      async _createMessage(messages, params, options) {
        const signal = options?.signal;
        let abortHandler;
        if (signal) {
          if (signal.aborted)
            this.controller.abort();
          abortHandler = this.controller.abort.bind(this.controller);
          signal.addEventListener("abort", abortHandler);
        }
        try {
          tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_beginRequest).call(this);
          const { response, data: stream } = await messages.create({ ...params, stream: true }, { ...options, signal: this.controller.signal }).withResponse();
          this._connected(response);
          for await (const event of stream) {
            tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_addStreamEvent).call(this, event);
          }
          if (stream.controller.signal?.aborted) {
            throw new error_1.APIUserAbortError();
          }
          tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_endRequest).call(this);
        } finally {
          if (signal && abortHandler) {
            signal.removeEventListener("abort", abortHandler);
          }
        }
      }
      _connected(response) {
        if (this.ended)
          return;
        tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_response, response, "f");
        tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_request_id, response?.headers.get("request-id"), "f");
        tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_resolveConnectedPromise, "f").call(this, response);
        this._emit("connect");
      }
      get ended() {
        return tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_ended, "f");
      }
      get errored() {
        return tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_errored, "f");
      }
      get aborted() {
        return tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_aborted, "f");
      }
      abort() {
        this.controller.abort();
      }
      /**
       * Adds the listener function to the end of the listeners array for the event.
       * No checks are made to see if the listener has already been added. Multiple calls passing
       * the same combination of event and listener will result in the listener being added, and
       * called, multiple times.
       * @returns this MessageStream, so that calls can be chained
       */
      on(event, listener) {
        const listeners = tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_listeners, "f")[event] || (tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_listeners, "f")[event] = []);
        listeners.push({ listener });
        return this;
      }
      /**
       * Removes the specified listener from the listener array for the event.
       * off() will remove, at most, one instance of a listener from the listener array. If any single
       * listener has been added multiple times to the listener array for the specified event, then
       * off() must be called multiple times to remove each instance.
       * @returns this MessageStream, so that calls can be chained
       */
      off(event, listener) {
        const listeners = tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_listeners, "f")[event];
        if (!listeners)
          return this;
        const index = listeners.findIndex((l) => l.listener === listener);
        if (index >= 0)
          listeners.splice(index, 1);
        return this;
      }
      /**
       * Adds a one-time listener function for the event. The next time the event is triggered,
       * this listener is removed and then invoked.
       * @returns this MessageStream, so that calls can be chained
       */
      once(event, listener) {
        const listeners = tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_listeners, "f")[event] || (tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_listeners, "f")[event] = []);
        listeners.push({ listener, once: true });
        return this;
      }
      /**
       * This is similar to `.once()`, but returns a Promise that resolves the next time
       * the event is triggered, instead of calling a listener callback.
       * @returns a Promise that resolves the next time given event is triggered,
       * or rejects if an error is emitted.  (If you request the 'error' event,
       * returns a promise that resolves with the error).
       *
       * Example:
       *
       *   const message = await stream.emitted('message') // rejects if the stream errors
       */
      emitted(event) {
        return new Promise((resolve, reject) => {
          tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_catchingPromiseCreated, true, "f");
          if (event !== "error")
            this.once("error", reject);
          this.once(event, resolve);
        });
      }
      async done() {
        tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_catchingPromiseCreated, true, "f");
        await tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_endPromise, "f");
      }
      get currentMessage() {
        return tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_currentMessageSnapshot, "f");
      }
      /**
       * @returns a promise that resolves with the the final assistant Message response,
       * or rejects if an error occurred or the stream ended prematurely without producing a Message.
       * If structured outputs were used, this will be a ParsedMessage with a `parsed` field.
       */
      async finalMessage() {
        await this.done();
        return tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_getFinalMessage).call(this);
      }
      /**
       * @returns a promise that resolves with the the final assistant Message's text response, concatenated
       * together if there are more than one text blocks.
       * Rejects if an error occurred or the stream ended prematurely without producing a Message.
       */
      async finalText() {
        await this.done();
        return tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_getFinalText).call(this);
      }
      _emit(event, ...args) {
        if (tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_ended, "f"))
          return;
        if (event === "end") {
          tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_ended, true, "f");
          tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_resolveEndPromise, "f").call(this);
        }
        const listeners = tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_listeners, "f")[event];
        if (listeners) {
          tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_listeners, "f")[event] = listeners.filter((l) => !l.once);
          listeners.forEach(({ listener }) => listener(...args));
        }
        if (event === "abort") {
          const error = args[0];
          if (!tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_catchingPromiseCreated, "f") && !listeners?.length) {
            Promise.reject(error);
          }
          tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_rejectConnectedPromise, "f").call(this, error);
          tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_rejectEndPromise, "f").call(this, error);
          this._emit("end");
          return;
        }
        if (event === "error") {
          const error = args[0];
          if (!tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_catchingPromiseCreated, "f") && !listeners?.length) {
            Promise.reject(error);
          }
          tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_rejectConnectedPromise, "f").call(this, error);
          tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_rejectEndPromise, "f").call(this, error);
          this._emit("end");
        }
      }
      _emitFinal() {
        const finalMessage = this.receivedMessages.at(-1);
        if (finalMessage) {
          this._emit("finalMessage", tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_getFinalMessage).call(this));
        }
      }
      async _fromReadableStream(readableStream, options) {
        const signal = options?.signal;
        let abortHandler;
        if (signal) {
          if (signal.aborted)
            this.controller.abort();
          abortHandler = this.controller.abort.bind(this.controller);
          signal.addEventListener("abort", abortHandler);
        }
        try {
          tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_beginRequest).call(this);
          this._connected(null);
          const stream = streaming_1.Stream.fromReadableStream(readableStream, this.controller);
          for await (const event of stream) {
            tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_addStreamEvent).call(this, event);
          }
          if (stream.controller.signal?.aborted) {
            throw new error_1.APIUserAbortError();
          }
          tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_endRequest).call(this);
        } finally {
          if (signal && abortHandler) {
            signal.removeEventListener("abort", abortHandler);
          }
        }
      }
      [(_BetaMessageStream_currentMessageSnapshot = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_params = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_connectedPromise = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_resolveConnectedPromise = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_rejectConnectedPromise = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_endPromise = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_resolveEndPromise = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_rejectEndPromise = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_listeners = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_ended = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_errored = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_aborted = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_catchingPromiseCreated = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_response = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_request_id = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_logger = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_handleError = /* @__PURE__ */ new WeakMap(), _BetaMessageStream_instances = /* @__PURE__ */ new WeakSet(), _BetaMessageStream_getFinalMessage = function _BetaMessageStream_getFinalMessage2() {
        if (this.receivedMessages.length === 0) {
          throw new error_1.AnthropicError("stream ended without producing a Message with role=assistant");
        }
        return this.receivedMessages.at(-1);
      }, _BetaMessageStream_getFinalText = function _BetaMessageStream_getFinalText2() {
        if (this.receivedMessages.length === 0) {
          throw new error_1.AnthropicError("stream ended without producing a Message with role=assistant");
        }
        const textBlocks = this.receivedMessages.at(-1).content.filter((block) => block.type === "text").map((block) => block.text);
        if (textBlocks.length === 0) {
          throw new error_1.AnthropicError("stream ended without producing a content block with type=text");
        }
        return textBlocks.join(" ");
      }, _BetaMessageStream_beginRequest = function _BetaMessageStream_beginRequest2() {
        if (this.ended)
          return;
        tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_currentMessageSnapshot, void 0, "f");
      }, _BetaMessageStream_addStreamEvent = function _BetaMessageStream_addStreamEvent2(event) {
        if (this.ended)
          return;
        const messageSnapshot = tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_instances, "m", _BetaMessageStream_accumulateMessage).call(this, event);
        this._emit("streamEvent", event, messageSnapshot);
        switch (event.type) {
          case "content_block_delta": {
            const content = messageSnapshot.content.at(-1);
            switch (event.delta.type) {
              case "text_delta": {
                if (content.type === "text") {
                  this._emit("text", event.delta.text, content.text || "");
                }
                break;
              }
              case "citations_delta": {
                if (content.type === "text") {
                  this._emit("citation", event.delta.citation, content.citations ?? []);
                }
                break;
              }
              case "input_json_delta": {
                if (tracksToolInput(content) && content.input) {
                  this._emit("inputJson", event.delta.partial_json, content.input);
                }
                break;
              }
              case "thinking_delta": {
                if (content.type === "thinking") {
                  this._emit("thinking", event.delta.thinking, content.thinking);
                }
                break;
              }
              case "signature_delta": {
                if (content.type === "thinking") {
                  this._emit("signature", content.signature);
                }
                break;
              }
              case "compaction_delta": {
                if (content.type === "compaction" && content.content) {
                  this._emit("compaction", content.content);
                }
                break;
              }
              default:
                checkNever(event.delta);
            }
            break;
          }
          case "message_stop": {
            this._addMessageParam(messageSnapshot);
            this._addMessage((0, beta_parser_1.maybeParseBetaMessage)(messageSnapshot, tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_params, "f"), { logger: tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_logger, "f") }), true);
            break;
          }
          case "content_block_stop": {
            this._emit("contentBlock", messageSnapshot.content.at(-1));
            break;
          }
          case "message_start": {
            tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_currentMessageSnapshot, messageSnapshot, "f");
            break;
          }
          case "content_block_start":
          case "message_delta":
            break;
        }
      }, _BetaMessageStream_endRequest = function _BetaMessageStream_endRequest2() {
        if (this.ended) {
          throw new error_1.AnthropicError(`stream has ended, this shouldn't happen`);
        }
        const snapshot = tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_currentMessageSnapshot, "f");
        if (!snapshot) {
          throw new error_1.AnthropicError(`request ended without sending any chunks`);
        }
        tslib_1.__classPrivateFieldSet(this, _BetaMessageStream_currentMessageSnapshot, void 0, "f");
        return (0, beta_parser_1.maybeParseBetaMessage)(snapshot, tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_params, "f"), { logger: tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_logger, "f") });
      }, _BetaMessageStream_accumulateMessage = function _BetaMessageStream_accumulateMessage2(event) {
        let snapshot = tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_currentMessageSnapshot, "f");
        if (event.type === "message_start") {
          if (snapshot) {
            throw new error_1.AnthropicError(`Unexpected event order, got ${event.type} before receiving "message_stop"`);
          }
          return event.message;
        }
        if (!snapshot) {
          throw new error_1.AnthropicError(`Unexpected event order, got ${event.type} before "message_start"`);
        }
        switch (event.type) {
          case "message_stop":
            return snapshot;
          case "message_delta":
            snapshot.container = event.delta.container;
            snapshot.stop_reason = event.delta.stop_reason;
            snapshot.stop_sequence = event.delta.stop_sequence;
            snapshot.usage.output_tokens = event.usage.output_tokens;
            snapshot.context_management = event.context_management;
            if (event.usage.input_tokens != null) {
              snapshot.usage.input_tokens = event.usage.input_tokens;
            }
            if (event.usage.cache_creation_input_tokens != null) {
              snapshot.usage.cache_creation_input_tokens = event.usage.cache_creation_input_tokens;
            }
            if (event.usage.cache_read_input_tokens != null) {
              snapshot.usage.cache_read_input_tokens = event.usage.cache_read_input_tokens;
            }
            if (event.usage.server_tool_use != null) {
              snapshot.usage.server_tool_use = event.usage.server_tool_use;
            }
            if (event.usage.iterations != null) {
              snapshot.usage.iterations = event.usage.iterations;
            }
            return snapshot;
          case "content_block_start":
            snapshot.content.push(event.content_block);
            return snapshot;
          case "content_block_delta": {
            const snapshotContent = snapshot.content.at(event.index);
            switch (event.delta.type) {
              case "text_delta": {
                if (snapshotContent?.type === "text") {
                  snapshot.content[event.index] = {
                    ...snapshotContent,
                    text: (snapshotContent.text || "") + event.delta.text
                  };
                }
                break;
              }
              case "citations_delta": {
                if (snapshotContent?.type === "text") {
                  snapshot.content[event.index] = {
                    ...snapshotContent,
                    citations: [...snapshotContent.citations ?? [], event.delta.citation]
                  };
                }
                break;
              }
              case "input_json_delta": {
                if (snapshotContent && tracksToolInput(snapshotContent)) {
                  let jsonBuf = snapshotContent[JSON_BUF_PROPERTY] || "";
                  jsonBuf += event.delta.partial_json;
                  const newContent = { ...snapshotContent };
                  Object.defineProperty(newContent, JSON_BUF_PROPERTY, {
                    value: jsonBuf,
                    enumerable: false,
                    writable: true
                  });
                  if (jsonBuf) {
                    try {
                      newContent.input = (0, parser_1.partialParse)(jsonBuf);
                    } catch (err) {
                      const error = new error_1.AnthropicError(`Unable to parse tool parameter JSON from model. Please retry your request or adjust your prompt. Error: ${err}. JSON: ${jsonBuf}`);
                      tslib_1.__classPrivateFieldGet(this, _BetaMessageStream_handleError, "f").call(this, error);
                    }
                  }
                  snapshot.content[event.index] = newContent;
                }
                break;
              }
              case "thinking_delta": {
                if (snapshotContent?.type === "thinking") {
                  snapshot.content[event.index] = {
                    ...snapshotContent,
                    thinking: snapshotContent.thinking + event.delta.thinking
                  };
                }
                break;
              }
              case "signature_delta": {
                if (snapshotContent?.type === "thinking") {
                  snapshot.content[event.index] = {
                    ...snapshotContent,
                    signature: event.delta.signature
                  };
                }
                break;
              }
              case "compaction_delta": {
                if (snapshotContent?.type === "compaction") {
                  snapshot.content[event.index] = {
                    ...snapshotContent,
                    content: (snapshotContent.content || "") + event.delta.content,
                    encrypted_content: event.delta.encrypted_content
                  };
                }
                break;
              }
              default:
                checkNever(event.delta);
            }
            return snapshot;
          }
          case "content_block_stop":
            return snapshot;
        }
      }, Symbol.asyncIterator)]() {
        const pushQueue = [];
        const readQueue = [];
        let done = false;
        this.on("streamEvent", (event) => {
          const reader = readQueue.shift();
          if (reader) {
            reader.resolve(event);
          } else {
            pushQueue.push(event);
          }
        });
        this.on("end", () => {
          done = true;
          for (const reader of readQueue) {
            reader.resolve(void 0);
          }
          readQueue.length = 0;
        });
        this.on("abort", (err) => {
          done = true;
          for (const reader of readQueue) {
            reader.reject(err);
          }
          readQueue.length = 0;
        });
        this.on("error", (err) => {
          done = true;
          for (const reader of readQueue) {
            reader.reject(err);
          }
          readQueue.length = 0;
        });
        return {
          next: async () => {
            if (!pushQueue.length) {
              if (done) {
                return { value: void 0, done: true };
              }
              return new Promise((resolve, reject) => readQueue.push({ resolve, reject })).then((chunk2) => chunk2 ? { value: chunk2, done: false } : { value: void 0, done: true });
            }
            const chunk = pushQueue.shift();
            return { value: chunk, done: false };
          },
          return: async () => {
            this.abort();
            return { value: void 0, done: true };
          }
        };
      }
      toReadableStream() {
        const stream = new streaming_1.Stream(this[Symbol.asyncIterator].bind(this), this.controller);
        return stream.toReadableStream();
      }
    };
    exports2.BetaMessageStream = BetaMessageStream;
    function checkNever(x) {
    }
  }
});

// node_modules/@anthropic-ai/sdk/lib/tools/CompactionControl.js
var require_CompactionControl = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/tools/CompactionControl.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.DEFAULT_SUMMARY_PROMPT = exports2.DEFAULT_TOKEN_THRESHOLD = void 0;
    exports2.DEFAULT_TOKEN_THRESHOLD = 1e5;
    exports2.DEFAULT_SUMMARY_PROMPT = `You have been working on the task described above but have not yet completed it. Write a continuation summary that will allow you (or another instance of yourself) to resume work efficiently in a future context window where the conversation history will be replaced with this summary. Your summary should be structured, concise, and actionable. Include:
1. Task Overview
The user's core request and success criteria
Any clarifications or constraints they specified
2. Current State
What has been completed so far
Files created, modified, or analyzed (with paths if relevant)
Key outputs or artifacts produced
3. Important Discoveries
Technical constraints or requirements uncovered
Decisions made and their rationale
Errors encountered and how they were resolved
What approaches were tried that didn't work (and why)
4. Next Steps
Specific actions needed to complete the task
Any blockers or open questions to resolve
Priority order if multiple steps remain
5. Context to Preserve
User preferences or style requirements
Domain-specific details that aren't obvious
Any promises made to the user
Be concise but complete\u2014err on the side of including information that would prevent duplicate work or repeated mistakes. Write in a way that enables immediate resumption of the task.
Wrap your summary in <summary></summary> tags.`;
  }
});

// node_modules/@anthropic-ai/sdk/lib/tools/BetaToolRunner.js
var require_BetaToolRunner = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/tools/BetaToolRunner.js"(exports2) {
    "use strict";
    var _BetaToolRunner_instances;
    var _BetaToolRunner_consumed;
    var _BetaToolRunner_mutated;
    var _BetaToolRunner_state;
    var _BetaToolRunner_options;
    var _BetaToolRunner_message;
    var _BetaToolRunner_toolResponse;
    var _BetaToolRunner_completion;
    var _BetaToolRunner_iterationCount;
    var _BetaToolRunner_checkAndCompact;
    var _BetaToolRunner_generateToolResponse;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.BetaToolRunner = void 0;
    var tslib_1 = require_tslib();
    var ToolError_1 = require_ToolError();
    var error_1 = require_error();
    var headers_1 = require_headers();
    var promise_1 = require_promise();
    var CompactionControl_1 = require_CompactionControl();
    var stainless_helper_header_1 = require_stainless_helper_header();
    var BetaToolRunner = class {
      constructor(client, params, options) {
        _BetaToolRunner_instances.add(this);
        this.client = client;
        _BetaToolRunner_consumed.set(this, false);
        _BetaToolRunner_mutated.set(this, false);
        _BetaToolRunner_state.set(this, void 0);
        _BetaToolRunner_options.set(this, void 0);
        _BetaToolRunner_message.set(this, void 0);
        _BetaToolRunner_toolResponse.set(this, void 0);
        _BetaToolRunner_completion.set(this, void 0);
        _BetaToolRunner_iterationCount.set(this, 0);
        tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_state, {
          params: {
            // You can't clone the entire params since there are functions as handlers.
            // You also don't really need to clone params.messages, but it probably will prevent a foot gun
            // somewhere.
            ...params,
            messages: structuredClone(params.messages)
          }
        }, "f");
        const helpers = (0, stainless_helper_header_1.collectStainlessHelpers)(params.tools, params.messages);
        const helperValue = ["BetaToolRunner", ...helpers].join(", ");
        tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_options, {
          ...options,
          headers: (0, headers_1.buildHeaders)([{ "x-stainless-helper": helperValue }, options?.headers])
        }, "f");
        tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_completion, (0, promise_1.promiseWithResolvers)(), "f");
        if (params.compactionControl?.enabled) {
          console.warn('Anthropic: The `compactionControl` parameter is deprecated and will be removed in a future version. Use server-side compaction instead by passing `edits: [{ type: "compact_20260112" }]` in the params passed to `toolRunner()`. See https://platform.claude.com/docs/en/build-with-claude/compaction');
        }
      }
      async *[(_BetaToolRunner_consumed = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_mutated = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_state = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_options = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_message = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_toolResponse = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_completion = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_iterationCount = /* @__PURE__ */ new WeakMap(), _BetaToolRunner_instances = /* @__PURE__ */ new WeakSet(), _BetaToolRunner_checkAndCompact = async function _BetaToolRunner_checkAndCompact2() {
        const compactionControl = tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.compactionControl;
        if (!compactionControl || !compactionControl.enabled) {
          return false;
        }
        let tokensUsed = 0;
        if (tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_message, "f") !== void 0) {
          try {
            const message = await tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_message, "f");
            const totalInputTokens = message.usage.input_tokens + (message.usage.cache_creation_input_tokens ?? 0) + (message.usage.cache_read_input_tokens ?? 0);
            tokensUsed = totalInputTokens + message.usage.output_tokens;
          } catch {
            return false;
          }
        }
        const threshold = compactionControl.contextTokenThreshold ?? CompactionControl_1.DEFAULT_TOKEN_THRESHOLD;
        if (tokensUsed < threshold) {
          return false;
        }
        const model = compactionControl.model ?? tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.model;
        const summaryPrompt = compactionControl.summaryPrompt ?? CompactionControl_1.DEFAULT_SUMMARY_PROMPT;
        const messages = tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.messages;
        if (messages[messages.length - 1].role === "assistant") {
          const lastMessage = messages[messages.length - 1];
          if (Array.isArray(lastMessage.content)) {
            const nonToolBlocks = lastMessage.content.filter((block) => block.type !== "tool_use");
            if (nonToolBlocks.length === 0) {
              messages.pop();
            } else {
              lastMessage.content = nonToolBlocks;
            }
          }
        }
        const response = await this.client.beta.messages.create({
          model,
          messages: [
            ...messages,
            {
              role: "user",
              content: [
                {
                  type: "text",
                  text: summaryPrompt
                }
              ]
            }
          ],
          max_tokens: tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.max_tokens
        }, {
          signal: tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_options, "f").signal,
          headers: (0, headers_1.buildHeaders)([tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_options, "f").headers, { "x-stainless-helper": "compaction" }])
        });
        if (response.content[0]?.type !== "text") {
          throw new error_1.AnthropicError("Expected text response for compaction");
        }
        tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.messages = [
          {
            role: "user",
            content: response.content
          }
        ];
        return true;
      }, Symbol.asyncIterator)]() {
        var _a;
        if (tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_consumed, "f")) {
          throw new error_1.AnthropicError("Cannot iterate over a consumed stream");
        }
        tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_consumed, true, "f");
        tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_mutated, true, "f");
        tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_toolResponse, void 0, "f");
        try {
          while (true) {
            let stream;
            try {
              if (tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.max_iterations && tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_iterationCount, "f") >= tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.max_iterations) {
                break;
              }
              tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_mutated, false, "f");
              tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_toolResponse, void 0, "f");
              tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_iterationCount, (_a = tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_iterationCount, "f"), _a++, _a), "f");
              tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_message, void 0, "f");
              const { max_iterations, compactionControl, ...params } = tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params;
              if (params.stream) {
                stream = this.client.beta.messages.stream({ ...params }, tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_options, "f"));
                tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_message, stream.finalMessage(), "f");
                tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_message, "f").catch(() => {
                });
                yield stream;
              } else {
                tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_message, this.client.beta.messages.create({ ...params, stream: false }, tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_options, "f")), "f");
                yield tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_message, "f");
              }
              const isCompacted = await tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_checkAndCompact).call(this);
              if (!isCompacted) {
                if (!tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_mutated, "f")) {
                  const { role, content } = await tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_message, "f");
                  tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.messages.push({ role, content });
                }
                const toolMessage = await tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_generateToolResponse).call(this, tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.messages.at(-1));
                if (toolMessage) {
                  tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params.messages.push(toolMessage);
                } else if (!tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_mutated, "f")) {
                  break;
                }
              }
            } finally {
              if (stream) {
                stream.abort();
              }
            }
          }
          if (!tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_message, "f")) {
            throw new error_1.AnthropicError("ToolRunner concluded without a message from the server");
          }
          tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_completion, "f").resolve(await tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_message, "f"));
        } catch (error) {
          tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_consumed, false, "f");
          tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_completion, "f").promise.catch(() => {
          });
          tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_completion, "f").reject(error);
          tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_completion, (0, promise_1.promiseWithResolvers)(), "f");
          throw error;
        }
      }
      setMessagesParams(paramsOrMutator) {
        if (typeof paramsOrMutator === "function") {
          tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params = paramsOrMutator(tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params);
        } else {
          tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params = paramsOrMutator;
        }
        tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_mutated, true, "f");
        tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_toolResponse, void 0, "f");
      }
      setRequestOptions(optionsOrMutator) {
        if (typeof optionsOrMutator === "function") {
          tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_options, optionsOrMutator(tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_options, "f")), "f");
        } else {
          tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_options, { ...tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_options, "f"), ...optionsOrMutator }, "f");
        }
      }
      /**
       * Get the tool response for the last message from the assistant.
       * Avoids redundant tool executions by caching results.
       *
       * @returns A promise that resolves to a BetaMessageParam containing tool results, or null if no tools need to be executed
       *
       * @example
       * const toolResponse = await runner.generateToolResponse();
       * if (toolResponse) {
       *   console.log('Tool results:', toolResponse.content);
       * }
       */
      async generateToolResponse(signal = tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_options, "f").signal) {
        const message = await tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_message, "f") ?? this.params.messages.at(-1);
        if (!message) {
          return null;
        }
        return tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_instances, "m", _BetaToolRunner_generateToolResponse).call(this, message, signal);
      }
      /**
       * Wait for the async iterator to complete. This works even if the async iterator hasn't yet started, and
       * will wait for an instance to start and go to completion.
       *
       * @returns A promise that resolves to the final BetaMessage when the iterator completes
       *
       * @example
       * // Start consuming the iterator
       * for await (const message of runner) {
       *   console.log('Message:', message.content);
       * }
       *
       * // Meanwhile, wait for completion from another part of the code
       * const finalMessage = await runner.done();
       * console.log('Final response:', finalMessage.content);
       */
      done() {
        return tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_completion, "f").promise;
      }
      /**
       * Returns a promise indicating that the stream is done. Unlike .done(), this will eagerly read the stream:
       * * If the iterator has not been consumed, consume the entire iterator and return the final message from the
       * assistant.
       * * If the iterator has been consumed, waits for it to complete and returns the final message.
       *
       * @returns A promise that resolves to the final BetaMessage from the conversation
       * @throws {AnthropicError} If no messages were processed during the conversation
       *
       * @example
       * const finalMessage = await runner.runUntilDone();
       * console.log('Final response:', finalMessage.content);
       */
      async runUntilDone() {
        if (!tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_consumed, "f")) {
          for await (const _ of this) {
          }
        }
        return this.done();
      }
      /**
       * Get the current parameters being used by the ToolRunner.
       *
       * @returns A readonly view of the current ToolRunnerParams
       *
       * @example
       * const currentParams = runner.params;
       * console.log('Current model:', currentParams.model);
       * console.log('Message count:', currentParams.messages.length);
       */
      get params() {
        return tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params;
      }
      /**
       * Add one or more messages to the conversation history.
       *
       * @param messages - One or more BetaMessageParam objects to add to the conversation
       *
       * @example
       * runner.pushMessages(
       *   { role: 'user', content: 'Also, what about the weather in NYC?' }
       * );
       *
       * @example
       * // Adding multiple messages
       * runner.pushMessages(
       *   { role: 'user', content: 'What about NYC?' },
       *   { role: 'user', content: 'And Boston?' }
       * );
       */
      pushMessages(...messages) {
        this.setMessagesParams((params) => ({
          ...params,
          messages: [...params.messages, ...messages]
        }));
      }
      /**
       * Makes the ToolRunner directly awaitable, equivalent to calling .runUntilDone()
       * This allows using `await runner` instead of `await runner.runUntilDone()`
       */
      then(onfulfilled, onrejected) {
        return this.runUntilDone().then(onfulfilled, onrejected);
      }
    };
    exports2.BetaToolRunner = BetaToolRunner;
    _BetaToolRunner_generateToolResponse = async function _BetaToolRunner_generateToolResponse2(lastMessage, signal = tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_options, "f").signal) {
      if (tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_toolResponse, "f") !== void 0) {
        return tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_toolResponse, "f");
      }
      tslib_1.__classPrivateFieldSet(this, _BetaToolRunner_toolResponse, generateToolResponse(tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_state, "f").params, lastMessage, {
        ...tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_options, "f"),
        signal
      }), "f");
      return tslib_1.__classPrivateFieldGet(this, _BetaToolRunner_toolResponse, "f");
    };
    async function generateToolResponse(params, lastMessage = params.messages.at(-1), requestOptions) {
      if (!lastMessage || lastMessage.role !== "assistant" || !lastMessage.content || typeof lastMessage.content === "string") {
        return null;
      }
      const toolUseBlocks = lastMessage.content.filter((content) => content.type === "tool_use");
      if (toolUseBlocks.length === 0) {
        return null;
      }
      const toolResults = await Promise.all(toolUseBlocks.map(async (toolUse) => {
        const tool = params.tools.find((t) => ("name" in t ? t.name : t.mcp_server_name) === toolUse.name);
        if (!tool || !("run" in tool)) {
          return {
            type: "tool_result",
            tool_use_id: toolUse.id,
            content: `Error: Tool '${toolUse.name}' not found`,
            is_error: true
          };
        }
        try {
          let input = toolUse.input;
          if ("parse" in tool && tool.parse) {
            input = tool.parse(input);
          }
          const result = await tool.run(input, {
            toolUse,
            toolUseBlock: toolUse,
            signal: requestOptions?.signal
          });
          return {
            type: "tool_result",
            tool_use_id: toolUse.id,
            content: result
          };
        } catch (error) {
          return {
            type: "tool_result",
            tool_use_id: toolUse.id,
            content: error instanceof ToolError_1.ToolError ? error.content : `Error: ${error instanceof Error ? error.message : String(error)}`,
            is_error: true
          };
        }
      }));
      return {
        role: "user",
        content: toolResults
      };
    }
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/messages/messages.js
var require_messages = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/messages/messages.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.ToolError = exports2.BetaToolRunner = exports2.Messages = void 0;
    var tslib_1 = require_tslib();
    var error_1 = require_error2();
    var BatchesAPI = tslib_1.__importStar(require_batches());
    var resource_1 = require_resource();
    var constants_1 = require_constants();
    var headers_1 = require_headers();
    var stainless_helper_header_1 = require_stainless_helper_header();
    var beta_parser_1 = require_beta_parser();
    var BetaMessageStream_1 = require_BetaMessageStream();
    var BetaToolRunner_1 = require_BetaToolRunner();
    var ToolError_1 = require_ToolError();
    var batches_1 = require_batches();
    var DEPRECATED_MODELS = {
      "claude-1.3": "November 6th, 2024",
      "claude-1.3-100k": "November 6th, 2024",
      "claude-instant-1.1": "November 6th, 2024",
      "claude-instant-1.1-100k": "November 6th, 2024",
      "claude-instant-1.2": "November 6th, 2024",
      "claude-3-sonnet-20240229": "July 21st, 2025",
      "claude-3-opus-20240229": "January 5th, 2026",
      "claude-2.1": "July 21st, 2025",
      "claude-2.0": "July 21st, 2025",
      "claude-3-7-sonnet-latest": "February 19th, 2026",
      "claude-3-7-sonnet-20250219": "February 19th, 2026"
    };
    var MODELS_TO_WARN_WITH_THINKING_ENABLED = ["claude-mythos-preview", "claude-opus-4-6"];
    var Messages = class extends resource_1.APIResource {
      constructor() {
        super(...arguments);
        this.batches = new BatchesAPI.Batches(this._client);
      }
      create(params, options) {
        const modifiedParams = transformOutputFormat(params);
        const { betas, ...body } = modifiedParams;
        if (body.model in DEPRECATED_MODELS) {
          console.warn(`The model '${body.model}' is deprecated and will reach end-of-life on ${DEPRECATED_MODELS[body.model]}
Please migrate to a newer model. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.`);
        }
        if (MODELS_TO_WARN_WITH_THINKING_ENABLED.includes(body.model) && body.thinking && body.thinking.type === "enabled") {
          console.warn(`Using Claude with ${body.model} and 'thinking.type=enabled' is deprecated. Use 'thinking.type=adaptive' instead which results in better model performance in our testing: https://platform.claude.com/docs/en/build-with-claude/adaptive-thinking`);
        }
        let timeout = this._client._options.timeout;
        if (!body.stream && timeout == null) {
          const maxNonstreamingTokens = constants_1.MODEL_NONSTREAMING_TOKENS[body.model] ?? void 0;
          timeout = this._client.calculateNonstreamingTimeout(body.max_tokens, maxNonstreamingTokens);
        }
        const helperHeader = (0, stainless_helper_header_1.stainlessHelperHeader)(body.tools, body.messages);
        return this._client.post("/v1/messages?beta=true", {
          body,
          timeout: timeout ?? 6e5,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
            helperHeader,
            options?.headers
          ]),
          stream: modifiedParams.stream ?? false
        });
      }
      /**
       * Send a structured list of input messages with text and/or image content, along with an expected `output_format` and
       * the response will be automatically parsed and available in the `parsed_output` property of the message.
       *
       * @example
       * ```ts
       * const message = await client.beta.messages.parse({
       *   model: 'claude-3-5-sonnet-20241022',
       *   max_tokens: 1024,
       *   messages: [{ role: 'user', content: 'What is 2+2?' }],
       *   output_format: zodOutputFormat(z.object({ answer: z.number() }), 'math'),
       * });
       *
       * console.log(message.parsed_output?.answer); // 4
       * ```
       */
      parse(params, options) {
        options = {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...params.betas ?? [], "structured-outputs-2025-12-15"].toString() },
            options?.headers
          ])
        };
        return this.create(params, options).then((message) => (0, beta_parser_1.parseBetaMessage)(message, params, { logger: this._client.logger ?? console }));
      }
      /**
       * Create a Message stream
       */
      stream(body, options) {
        return BetaMessageStream_1.BetaMessageStream.createMessage(this, body, options);
      }
      /**
       * Count the number of tokens in a Message.
       *
       * The Token Count API can be used to count the number of tokens in a Message,
       * including tools, images, and documents, without creating it.
       *
       * Learn more about token counting in our
       * [user guide](https://docs.claude.com/en/docs/build-with-claude/token-counting)
       *
       * @example
       * ```ts
       * const betaMessageTokensCount =
       *   await client.beta.messages.countTokens({
       *     messages: [{ content: 'Hello, world', role: 'user' }],
       *     model: 'claude-opus-4-6',
       *   });
       * ```
       */
      countTokens(params, options) {
        const modifiedParams = transformOutputFormat(params);
        const { betas, ...body } = modifiedParams;
        return this._client.post("/v1/messages/count_tokens?beta=true", {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "token-counting-2024-11-01"].toString() },
            options?.headers
          ])
        });
      }
      toolRunner(body, options) {
        return new BetaToolRunner_1.BetaToolRunner(this._client, body, options);
      }
    };
    exports2.Messages = Messages;
    function transformOutputFormat(params) {
      if (!params.output_format) {
        return params;
      }
      if (params.output_config?.format) {
        throw new error_1.AnthropicError("Both output_format and output_config.format were provided. Please use only output_config.format (output_format is deprecated).");
      }
      const { output_format, ...rest } = params;
      return {
        ...rest,
        output_config: {
          ...params.output_config,
          format: output_format
        }
      };
    }
    var BetaToolRunner_2 = require_BetaToolRunner();
    Object.defineProperty(exports2, "BetaToolRunner", { enumerable: true, get: function() {
      return BetaToolRunner_2.BetaToolRunner;
    } });
    var ToolError_2 = require_ToolError();
    Object.defineProperty(exports2, "ToolError", { enumerable: true, get: function() {
      return ToolError_2.ToolError;
    } });
    Messages.Batches = batches_1.Batches;
    Messages.BetaToolRunner = BetaToolRunner_1.BetaToolRunner;
    Messages.ToolError = ToolError_1.ToolError;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/sessions/events.js
var require_events = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/sessions/events.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.SessionToolRunner = exports2.Events = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var SessionToolRunner_1 = require_SessionToolRunner();
    var Events = class extends resource_1.APIResource {
      /**
       * List Events
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaManagedAgentsSessionEvent of client.beta.sessions.events.list(
       *   'sesn_011CZkZAtmR3yMPDzynEDxu7',
       * )) {
       *   // ...
       * }
       * ```
       */
      list(sessionID, params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList((0, path_1.path)`/v1/sessions/${sessionID}/events?beta=true`, pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Send Events
       *
       * @example
       * ```ts
       * const betaManagedAgentsSendSessionEvents =
       *   await client.beta.sessions.events.send(
       *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
       *     {
       *       events: [
       *         {
       *           content: [
       *             {
       *               text: 'Where is my order #1234?',
       *               type: 'text',
       *             },
       *           ],
       *           type: 'user.message',
       *         },
       *       ],
       *     },
       *   );
       * ```
       */
      send(sessionID, params, options) {
        const { betas, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/sessions/${sessionID}/events?beta=true`, {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Stream Events
       *
       * @example
       * ```ts
       * const betaManagedAgentsStreamSessionEvents =
       *   await client.beta.sessions.events.stream(
       *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
       *   );
       * ```
       */
      stream(sessionID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/sessions/${sessionID}/events/stream?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ]),
          stream: true
        });
      }
      /**
       * Attach to a session and dispatch every incoming `agent.tool_use` and
       * `agent.custom_tool_use` event to a local tool registry, sending the matching
       * result back (`user.tool_result` / `user.custom_tool_result`). The
       * sessions-side counterpart to `client.beta.messages.toolRunner`: yields one
       * entry per completed tool call so callers can observe each dispatch (and
       * `break` to abort cleanly).
       *
       * @example
       * ```ts
       * import { betaAgentToolset20260401 } from '@anthropic-ai/sdk/tools/agent-toolset/node';
       *
       * for await (const call of client.beta.sessions.events.toolRunner(work.data.id, {
       *   tools: [...betaAgentToolset20260401({ workdir }), myTool],
       * })) {
       *   console.log(`${call.name} -> ${call.isError ? 'error' : 'ok'}`);
       * }
       * ```
       */
      toolRunner(sessionID, opts) {
        return new SessionToolRunner_1.SessionToolRunner(sessionID, { ...opts, client: this._client });
      }
    };
    exports2.Events = Events;
    var SessionToolRunner_2 = require_SessionToolRunner();
    Object.defineProperty(exports2, "SessionToolRunner", { enumerable: true, get: function() {
      return SessionToolRunner_2.SessionToolRunner;
    } });
    Events.SessionToolRunner = SessionToolRunner_1.SessionToolRunner;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/sessions/resources.js
var require_resources = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/sessions/resources.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Resources = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Resources = class extends resource_1.APIResource {
      /**
       * Get Session Resource
       *
       * @example
       * ```ts
       * const resource =
       *   await client.beta.sessions.resources.retrieve(
       *     'sesrsc_011CZkZBJq5dWxk9fVLNcPht',
       *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
       *   );
       * ```
       */
      retrieve(resourceID, params, options) {
        const { session_id, betas } = params;
        return this._client.get((0, path_1.path)`/v1/sessions/${session_id}/resources/${resourceID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Update Session Resource
       *
       * @example
       * ```ts
       * const resource =
       *   await client.beta.sessions.resources.update(
       *     'sesrsc_011CZkZBJq5dWxk9fVLNcPht',
       *     {
       *       session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7',
       *       authorization_token: 'ghp_exampletoken',
       *     },
       *   );
       * ```
       */
      update(resourceID, params, options) {
        const { session_id, betas, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/sessions/${session_id}/resources/${resourceID}?beta=true`, {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * List Session Resources
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaManagedAgentsSessionResource of client.beta.sessions.resources.list(
       *   'sesn_011CZkZAtmR3yMPDzynEDxu7',
       * )) {
       *   // ...
       * }
       * ```
       */
      list(sessionID, params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList((0, path_1.path)`/v1/sessions/${sessionID}/resources?beta=true`, pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Delete Session Resource
       *
       * @example
       * ```ts
       * const betaManagedAgentsDeleteSessionResource =
       *   await client.beta.sessions.resources.delete(
       *     'sesrsc_011CZkZBJq5dWxk9fVLNcPht',
       *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
       *   );
       * ```
       */
      delete(resourceID, params, options) {
        const { session_id, betas } = params;
        return this._client.delete((0, path_1.path)`/v1/sessions/${session_id}/resources/${resourceID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Add Session Resource
       *
       * @example
       * ```ts
       * const betaManagedAgentsFileResource =
       *   await client.beta.sessions.resources.add(
       *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
       *     {
       *       file_id: 'file_011CNha8iCJcU1wXNR6q4V8w',
       *       type: 'file',
       *     },
       *   );
       * ```
       */
      add(sessionID, params, options) {
        const { betas, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/sessions/${sessionID}/resources?beta=true`, {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
    };
    exports2.Resources = Resources;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/sessions/threads/events.js
var require_events2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/sessions/threads/events.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Events = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Events = class extends resource_1.APIResource {
      /**
       * List Session Thread Events
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaManagedAgentsSessionEvent of client.beta.sessions.threads.events.list(
       *   'sthr_011CZkZVWa6oIjw0rgXZpnBt',
       *   { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
       * )) {
       *   // ...
       * }
       * ```
       */
      list(threadID, params, options) {
        const { session_id, betas, ...query } = params;
        return this._client.getAPIList((0, path_1.path)`/v1/sessions/${session_id}/threads/${threadID}/events?beta=true`, pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Stream Session Thread Events
       *
       * @example
       * ```ts
       * const betaManagedAgentsStreamSessionThreadEvents =
       *   await client.beta.sessions.threads.events.stream(
       *     'sthr_011CZkZVWa6oIjw0rgXZpnBt',
       *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
       *   );
       * ```
       */
      stream(threadID, params, options) {
        const { session_id, betas } = params;
        return this._client.get((0, path_1.path)`/v1/sessions/${session_id}/threads/${threadID}/stream?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ]),
          stream: true
        });
      }
    };
    exports2.Events = Events;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/sessions/threads/threads.js
var require_threads = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/sessions/threads/threads.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Threads = void 0;
    var tslib_1 = require_tslib();
    var resource_1 = require_resource();
    var ThreadsEventsAPI = tslib_1.__importStar(require_events2());
    var events_1 = require_events2();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Threads = class extends resource_1.APIResource {
      constructor() {
        super(...arguments);
        this.events = new ThreadsEventsAPI.Events(this._client);
      }
      /**
       * Get Session Thread
       *
       * @example
       * ```ts
       * const betaManagedAgentsSessionThread =
       *   await client.beta.sessions.threads.retrieve(
       *     'sthr_011CZkZVWa6oIjw0rgXZpnBt',
       *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
       *   );
       * ```
       */
      retrieve(threadID, params, options) {
        const { session_id, betas } = params;
        return this._client.get((0, path_1.path)`/v1/sessions/${session_id}/threads/${threadID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * List Session Threads
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaManagedAgentsSessionThread of client.beta.sessions.threads.list(
       *   'sesn_011CZkZAtmR3yMPDzynEDxu7',
       * )) {
       *   // ...
       * }
       * ```
       */
      list(sessionID, params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList((0, path_1.path)`/v1/sessions/${sessionID}/threads?beta=true`, pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Archive Session Thread
       *
       * @example
       * ```ts
       * const betaManagedAgentsSessionThread =
       *   await client.beta.sessions.threads.archive(
       *     'sthr_011CZkZVWa6oIjw0rgXZpnBt',
       *     { session_id: 'sesn_011CZkZAtmR3yMPDzynEDxu7' },
       *   );
       * ```
       */
      archive(threadID, params, options) {
        const { session_id, betas } = params;
        return this._client.post((0, path_1.path)`/v1/sessions/${session_id}/threads/${threadID}/archive?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
    };
    exports2.Threads = Threads;
    Threads.Events = events_1.Events;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/sessions/sessions.js
var require_sessions = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/sessions/sessions.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Sessions = void 0;
    var tslib_1 = require_tslib();
    var resource_1 = require_resource();
    var EventsAPI = tslib_1.__importStar(require_events());
    var events_1 = require_events();
    var ResourcesAPI = tslib_1.__importStar(require_resources());
    var resources_1 = require_resources();
    var ThreadsAPI = tslib_1.__importStar(require_threads());
    var threads_1 = require_threads();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Sessions = class extends resource_1.APIResource {
      constructor() {
        super(...arguments);
        this.events = new EventsAPI.Events(this._client);
        this.resources = new ResourcesAPI.Resources(this._client);
        this.threads = new ThreadsAPI.Threads(this._client);
      }
      /**
       * Create Session
       *
       * @example
       * ```ts
       * const betaManagedAgentsSession =
       *   await client.beta.sessions.create({
       *     agent: 'agent_011CZkYpogX7uDKUyvBTophP',
       *     environment_id: 'env_011CZkZ9X2dpNyB7HsEFoRfW',
       *   });
       * ```
       */
      create(params, options) {
        const { betas, ...body } = params;
        return this._client.post("/v1/sessions?beta=true", {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Get Session
       *
       * @example
       * ```ts
       * const betaManagedAgentsSession =
       *   await client.beta.sessions.retrieve(
       *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
       *   );
       * ```
       */
      retrieve(sessionID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/sessions/${sessionID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Update Session
       *
       * @example
       * ```ts
       * const betaManagedAgentsSession =
       *   await client.beta.sessions.update(
       *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
       *   );
       * ```
       */
      update(sessionID, params, options) {
        const { betas, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/sessions/${sessionID}?beta=true`, {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * List Sessions
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaManagedAgentsSession of client.beta.sessions.list()) {
       *   // ...
       * }
       * ```
       */
      list(params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList("/v1/sessions?beta=true", pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Delete Session
       *
       * @example
       * ```ts
       * const betaManagedAgentsDeletedSession =
       *   await client.beta.sessions.delete(
       *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
       *   );
       * ```
       */
      delete(sessionID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.delete((0, path_1.path)`/v1/sessions/${sessionID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Archive Session
       *
       * @example
       * ```ts
       * const betaManagedAgentsSession =
       *   await client.beta.sessions.archive(
       *     'sesn_011CZkZAtmR3yMPDzynEDxu7',
       *   );
       * ```
       */
      archive(sessionID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.post((0, path_1.path)`/v1/sessions/${sessionID}/archive?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
    };
    exports2.Sessions = Sessions;
    Sessions.Events = events_1.Events;
    Sessions.Resources = resources_1.Resources;
    Sessions.Threads = threads_1.Threads;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/skills/versions.js
var require_versions2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/skills/versions.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Versions = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var uploads_1 = require_uploads();
    var path_1 = require_path();
    var Versions = class extends resource_1.APIResource {
      /**
       * Create Skill Version
       *
       * @example
       * ```ts
       * const version = await client.beta.skills.versions.create(
       *   'skill_id',
       * );
       * ```
       */
      create(skillID, params = {}, options) {
        const { betas, ...body } = params ?? {};
        return this._client.post((0, path_1.path)`/v1/skills/${skillID}/versions?beta=true`, (0, uploads_1.multipartFormRequestOptions)({
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "skills-2025-10-02"].toString() },
            options?.headers
          ])
        }, this._client, false));
      }
      /**
       * Get Skill Version
       *
       * @example
       * ```ts
       * const version = await client.beta.skills.versions.retrieve(
       *   'version',
       *   { skill_id: 'skill_id' },
       * );
       * ```
       */
      retrieve(version, params, options) {
        const { skill_id, betas } = params;
        return this._client.get((0, path_1.path)`/v1/skills/${skill_id}/versions/${version}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "skills-2025-10-02"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * List Skill Versions
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const versionListResponse of client.beta.skills.versions.list(
       *   'skill_id',
       * )) {
       *   // ...
       * }
       * ```
       */
      list(skillID, params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList((0, path_1.path)`/v1/skills/${skillID}/versions?beta=true`, pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "skills-2025-10-02"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Delete Skill Version
       *
       * @example
       * ```ts
       * const version = await client.beta.skills.versions.delete(
       *   'version',
       *   { skill_id: 'skill_id' },
       * );
       * ```
       */
      delete(version, params, options) {
        const { skill_id, betas } = params;
        return this._client.delete((0, path_1.path)`/v1/skills/${skill_id}/versions/${version}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "skills-2025-10-02"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Download a skill version's content as a zip archive.
       *
       * @example
       * ```ts
       * const response = await client.beta.skills.versions.download(
       *   'version',
       *   { skill_id: 'skill_id' },
       * );
       *
       * const content = await response.blob();
       * console.log(content);
       * ```
       */
      download(version, params, options) {
        const { skill_id, betas } = params;
        return this._client.get((0, path_1.path)`/v1/skills/${skill_id}/versions/${version}/content?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            {
              "anthropic-beta": [...betas ?? [], "skills-2025-10-02"].toString(),
              Accept: "application/binary"
            },
            options?.headers
          ]),
          __binaryResponse: true
        });
      }
    };
    exports2.Versions = Versions;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/skills/skills.js
var require_skills2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/skills/skills.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Skills = void 0;
    var tslib_1 = require_tslib();
    var resource_1 = require_resource();
    var VersionsAPI = tslib_1.__importStar(require_versions2());
    var versions_1 = require_versions2();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var uploads_1 = require_uploads();
    var path_1 = require_path();
    var Skills = class extends resource_1.APIResource {
      constructor() {
        super(...arguments);
        this.versions = new VersionsAPI.Versions(this._client);
      }
      /**
       * Create Skill
       *
       * @example
       * ```ts
       * const skill = await client.beta.skills.create();
       * ```
       */
      create(params = {}, options) {
        const { betas, ...body } = params ?? {};
        return this._client.post("/v1/skills?beta=true", (0, uploads_1.multipartFormRequestOptions)({
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "skills-2025-10-02"].toString() },
            options?.headers
          ])
        }, this._client, false));
      }
      /**
       * Get Skill
       *
       * @example
       * ```ts
       * const skill = await client.beta.skills.retrieve('skill_id');
       * ```
       */
      retrieve(skillID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/skills/${skillID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "skills-2025-10-02"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * List Skills
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const skillListResponse of client.beta.skills.list()) {
       *   // ...
       * }
       * ```
       */
      list(params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList("/v1/skills?beta=true", pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "skills-2025-10-02"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Delete Skill
       *
       * @example
       * ```ts
       * const skill = await client.beta.skills.delete('skill_id');
       * ```
       */
      delete(skillID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.delete((0, path_1.path)`/v1/skills/${skillID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "skills-2025-10-02"].toString() },
            options?.headers
          ])
        });
      }
    };
    exports2.Skills = Skills;
    Skills.Versions = versions_1.Versions;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/vaults/credentials.js
var require_credentials2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/vaults/credentials.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Credentials = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Credentials = class extends resource_1.APIResource {
      /**
       * Create Credential
       *
       * @example
       * ```ts
       * const betaManagedAgentsCredential =
       *   await client.beta.vaults.credentials.create(
       *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
       *     {
       *       auth: {
       *         token: 'bearer_exampletoken',
       *         mcp_server_url:
       *           'https://example-server.modelcontextprotocol.io/sse',
       *         type: 'static_bearer',
       *       },
       *     },
       *   );
       * ```
       */
      create(vaultID, params, options) {
        const { betas, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/vaults/${vaultID}/credentials?beta=true`, {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Get Credential
       *
       * @example
       * ```ts
       * const betaManagedAgentsCredential =
       *   await client.beta.vaults.credentials.retrieve(
       *     'vcrd_011CZkZEMt8gZan2iYOQfSkw',
       *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
       *   );
       * ```
       */
      retrieve(credentialID, params, options) {
        const { vault_id, betas } = params;
        return this._client.get((0, path_1.path)`/v1/vaults/${vault_id}/credentials/${credentialID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Update Credential
       *
       * @example
       * ```ts
       * const betaManagedAgentsCredential =
       *   await client.beta.vaults.credentials.update(
       *     'vcrd_011CZkZEMt8gZan2iYOQfSkw',
       *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
       *   );
       * ```
       */
      update(credentialID, params, options) {
        const { vault_id, betas, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/vaults/${vault_id}/credentials/${credentialID}?beta=true`, {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * List Credentials
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaManagedAgentsCredential of client.beta.vaults.credentials.list(
       *   'vlt_011CZkZDLs7fYzm1hXNPeRjv',
       * )) {
       *   // ...
       * }
       * ```
       */
      list(vaultID, params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList((0, path_1.path)`/v1/vaults/${vaultID}/credentials?beta=true`, pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Delete Credential
       *
       * @example
       * ```ts
       * const betaManagedAgentsDeletedCredential =
       *   await client.beta.vaults.credentials.delete(
       *     'vcrd_011CZkZEMt8gZan2iYOQfSkw',
       *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
       *   );
       * ```
       */
      delete(credentialID, params, options) {
        const { vault_id, betas } = params;
        return this._client.delete((0, path_1.path)`/v1/vaults/${vault_id}/credentials/${credentialID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Archive Credential
       *
       * @example
       * ```ts
       * const betaManagedAgentsCredential =
       *   await client.beta.vaults.credentials.archive(
       *     'vcrd_011CZkZEMt8gZan2iYOQfSkw',
       *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
       *   );
       * ```
       */
      archive(credentialID, params, options) {
        const { vault_id, betas } = params;
        return this._client.post((0, path_1.path)`/v1/vaults/${vault_id}/credentials/${credentialID}/archive?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Validate Credential
       *
       * @example
       * ```ts
       * const betaManagedAgentsCredentialValidation =
       *   await client.beta.vaults.credentials.mcpOAuthValidate(
       *     'vcrd_011CZkZEMt8gZan2iYOQfSkw',
       *     { vault_id: 'vlt_011CZkZDLs7fYzm1hXNPeRjv' },
       *   );
       * ```
       */
      mcpOAuthValidate(credentialID, params, options) {
        const { vault_id, betas } = params;
        return this._client.post((0, path_1.path)`/v1/vaults/${vault_id}/credentials/${credentialID}/mcp_oauth_validate?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
    };
    exports2.Credentials = Credentials;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/vaults/vaults.js
var require_vaults = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/vaults/vaults.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Vaults = void 0;
    var tslib_1 = require_tslib();
    var resource_1 = require_resource();
    var CredentialsAPI = tslib_1.__importStar(require_credentials2());
    var credentials_1 = require_credentials2();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Vaults = class extends resource_1.APIResource {
      constructor() {
        super(...arguments);
        this.credentials = new CredentialsAPI.Credentials(this._client);
      }
      /**
       * Create Vault
       *
       * @example
       * ```ts
       * const betaManagedAgentsVault =
       *   await client.beta.vaults.create({
       *     display_name: 'Example vault',
       *   });
       * ```
       */
      create(params, options) {
        const { betas, ...body } = params;
        return this._client.post("/v1/vaults?beta=true", {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Get Vault
       *
       * @example
       * ```ts
       * const betaManagedAgentsVault =
       *   await client.beta.vaults.retrieve(
       *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
       *   );
       * ```
       */
      retrieve(vaultID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/vaults/${vaultID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Update Vault
       *
       * @example
       * ```ts
       * const betaManagedAgentsVault =
       *   await client.beta.vaults.update(
       *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
       *   );
       * ```
       */
      update(vaultID, params, options) {
        const { betas, ...body } = params;
        return this._client.post((0, path_1.path)`/v1/vaults/${vaultID}?beta=true`, {
          body,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * List Vaults
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const betaManagedAgentsVault of client.beta.vaults.list()) {
       *   // ...
       * }
       * ```
       */
      list(params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList("/v1/vaults?beta=true", pagination_1.PageCursor, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Delete Vault
       *
       * @example
       * ```ts
       * const betaManagedAgentsDeletedVault =
       *   await client.beta.vaults.delete(
       *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
       *   );
       * ```
       */
      delete(vaultID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.delete((0, path_1.path)`/v1/vaults/${vaultID}?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
      /**
       * Archive Vault
       *
       * @example
       * ```ts
       * const betaManagedAgentsVault =
       *   await client.beta.vaults.archive(
       *     'vlt_011CZkZDLs7fYzm1hXNPeRjv',
       *   );
       * ```
       */
      archive(vaultID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.post((0, path_1.path)`/v1/vaults/${vaultID}/archive?beta=true`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { "anthropic-beta": [...betas ?? [], "managed-agents-2026-04-01"].toString() },
            options?.headers
          ])
        });
      }
    };
    exports2.Vaults = Vaults;
    Vaults.Credentials = credentials_1.Credentials;
  }
});

// node_modules/@anthropic-ai/sdk/resources/beta/beta.js
var require_beta = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/beta/beta.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Beta = void 0;
    var tslib_1 = require_tslib();
    var resource_1 = require_resource();
    var FilesAPI = tslib_1.__importStar(require_files());
    var files_1 = require_files();
    var ModelsAPI = tslib_1.__importStar(require_models());
    var models_1 = require_models();
    var UserProfilesAPI = tslib_1.__importStar(require_user_profiles());
    var user_profiles_1 = require_user_profiles();
    var WebhooksAPI = tslib_1.__importStar(require_webhooks());
    var webhooks_1 = require_webhooks();
    var AgentsAPI = tslib_1.__importStar(require_agents());
    var agents_1 = require_agents();
    var EnvironmentsAPI = tslib_1.__importStar(require_environments());
    var environments_1 = require_environments();
    var MemoryStoresAPI = tslib_1.__importStar(require_memory_stores());
    var memory_stores_1 = require_memory_stores();
    var MessagesAPI = tslib_1.__importStar(require_messages());
    var messages_1 = require_messages();
    var SessionsAPI = tslib_1.__importStar(require_sessions());
    var sessions_1 = require_sessions();
    var SkillsAPI = tslib_1.__importStar(require_skills2());
    var skills_1 = require_skills2();
    var VaultsAPI = tslib_1.__importStar(require_vaults());
    var vaults_1 = require_vaults();
    var Beta = class extends resource_1.APIResource {
      constructor() {
        super(...arguments);
        this.models = new ModelsAPI.Models(this._client);
        this.messages = new MessagesAPI.Messages(this._client);
        this.agents = new AgentsAPI.Agents(this._client);
        this.environments = new EnvironmentsAPI.Environments(this._client);
        this.sessions = new SessionsAPI.Sessions(this._client);
        this.vaults = new VaultsAPI.Vaults(this._client);
        this.memoryStores = new MemoryStoresAPI.MemoryStores(this._client);
        this.files = new FilesAPI.Files(this._client);
        this.skills = new SkillsAPI.Skills(this._client);
        this.webhooks = new WebhooksAPI.Webhooks(this._client);
        this.userProfiles = new UserProfilesAPI.UserProfiles(this._client);
      }
    };
    exports2.Beta = Beta;
    Beta.Models = models_1.Models;
    Beta.Messages = messages_1.Messages;
    Beta.Agents = agents_1.Agents;
    Beta.Environments = environments_1.Environments;
    Beta.Sessions = sessions_1.Sessions;
    Beta.Vaults = vaults_1.Vaults;
    Beta.MemoryStores = memory_stores_1.MemoryStores;
    Beta.Files = files_1.Files;
    Beta.Skills = skills_1.Skills;
    Beta.Webhooks = webhooks_1.Webhooks;
    Beta.UserProfiles = user_profiles_1.UserProfiles;
  }
});

// node_modules/@anthropic-ai/sdk/resources/completions.js
var require_completions = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/completions.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Completions = void 0;
    var resource_1 = require_resource();
    var headers_1 = require_headers();
    var Completions = class extends resource_1.APIResource {
      create(params, options) {
        const { betas, ...body } = params;
        return this._client.post("/v1/complete", {
          body,
          timeout: this._client._options.timeout ?? 6e5,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
            options?.headers
          ]),
          stream: params.stream ?? false
        });
      }
    };
    exports2.Completions = Completions;
  }
});

// node_modules/@anthropic-ai/sdk/lib/parser.js
var require_parser2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/parser.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.maybeParseMessage = maybeParseMessage;
    exports2.parseMessage = parseMessage;
    var error_1 = require_error();
    function getOutputFormat(params) {
      return params?.output_config?.format;
    }
    function maybeParseMessage(message, params, opts) {
      const outputFormat = getOutputFormat(params);
      if (!params || !("parse" in (outputFormat ?? {}))) {
        return {
          ...message,
          content: message.content.map((block) => {
            if (block.type === "text") {
              const parsedBlock = Object.defineProperty({ ...block }, "parsed_output", {
                value: null,
                enumerable: false
              });
              return parsedBlock;
            }
            return block;
          }),
          parsed_output: null
        };
      }
      return parseMessage(message, params, opts);
    }
    function parseMessage(message, params, opts) {
      let firstParsedOutput = null;
      const content = message.content.map((block) => {
        if (block.type === "text") {
          const parsedOutput = parseOutputFormat(params, block.text);
          if (firstParsedOutput === null) {
            firstParsedOutput = parsedOutput;
          }
          const parsedBlock = Object.defineProperty({ ...block }, "parsed_output", {
            value: parsedOutput,
            enumerable: false
          });
          return parsedBlock;
        }
        return block;
      });
      return {
        ...message,
        content,
        parsed_output: firstParsedOutput
      };
    }
    function parseOutputFormat(params, content) {
      const outputFormat = getOutputFormat(params);
      if (outputFormat?.type !== "json_schema") {
        return null;
      }
      try {
        if ("parse" in outputFormat) {
          return outputFormat.parse(content);
        }
        return JSON.parse(content);
      } catch (error) {
        throw new error_1.AnthropicError(`Failed to parse structured output: ${error}`);
      }
    }
  }
});

// node_modules/@anthropic-ai/sdk/lib/MessageStream.js
var require_MessageStream = __commonJS({
  "node_modules/@anthropic-ai/sdk/lib/MessageStream.js"(exports2) {
    "use strict";
    var _MessageStream_instances;
    var _MessageStream_currentMessageSnapshot;
    var _MessageStream_params;
    var _MessageStream_connectedPromise;
    var _MessageStream_resolveConnectedPromise;
    var _MessageStream_rejectConnectedPromise;
    var _MessageStream_endPromise;
    var _MessageStream_resolveEndPromise;
    var _MessageStream_rejectEndPromise;
    var _MessageStream_listeners;
    var _MessageStream_ended;
    var _MessageStream_errored;
    var _MessageStream_aborted;
    var _MessageStream_catchingPromiseCreated;
    var _MessageStream_response;
    var _MessageStream_request_id;
    var _MessageStream_logger;
    var _MessageStream_getFinalMessage;
    var _MessageStream_getFinalText;
    var _MessageStream_handleError;
    var _MessageStream_beginRequest;
    var _MessageStream_addStreamEvent;
    var _MessageStream_endRequest;
    var _MessageStream_accumulateMessage;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.MessageStream = void 0;
    var tslib_1 = require_tslib();
    var errors_1 = require_errors();
    var error_1 = require_error2();
    var streaming_1 = require_streaming2();
    var parser_1 = require_parser();
    var parser_2 = require_parser2();
    var JSON_BUF_PROPERTY = "__json_buf";
    function tracksToolInput(content) {
      return content.type === "tool_use" || content.type === "server_tool_use";
    }
    var MessageStream = class _MessageStream {
      constructor(params, opts) {
        _MessageStream_instances.add(this);
        this.messages = [];
        this.receivedMessages = [];
        _MessageStream_currentMessageSnapshot.set(this, void 0);
        _MessageStream_params.set(this, null);
        this.controller = new AbortController();
        _MessageStream_connectedPromise.set(this, void 0);
        _MessageStream_resolveConnectedPromise.set(this, () => {
        });
        _MessageStream_rejectConnectedPromise.set(this, () => {
        });
        _MessageStream_endPromise.set(this, void 0);
        _MessageStream_resolveEndPromise.set(this, () => {
        });
        _MessageStream_rejectEndPromise.set(this, () => {
        });
        _MessageStream_listeners.set(this, {});
        _MessageStream_ended.set(this, false);
        _MessageStream_errored.set(this, false);
        _MessageStream_aborted.set(this, false);
        _MessageStream_catchingPromiseCreated.set(this, false);
        _MessageStream_response.set(this, void 0);
        _MessageStream_request_id.set(this, void 0);
        _MessageStream_logger.set(this, void 0);
        _MessageStream_handleError.set(this, (error) => {
          tslib_1.__classPrivateFieldSet(this, _MessageStream_errored, true, "f");
          if ((0, errors_1.isAbortError)(error)) {
            error = new error_1.APIUserAbortError();
          }
          if (error instanceof error_1.APIUserAbortError) {
            tslib_1.__classPrivateFieldSet(this, _MessageStream_aborted, true, "f");
            return this._emit("abort", error);
          }
          if (error instanceof error_1.AnthropicError) {
            return this._emit("error", error);
          }
          if (error instanceof Error) {
            const anthropicError = new error_1.AnthropicError(error.message);
            anthropicError.cause = error;
            return this._emit("error", anthropicError);
          }
          return this._emit("error", new error_1.AnthropicError(String(error)));
        });
        tslib_1.__classPrivateFieldSet(this, _MessageStream_connectedPromise, new Promise((resolve, reject) => {
          tslib_1.__classPrivateFieldSet(this, _MessageStream_resolveConnectedPromise, resolve, "f");
          tslib_1.__classPrivateFieldSet(this, _MessageStream_rejectConnectedPromise, reject, "f");
        }), "f");
        tslib_1.__classPrivateFieldSet(this, _MessageStream_endPromise, new Promise((resolve, reject) => {
          tslib_1.__classPrivateFieldSet(this, _MessageStream_resolveEndPromise, resolve, "f");
          tslib_1.__classPrivateFieldSet(this, _MessageStream_rejectEndPromise, reject, "f");
        }), "f");
        tslib_1.__classPrivateFieldGet(this, _MessageStream_connectedPromise, "f").catch(() => {
        });
        tslib_1.__classPrivateFieldGet(this, _MessageStream_endPromise, "f").catch(() => {
        });
        tslib_1.__classPrivateFieldSet(this, _MessageStream_params, params, "f");
        tslib_1.__classPrivateFieldSet(this, _MessageStream_logger, opts?.logger ?? console, "f");
      }
      get response() {
        return tslib_1.__classPrivateFieldGet(this, _MessageStream_response, "f");
      }
      get request_id() {
        return tslib_1.__classPrivateFieldGet(this, _MessageStream_request_id, "f");
      }
      /**
       * Returns the `MessageStream` data, the raw `Response` instance and the ID of the request,
       * returned vie the `request-id` header which is useful for debugging requests and resporting
       * issues to Anthropic.
       *
       * This is the same as the `APIPromise.withResponse()` method.
       *
       * This method will raise an error if you created the stream using `MessageStream.fromReadableStream`
       * as no `Response` is available.
       */
      async withResponse() {
        tslib_1.__classPrivateFieldSet(this, _MessageStream_catchingPromiseCreated, true, "f");
        const response = await tslib_1.__classPrivateFieldGet(this, _MessageStream_connectedPromise, "f");
        if (!response) {
          throw new Error("Could not resolve a `Response` object");
        }
        return {
          data: this,
          response,
          request_id: response.headers.get("request-id")
        };
      }
      /**
       * Intended for use on the frontend, consuming a stream produced with
       * `.toReadableStream()` on the backend.
       *
       * Note that messages sent to the model do not appear in `.on('message')`
       * in this context.
       */
      static fromReadableStream(stream) {
        const runner = new _MessageStream(null);
        runner._run(() => runner._fromReadableStream(stream));
        return runner;
      }
      static createMessage(messages, params, options, { logger } = {}) {
        const runner = new _MessageStream(params, { logger });
        for (const message of params.messages) {
          runner._addMessageParam(message);
        }
        tslib_1.__classPrivateFieldSet(runner, _MessageStream_params, { ...params, stream: true }, "f");
        runner._run(() => runner._createMessage(messages, { ...params, stream: true }, { ...options, headers: { ...options?.headers, "X-Stainless-Helper-Method": "stream" } }));
        return runner;
      }
      _run(executor) {
        executor().then(() => {
          this._emitFinal();
          this._emit("end");
        }, tslib_1.__classPrivateFieldGet(this, _MessageStream_handleError, "f"));
      }
      _addMessageParam(message) {
        this.messages.push(message);
      }
      _addMessage(message, emit = true) {
        this.receivedMessages.push(message);
        if (emit) {
          this._emit("message", message);
        }
      }
      async _createMessage(messages, params, options) {
        const signal = options?.signal;
        let abortHandler;
        if (signal) {
          if (signal.aborted)
            this.controller.abort();
          abortHandler = this.controller.abort.bind(this.controller);
          signal.addEventListener("abort", abortHandler);
        }
        try {
          tslib_1.__classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_beginRequest).call(this);
          const { response, data: stream } = await messages.create({ ...params, stream: true }, { ...options, signal: this.controller.signal }).withResponse();
          this._connected(response);
          for await (const event of stream) {
            tslib_1.__classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_addStreamEvent).call(this, event);
          }
          if (stream.controller.signal?.aborted) {
            throw new error_1.APIUserAbortError();
          }
          tslib_1.__classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_endRequest).call(this);
        } finally {
          if (signal && abortHandler) {
            signal.removeEventListener("abort", abortHandler);
          }
        }
      }
      _connected(response) {
        if (this.ended)
          return;
        tslib_1.__classPrivateFieldSet(this, _MessageStream_response, response, "f");
        tslib_1.__classPrivateFieldSet(this, _MessageStream_request_id, response?.headers.get("request-id"), "f");
        tslib_1.__classPrivateFieldGet(this, _MessageStream_resolveConnectedPromise, "f").call(this, response);
        this._emit("connect");
      }
      get ended() {
        return tslib_1.__classPrivateFieldGet(this, _MessageStream_ended, "f");
      }
      get errored() {
        return tslib_1.__classPrivateFieldGet(this, _MessageStream_errored, "f");
      }
      get aborted() {
        return tslib_1.__classPrivateFieldGet(this, _MessageStream_aborted, "f");
      }
      abort() {
        this.controller.abort();
      }
      /**
       * Adds the listener function to the end of the listeners array for the event.
       * No checks are made to see if the listener has already been added. Multiple calls passing
       * the same combination of event and listener will result in the listener being added, and
       * called, multiple times.
       * @returns this MessageStream, so that calls can be chained
       */
      on(event, listener) {
        const listeners = tslib_1.__classPrivateFieldGet(this, _MessageStream_listeners, "f")[event] || (tslib_1.__classPrivateFieldGet(this, _MessageStream_listeners, "f")[event] = []);
        listeners.push({ listener });
        return this;
      }
      /**
       * Removes the specified listener from the listener array for the event.
       * off() will remove, at most, one instance of a listener from the listener array. If any single
       * listener has been added multiple times to the listener array for the specified event, then
       * off() must be called multiple times to remove each instance.
       * @returns this MessageStream, so that calls can be chained
       */
      off(event, listener) {
        const listeners = tslib_1.__classPrivateFieldGet(this, _MessageStream_listeners, "f")[event];
        if (!listeners)
          return this;
        const index = listeners.findIndex((l) => l.listener === listener);
        if (index >= 0)
          listeners.splice(index, 1);
        return this;
      }
      /**
       * Adds a one-time listener function for the event. The next time the event is triggered,
       * this listener is removed and then invoked.
       * @returns this MessageStream, so that calls can be chained
       */
      once(event, listener) {
        const listeners = tslib_1.__classPrivateFieldGet(this, _MessageStream_listeners, "f")[event] || (tslib_1.__classPrivateFieldGet(this, _MessageStream_listeners, "f")[event] = []);
        listeners.push({ listener, once: true });
        return this;
      }
      /**
       * This is similar to `.once()`, but returns a Promise that resolves the next time
       * the event is triggered, instead of calling a listener callback.
       * @returns a Promise that resolves the next time given event is triggered,
       * or rejects if an error is emitted.  (If you request the 'error' event,
       * returns a promise that resolves with the error).
       *
       * Example:
       *
       *   const message = await stream.emitted('message') // rejects if the stream errors
       */
      emitted(event) {
        return new Promise((resolve, reject) => {
          tslib_1.__classPrivateFieldSet(this, _MessageStream_catchingPromiseCreated, true, "f");
          if (event !== "error")
            this.once("error", reject);
          this.once(event, resolve);
        });
      }
      async done() {
        tslib_1.__classPrivateFieldSet(this, _MessageStream_catchingPromiseCreated, true, "f");
        await tslib_1.__classPrivateFieldGet(this, _MessageStream_endPromise, "f");
      }
      get currentMessage() {
        return tslib_1.__classPrivateFieldGet(this, _MessageStream_currentMessageSnapshot, "f");
      }
      /**
       * @returns a promise that resolves with the the final assistant Message response,
       * or rejects if an error occurred or the stream ended prematurely without producing a Message.
       * If structured outputs were used, this will be a ParsedMessage with a `parsed_output` field.
       */
      async finalMessage() {
        await this.done();
        return tslib_1.__classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_getFinalMessage).call(this);
      }
      /**
       * @returns a promise that resolves with the the final assistant Message's text response, concatenated
       * together if there are more than one text blocks.
       * Rejects if an error occurred or the stream ended prematurely without producing a Message.
       */
      async finalText() {
        await this.done();
        return tslib_1.__classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_getFinalText).call(this);
      }
      _emit(event, ...args) {
        if (tslib_1.__classPrivateFieldGet(this, _MessageStream_ended, "f"))
          return;
        if (event === "end") {
          tslib_1.__classPrivateFieldSet(this, _MessageStream_ended, true, "f");
          tslib_1.__classPrivateFieldGet(this, _MessageStream_resolveEndPromise, "f").call(this);
        }
        const listeners = tslib_1.__classPrivateFieldGet(this, _MessageStream_listeners, "f")[event];
        if (listeners) {
          tslib_1.__classPrivateFieldGet(this, _MessageStream_listeners, "f")[event] = listeners.filter((l) => !l.once);
          listeners.forEach(({ listener }) => listener(...args));
        }
        if (event === "abort") {
          const error = args[0];
          if (!tslib_1.__classPrivateFieldGet(this, _MessageStream_catchingPromiseCreated, "f") && !listeners?.length) {
            Promise.reject(error);
          }
          tslib_1.__classPrivateFieldGet(this, _MessageStream_rejectConnectedPromise, "f").call(this, error);
          tslib_1.__classPrivateFieldGet(this, _MessageStream_rejectEndPromise, "f").call(this, error);
          this._emit("end");
          return;
        }
        if (event === "error") {
          const error = args[0];
          if (!tslib_1.__classPrivateFieldGet(this, _MessageStream_catchingPromiseCreated, "f") && !listeners?.length) {
            Promise.reject(error);
          }
          tslib_1.__classPrivateFieldGet(this, _MessageStream_rejectConnectedPromise, "f").call(this, error);
          tslib_1.__classPrivateFieldGet(this, _MessageStream_rejectEndPromise, "f").call(this, error);
          this._emit("end");
        }
      }
      _emitFinal() {
        const finalMessage = this.receivedMessages.at(-1);
        if (finalMessage) {
          this._emit("finalMessage", tslib_1.__classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_getFinalMessage).call(this));
        }
      }
      async _fromReadableStream(readableStream, options) {
        const signal = options?.signal;
        let abortHandler;
        if (signal) {
          if (signal.aborted)
            this.controller.abort();
          abortHandler = this.controller.abort.bind(this.controller);
          signal.addEventListener("abort", abortHandler);
        }
        try {
          tslib_1.__classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_beginRequest).call(this);
          this._connected(null);
          const stream = streaming_1.Stream.fromReadableStream(readableStream, this.controller);
          for await (const event of stream) {
            tslib_1.__classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_addStreamEvent).call(this, event);
          }
          if (stream.controller.signal?.aborted) {
            throw new error_1.APIUserAbortError();
          }
          tslib_1.__classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_endRequest).call(this);
        } finally {
          if (signal && abortHandler) {
            signal.removeEventListener("abort", abortHandler);
          }
        }
      }
      [(_MessageStream_currentMessageSnapshot = /* @__PURE__ */ new WeakMap(), _MessageStream_params = /* @__PURE__ */ new WeakMap(), _MessageStream_connectedPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_resolveConnectedPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_rejectConnectedPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_endPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_resolveEndPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_rejectEndPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_listeners = /* @__PURE__ */ new WeakMap(), _MessageStream_ended = /* @__PURE__ */ new WeakMap(), _MessageStream_errored = /* @__PURE__ */ new WeakMap(), _MessageStream_aborted = /* @__PURE__ */ new WeakMap(), _MessageStream_catchingPromiseCreated = /* @__PURE__ */ new WeakMap(), _MessageStream_response = /* @__PURE__ */ new WeakMap(), _MessageStream_request_id = /* @__PURE__ */ new WeakMap(), _MessageStream_logger = /* @__PURE__ */ new WeakMap(), _MessageStream_handleError = /* @__PURE__ */ new WeakMap(), _MessageStream_instances = /* @__PURE__ */ new WeakSet(), _MessageStream_getFinalMessage = function _MessageStream_getFinalMessage2() {
        if (this.receivedMessages.length === 0) {
          throw new error_1.AnthropicError("stream ended without producing a Message with role=assistant");
        }
        return this.receivedMessages.at(-1);
      }, _MessageStream_getFinalText = function _MessageStream_getFinalText2() {
        if (this.receivedMessages.length === 0) {
          throw new error_1.AnthropicError("stream ended without producing a Message with role=assistant");
        }
        const textBlocks = this.receivedMessages.at(-1).content.filter((block) => block.type === "text").map((block) => block.text);
        if (textBlocks.length === 0) {
          throw new error_1.AnthropicError("stream ended without producing a content block with type=text");
        }
        return textBlocks.join(" ");
      }, _MessageStream_beginRequest = function _MessageStream_beginRequest2() {
        if (this.ended)
          return;
        tslib_1.__classPrivateFieldSet(this, _MessageStream_currentMessageSnapshot, void 0, "f");
      }, _MessageStream_addStreamEvent = function _MessageStream_addStreamEvent2(event) {
        if (this.ended)
          return;
        const messageSnapshot = tslib_1.__classPrivateFieldGet(this, _MessageStream_instances, "m", _MessageStream_accumulateMessage).call(this, event);
        this._emit("streamEvent", event, messageSnapshot);
        switch (event.type) {
          case "content_block_delta": {
            const content = messageSnapshot.content.at(-1);
            switch (event.delta.type) {
              case "text_delta": {
                if (content.type === "text") {
                  this._emit("text", event.delta.text, content.text || "");
                }
                break;
              }
              case "citations_delta": {
                if (content.type === "text") {
                  this._emit("citation", event.delta.citation, content.citations ?? []);
                }
                break;
              }
              case "input_json_delta": {
                if (tracksToolInput(content) && content.input) {
                  this._emit("inputJson", event.delta.partial_json, content.input);
                }
                break;
              }
              case "thinking_delta": {
                if (content.type === "thinking") {
                  this._emit("thinking", event.delta.thinking, content.thinking);
                }
                break;
              }
              case "signature_delta": {
                if (content.type === "thinking") {
                  this._emit("signature", content.signature);
                }
                break;
              }
              default:
                checkNever(event.delta);
            }
            break;
          }
          case "message_stop": {
            this._addMessageParam(messageSnapshot);
            this._addMessage((0, parser_2.maybeParseMessage)(messageSnapshot, tslib_1.__classPrivateFieldGet(this, _MessageStream_params, "f"), { logger: tslib_1.__classPrivateFieldGet(this, _MessageStream_logger, "f") }), true);
            break;
          }
          case "content_block_stop": {
            this._emit("contentBlock", messageSnapshot.content.at(-1));
            break;
          }
          case "message_start": {
            tslib_1.__classPrivateFieldSet(this, _MessageStream_currentMessageSnapshot, messageSnapshot, "f");
            break;
          }
          case "content_block_start":
          case "message_delta":
            break;
        }
      }, _MessageStream_endRequest = function _MessageStream_endRequest2() {
        if (this.ended) {
          throw new error_1.AnthropicError(`stream has ended, this shouldn't happen`);
        }
        const snapshot = tslib_1.__classPrivateFieldGet(this, _MessageStream_currentMessageSnapshot, "f");
        if (!snapshot) {
          throw new error_1.AnthropicError(`request ended without sending any chunks`);
        }
        tslib_1.__classPrivateFieldSet(this, _MessageStream_currentMessageSnapshot, void 0, "f");
        return (0, parser_2.maybeParseMessage)(snapshot, tslib_1.__classPrivateFieldGet(this, _MessageStream_params, "f"), { logger: tslib_1.__classPrivateFieldGet(this, _MessageStream_logger, "f") });
      }, _MessageStream_accumulateMessage = function _MessageStream_accumulateMessage2(event) {
        let snapshot = tslib_1.__classPrivateFieldGet(this, _MessageStream_currentMessageSnapshot, "f");
        if (event.type === "message_start") {
          if (snapshot) {
            throw new error_1.AnthropicError(`Unexpected event order, got ${event.type} before receiving "message_stop"`);
          }
          return event.message;
        }
        if (!snapshot) {
          throw new error_1.AnthropicError(`Unexpected event order, got ${event.type} before "message_start"`);
        }
        switch (event.type) {
          case "message_stop":
            return snapshot;
          case "message_delta":
            snapshot.stop_reason = event.delta.stop_reason;
            snapshot.stop_sequence = event.delta.stop_sequence;
            if (event.delta.stop_details != null) {
              snapshot.stop_details = event.delta.stop_details;
            }
            snapshot.usage.output_tokens = event.usage.output_tokens;
            if (event.usage.input_tokens != null) {
              snapshot.usage.input_tokens = event.usage.input_tokens;
            }
            if (event.usage.cache_creation_input_tokens != null) {
              snapshot.usage.cache_creation_input_tokens = event.usage.cache_creation_input_tokens;
            }
            if (event.usage.cache_read_input_tokens != null) {
              snapshot.usage.cache_read_input_tokens = event.usage.cache_read_input_tokens;
            }
            if (event.usage.server_tool_use != null) {
              snapshot.usage.server_tool_use = event.usage.server_tool_use;
            }
            return snapshot;
          case "content_block_start":
            snapshot.content.push({ ...event.content_block });
            return snapshot;
          case "content_block_delta": {
            const snapshotContent = snapshot.content.at(event.index);
            switch (event.delta.type) {
              case "text_delta": {
                if (snapshotContent?.type === "text") {
                  snapshot.content[event.index] = {
                    ...snapshotContent,
                    text: (snapshotContent.text || "") + event.delta.text
                  };
                }
                break;
              }
              case "citations_delta": {
                if (snapshotContent?.type === "text") {
                  snapshot.content[event.index] = {
                    ...snapshotContent,
                    citations: [...snapshotContent.citations ?? [], event.delta.citation]
                  };
                }
                break;
              }
              case "input_json_delta": {
                if (snapshotContent && tracksToolInput(snapshotContent)) {
                  let jsonBuf = snapshotContent[JSON_BUF_PROPERTY] || "";
                  jsonBuf += event.delta.partial_json;
                  const newContent = { ...snapshotContent };
                  Object.defineProperty(newContent, JSON_BUF_PROPERTY, {
                    value: jsonBuf,
                    enumerable: false,
                    writable: true
                  });
                  if (jsonBuf) {
                    newContent.input = (0, parser_1.partialParse)(jsonBuf);
                  }
                  snapshot.content[event.index] = newContent;
                }
                break;
              }
              case "thinking_delta": {
                if (snapshotContent?.type === "thinking") {
                  snapshot.content[event.index] = {
                    ...snapshotContent,
                    thinking: snapshotContent.thinking + event.delta.thinking
                  };
                }
                break;
              }
              case "signature_delta": {
                if (snapshotContent?.type === "thinking") {
                  snapshot.content[event.index] = {
                    ...snapshotContent,
                    signature: event.delta.signature
                  };
                }
                break;
              }
              default:
                checkNever(event.delta);
            }
            return snapshot;
          }
          case "content_block_stop":
            return snapshot;
        }
      }, Symbol.asyncIterator)]() {
        const pushQueue = [];
        const readQueue = [];
        let done = false;
        this.on("streamEvent", (event) => {
          const reader = readQueue.shift();
          if (reader) {
            reader.resolve(event);
          } else {
            pushQueue.push(event);
          }
        });
        this.on("end", () => {
          done = true;
          for (const reader of readQueue) {
            reader.resolve(void 0);
          }
          readQueue.length = 0;
        });
        this.on("abort", (err) => {
          done = true;
          for (const reader of readQueue) {
            reader.reject(err);
          }
          readQueue.length = 0;
        });
        this.on("error", (err) => {
          done = true;
          for (const reader of readQueue) {
            reader.reject(err);
          }
          readQueue.length = 0;
        });
        return {
          next: async () => {
            if (!pushQueue.length) {
              if (done) {
                return { value: void 0, done: true };
              }
              return new Promise((resolve, reject) => readQueue.push({ resolve, reject })).then((chunk2) => chunk2 ? { value: chunk2, done: false } : { value: void 0, done: true });
            }
            const chunk = pushQueue.shift();
            return { value: chunk, done: false };
          },
          return: async () => {
            this.abort();
            return { value: void 0, done: true };
          }
        };
      }
      toReadableStream() {
        const stream = new streaming_1.Stream(this[Symbol.asyncIterator].bind(this), this.controller);
        return stream.toReadableStream();
      }
    };
    exports2.MessageStream = MessageStream;
    function checkNever(x) {
    }
  }
});

// node_modules/@anthropic-ai/sdk/resources/messages/batches.js
var require_batches2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/messages/batches.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Batches = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var jsonl_1 = require_jsonl();
    var error_1 = require_error2();
    var path_1 = require_path();
    var Batches = class extends resource_1.APIResource {
      /**
       * Send a batch of Message creation requests.
       *
       * The Message Batches API can be used to process multiple Messages API requests at
       * once. Once a Message Batch is created, it begins processing immediately. Batches
       * can take up to 24 hours to complete.
       *
       * Learn more about the Message Batches API in our
       * [user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
       *
       * @example
       * ```ts
       * const messageBatch = await client.messages.batches.create({
       *   requests: [
       *     {
       *       custom_id: 'my-custom-id-1',
       *       params: {
       *         max_tokens: 1024,
       *         messages: [
       *           { content: 'Hello, world', role: 'user' },
       *         ],
       *         model: 'claude-opus-4-6',
       *       },
       *     },
       *   ],
       * });
       * ```
       */
      create(body, options) {
        return this._client.post("/v1/messages/batches", { body, ...options });
      }
      /**
       * This endpoint is idempotent and can be used to poll for Message Batch
       * completion. To access the results of a Message Batch, make a request to the
       * `results_url` field in the response.
       *
       * Learn more about the Message Batches API in our
       * [user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
       *
       * @example
       * ```ts
       * const messageBatch = await client.messages.batches.retrieve(
       *   'message_batch_id',
       * );
       * ```
       */
      retrieve(messageBatchID, options) {
        return this._client.get((0, path_1.path)`/v1/messages/batches/${messageBatchID}`, options);
      }
      /**
       * List all Message Batches within a Workspace. Most recently created batches are
       * returned first.
       *
       * Learn more about the Message Batches API in our
       * [user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
       *
       * @example
       * ```ts
       * // Automatically fetches more pages as needed.
       * for await (const messageBatch of client.messages.batches.list()) {
       *   // ...
       * }
       * ```
       */
      list(query = {}, options) {
        return this._client.getAPIList("/v1/messages/batches", pagination_1.Page, { query, ...options });
      }
      /**
       * Delete a Message Batch.
       *
       * Message Batches can only be deleted once they've finished processing. If you'd
       * like to delete an in-progress batch, you must first cancel it.
       *
       * Learn more about the Message Batches API in our
       * [user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
       *
       * @example
       * ```ts
       * const deletedMessageBatch =
       *   await client.messages.batches.delete('message_batch_id');
       * ```
       */
      delete(messageBatchID, options) {
        return this._client.delete((0, path_1.path)`/v1/messages/batches/${messageBatchID}`, options);
      }
      /**
       * Batches may be canceled any time before processing ends. Once cancellation is
       * initiated, the batch enters a `canceling` state, at which time the system may
       * complete any in-progress, non-interruptible requests before finalizing
       * cancellation.
       *
       * The number of canceled requests is specified in `request_counts`. To determine
       * which requests were canceled, check the individual results within the batch.
       * Note that cancellation may not result in any canceled requests if they were
       * non-interruptible.
       *
       * Learn more about the Message Batches API in our
       * [user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
       *
       * @example
       * ```ts
       * const messageBatch = await client.messages.batches.cancel(
       *   'message_batch_id',
       * );
       * ```
       */
      cancel(messageBatchID, options) {
        return this._client.post((0, path_1.path)`/v1/messages/batches/${messageBatchID}/cancel`, options);
      }
      /**
       * Streams the results of a Message Batch as a `.jsonl` file.
       *
       * Each line in the file is a JSON object containing the result of a single request
       * in the Message Batch. Results are not guaranteed to be in the same order as
       * requests. Use the `custom_id` field to match results to requests.
       *
       * Learn more about the Message Batches API in our
       * [user guide](https://docs.claude.com/en/docs/build-with-claude/batch-processing)
       *
       * @example
       * ```ts
       * const messageBatchIndividualResponse =
       *   await client.messages.batches.results('message_batch_id');
       * ```
       */
      async results(messageBatchID, options) {
        const batch = await this.retrieve(messageBatchID);
        if (!batch.results_url) {
          throw new error_1.AnthropicError(`No batch \`results_url\`; Has it finished processing? ${batch.processing_status} - ${batch.id}`);
        }
        return this._client.get(batch.results_url, {
          ...options,
          headers: (0, headers_1.buildHeaders)([{ Accept: "application/binary" }, options?.headers]),
          stream: true,
          __binaryResponse: true
        })._thenUnwrap((_, props) => jsonl_1.JSONLDecoder.fromResponse(props.response, props.controller));
      }
    };
    exports2.Batches = Batches;
  }
});

// node_modules/@anthropic-ai/sdk/resources/messages/messages.js
var require_messages2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/messages/messages.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Messages = void 0;
    var tslib_1 = require_tslib();
    var resource_1 = require_resource();
    var headers_1 = require_headers();
    var stainless_helper_header_1 = require_stainless_helper_header();
    var MessageStream_1 = require_MessageStream();
    var parser_1 = require_parser2();
    var BatchesAPI = tslib_1.__importStar(require_batches2());
    var batches_1 = require_batches2();
    var constants_1 = require_constants();
    var Messages = class extends resource_1.APIResource {
      constructor() {
        super(...arguments);
        this.batches = new BatchesAPI.Batches(this._client);
      }
      create(body, options) {
        if (body.model in DEPRECATED_MODELS) {
          console.warn(`The model '${body.model}' is deprecated and will reach end-of-life on ${DEPRECATED_MODELS[body.model]}
Please migrate to a newer model. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.`);
        }
        if (MODELS_TO_WARN_WITH_THINKING_ENABLED.includes(body.model) && body.thinking && body.thinking.type === "enabled") {
          console.warn(`Using Claude with ${body.model} and 'thinking.type=enabled' is deprecated. Use 'thinking.type=adaptive' instead which results in better model performance in our testing: https://platform.claude.com/docs/en/build-with-claude/adaptive-thinking`);
        }
        let timeout = this._client._options.timeout;
        if (!body.stream && timeout == null) {
          const maxNonstreamingTokens = constants_1.MODEL_NONSTREAMING_TOKENS[body.model] ?? void 0;
          timeout = this._client.calculateNonstreamingTimeout(body.max_tokens, maxNonstreamingTokens);
        }
        const helperHeader = (0, stainless_helper_header_1.stainlessHelperHeader)(body.tools, body.messages);
        return this._client.post("/v1/messages", {
          body,
          timeout: timeout ?? 6e5,
          ...options,
          headers: (0, headers_1.buildHeaders)([helperHeader, options?.headers]),
          stream: body.stream ?? false
        });
      }
      /**
       * Send a structured list of input messages with text and/or image content, along with an expected `output_config.format` and
       * the response will be automatically parsed and available in the `parsed_output` property of the message.
       *
       * @example
       * ```ts
       * const message = await client.messages.parse({
       *   model: 'claude-sonnet-4-5-20250929',
       *   max_tokens: 1024,
       *   messages: [{ role: 'user', content: 'What is 2+2?' }],
       *   output_config: {
       *     format: zodOutputFormat(z.object({ answer: z.number() })),
       *   },
       * });
       *
       * console.log(message.parsed_output?.answer); // 4
       * ```
       */
      parse(params, options) {
        return this.create(params, options).then((message) => (0, parser_1.parseMessage)(message, params, { logger: this._client.logger ?? console }));
      }
      /**
       * Create a Message stream.
       *
       * If `output_config.format` is provided with a parseable format (like `zodOutputFormat()`),
       * the final message will include a `parsed_output` property with the parsed content.
       *
       * @example
       * ```ts
       * const stream = client.messages.stream({
       *   model: 'claude-sonnet-4-5-20250929',
       *   max_tokens: 1024,
       *   messages: [{ role: 'user', content: 'What is 2+2?' }],
       *   output_config: {
       *     format: zodOutputFormat(z.object({ answer: z.number() })),
       *   },
       * });
       *
       * const message = await stream.finalMessage();
       * console.log(message.parsed_output?.answer); // 4
       * ```
       */
      stream(body, options) {
        return MessageStream_1.MessageStream.createMessage(this, body, options, { logger: this._client.logger ?? console });
      }
      /**
       * Count the number of tokens in a Message.
       *
       * The Token Count API can be used to count the number of tokens in a Message,
       * including tools, images, and documents, without creating it.
       *
       * Learn more about token counting in our
       * [user guide](https://docs.claude.com/en/docs/build-with-claude/token-counting)
       *
       * @example
       * ```ts
       * const messageTokensCount =
       *   await client.messages.countTokens({
       *     messages: [{ content: 'Hello, world', role: 'user' }],
       *     model: 'claude-opus-4-6',
       *   });
       * ```
       */
      countTokens(body, options) {
        return this._client.post("/v1/messages/count_tokens", { body, ...options });
      }
    };
    exports2.Messages = Messages;
    var DEPRECATED_MODELS = {
      "claude-1.3": "November 6th, 2024",
      "claude-1.3-100k": "November 6th, 2024",
      "claude-instant-1.1": "November 6th, 2024",
      "claude-instant-1.1-100k": "November 6th, 2024",
      "claude-instant-1.2": "November 6th, 2024",
      "claude-3-sonnet-20240229": "July 21st, 2025",
      "claude-3-opus-20240229": "January 5th, 2026",
      "claude-2.1": "July 21st, 2025",
      "claude-2.0": "July 21st, 2025",
      "claude-3-7-sonnet-latest": "February 19th, 2026",
      "claude-3-7-sonnet-20250219": "February 19th, 2026",
      "claude-3-5-haiku-latest": "February 19th, 2026",
      "claude-3-5-haiku-20241022": "February 19th, 2026",
      "claude-opus-4-0": "June 15th, 2026",
      "claude-opus-4-20250514": "June 15th, 2026",
      "claude-sonnet-4-0": "June 15th, 2026",
      "claude-sonnet-4-20250514": "June 15th, 2026"
    };
    var MODELS_TO_WARN_WITH_THINKING_ENABLED = ["claude-mythos-preview", "claude-opus-4-6"];
    Messages.Batches = batches_1.Batches;
  }
});

// node_modules/@anthropic-ai/sdk/resources/models.js
var require_models2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/models.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Models = void 0;
    var resource_1 = require_resource();
    var pagination_1 = require_pagination();
    var headers_1 = require_headers();
    var path_1 = require_path();
    var Models = class extends resource_1.APIResource {
      /**
       * Get a specific model.
       *
       * The Models API response can be used to determine information about a specific
       * model or resolve a model alias to a model ID.
       */
      retrieve(modelID, params = {}, options) {
        const { betas } = params ?? {};
        return this._client.get((0, path_1.path)`/v1/models/${modelID}`, {
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
            options?.headers
          ])
        });
      }
      /**
       * List available models.
       *
       * The Models API response can be used to determine which models are available for
       * use in the API. More recently released models are listed first.
       */
      list(params = {}, options) {
        const { betas, ...query } = params ?? {};
        return this._client.getAPIList("/v1/models", pagination_1.Page, {
          query,
          ...options,
          headers: (0, headers_1.buildHeaders)([
            { ...betas?.toString() != null ? { "anthropic-beta": betas?.toString() } : void 0 },
            options?.headers
          ])
        });
      }
    };
    exports2.Models = Models;
  }
});

// node_modules/@anthropic-ai/sdk/resources/index.js
var require_resources2 = __commonJS({
  "node_modules/@anthropic-ai/sdk/resources/index.js"(exports2) {
    "use strict";
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Models = exports2.Messages = exports2.Completions = exports2.Beta = void 0;
    var tslib_1 = require_tslib();
    tslib_1.__exportStar(require_shared(), exports2);
    var beta_1 = require_beta();
    Object.defineProperty(exports2, "Beta", { enumerable: true, get: function() {
      return beta_1.Beta;
    } });
    var completions_1 = require_completions();
    Object.defineProperty(exports2, "Completions", { enumerable: true, get: function() {
      return completions_1.Completions;
    } });
    var messages_1 = require_messages2();
    Object.defineProperty(exports2, "Messages", { enumerable: true, get: function() {
      return messages_1.Messages;
    } });
    var models_1 = require_models2();
    Object.defineProperty(exports2, "Models", { enumerable: true, get: function() {
      return models_1.Models;
    } });
  }
});

// node_modules/@anthropic-ai/sdk/client.js
var require_client = __commonJS({
  "node_modules/@anthropic-ai/sdk/client.js"(exports2) {
    "use strict";
    var _BaseAnthropic_instances;
    var _a;
    var _BaseAnthropic_encoder;
    var _BaseAnthropic_baseURLOverridden;
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.Anthropic = exports2.BaseAnthropic = exports2.AI_PROMPT = exports2.HUMAN_PROMPT = void 0;
    var tslib_1 = require_tslib();
    var uuid_1 = require_uuid();
    var values_1 = require_values();
    var sleep_1 = require_sleep();
    var errors_1 = require_errors();
    var detect_platform_1 = require_detect_platform();
    var Shims = tslib_1.__importStar(require_shims());
    var Opts = tslib_1.__importStar(require_request_options());
    var query_1 = require_query();
    var version_1 = require_version();
    var Errors = tslib_1.__importStar(require_error());
    var types_1 = require_types();
    var token_cache_1 = require_token_cache();
    var credential_chain_1 = require_credential_chain();
    var Pagination = tslib_1.__importStar(require_pagination());
    var Uploads = tslib_1.__importStar(require_uploads2());
    var API = tslib_1.__importStar(require_resources2());
    var api_promise_1 = require_api_promise();
    var completions_1 = require_completions();
    var models_1 = require_models2();
    var beta_1 = require_beta();
    var messages_1 = require_messages2();
    var detect_platform_2 = require_detect_platform();
    var headers_1 = require_headers();
    var env_1 = require_env();
    var log_1 = require_log();
    var values_2 = require_values();
    exports2.HUMAN_PROMPT = "\\n\\nHuman:";
    exports2.AI_PROMPT = "\\n\\nAssistant:";
    var BaseAnthropic = class {
      /**
       * The active credential provider. Default credential resolution runs once
       * at construction time. If it fails, the error is surfaced on every
       * request and the client must be reconstructed — there is no retry path.
       *
       * Clones returned by {@link withOptions} share the parent's auth state
       * (provider, token cache, pending resolution, and any resolution error)
       * unless the caller passes an explicit `apiKey`, `authToken`,
       * `credentials`, `config`, or `profile` override.
       */
      get credentials() {
        return this._authState.provider;
      }
      /**
       * API Client for interfacing with the Anthropic API.
       *
       * @param {string | null | undefined} [opts.apiKey=process.env['ANTHROPIC_API_KEY'] ?? null]
       * @param {string | null | undefined} [opts.authToken=process.env['ANTHROPIC_AUTH_TOKEN'] ?? null]
       * @param {string | null | undefined} [opts.webhookKey=process.env['ANTHROPIC_WEBHOOK_SIGNING_KEY'] ?? null]
       * @param {string} [opts.baseURL=process.env['ANTHROPIC_BASE_URL'] ?? https://api.anthropic.com] - Override the default base URL for the API.
       * @param {number} [opts.timeout=10 minutes] - The maximum amount of time (in milliseconds) the client will wait for a response before timing out.
       * @param {MergedRequestInit} [opts.fetchOptions] - Additional `RequestInit` options to be passed to `fetch` calls.
       * @param {Fetch} [opts.fetch] - Specify a custom `fetch` function implementation.
       * @param {number} [opts.maxRetries=2] - The maximum number of times the client will retry a request.
       * @param {HeadersLike} opts.defaultHeaders - Default headers to include with every request to the API.
       * @param {Record<string, string | undefined>} opts.defaultQuery - Default query parameters to include with every request to the API.
       * @param {boolean} [opts.dangerouslyAllowBrowser=false] - By default, client-side use of this library is not allowed, as it risks exposing your secret API credentials to attackers.
       */
      constructor({ baseURL = (0, env_1.readEnv)("ANTHROPIC_BASE_URL"), apiKey, authToken, webhookKey = (0, env_1.readEnv)("ANTHROPIC_WEBHOOK_SIGNING_KEY") ?? null, ...opts } = {}) {
        _BaseAnthropic_instances.add(this);
        this._requestAuthFlags = /* @__PURE__ */ new WeakMap();
        _BaseAnthropic_encoder.set(this, void 0);
        if (apiKey === void 0) {
          apiKey = opts.profile != null ? null : (0, env_1.readEnv)("ANTHROPIC_API_KEY") ?? null;
        }
        if (authToken === void 0) {
          authToken = opts.profile != null ? null : (0, env_1.readEnv)("ANTHROPIC_AUTH_TOKEN") ?? null;
        }
        if (opts.profile != null && (opts.credentials != null || opts.config != null)) {
          throw new TypeError("Pass at most one of `profile`, `credentials`, or `config`.");
        }
        const options = {
          apiKey,
          authToken,
          webhookKey,
          ...opts,
          baseURL: baseURL || `https://api.anthropic.com`
        };
        if (!options.dangerouslyAllowBrowser && (0, detect_platform_2.isRunningInBrowser)()) {
          throw new Errors.AnthropicError("It looks like you're running in a browser-like environment.\n\nThis is disabled by default, as it risks exposing your secret API credentials to attackers.\nIf you understand the risks and have appropriate mitigations in place,\nyou can set the `dangerouslyAllowBrowser` option to `true`, e.g.,\n\nnew Anthropic({ apiKey, dangerouslyAllowBrowser: true });\n");
        }
        this.baseURL = options.baseURL;
        this._baseURLIsExplicit = opts.__baseURLIsExplicit ?? !!baseURL;
        this.timeout = options.timeout ?? _a.DEFAULT_TIMEOUT;
        this.logger = options.logger ?? console;
        const defaultLogLevel = "warn";
        this.logLevel = defaultLogLevel;
        this.logLevel = (0, log_1.parseLogLevel)(options.logLevel, "ClientOptions.logLevel", this) ?? (0, log_1.parseLogLevel)((0, env_1.readEnv)("ANTHROPIC_LOG"), "process.env['ANTHROPIC_LOG']", this) ?? defaultLogLevel;
        this.fetchOptions = options.fetchOptions;
        this.maxRetries = options.maxRetries ?? 2;
        this.fetch = options.fetch ?? Shims.getDefaultFetch();
        tslib_1.__classPrivateFieldSet(this, _BaseAnthropic_encoder, Opts.FallbackEncoder, "f");
        const customHeadersEnv = (0, env_1.readEnv)("ANTHROPIC_CUSTOM_HEADERS");
        if (customHeadersEnv) {
          const parsed = {};
          for (const line of customHeadersEnv.split("\n")) {
            const colon = line.indexOf(":");
            if (colon >= 0) {
              parsed[line.substring(0, colon).trim()] = line.substring(colon + 1).trim();
            }
          }
          options.defaultHeaders = { ...parsed, ...options.defaultHeaders };
        }
        const inherited = opts.__auth;
        delete options.__auth;
        delete options.__baseURLIsExplicit;
        this._options = options;
        this.apiKey = typeof apiKey === "string" ? apiKey : null;
        this.authToken = authToken;
        this.webhookKey = webhookKey;
        if (inherited) {
          this._authState = inherited;
          if (!this._baseURLIsExplicit && inherited.baseURL) {
            this.baseURL = inherited.baseURL;
          }
        } else {
          this._authState = { provider: null, tokenCache: null, resolution: null, error: null, extraHeaders: {} };
          if (this.apiKey == null && this.authToken == null) {
            const credentials = options.credentials ?? null;
            if (credentials) {
              this._authState.provider = credentials;
              this._authState.tokenCache = this._makeTokenCache(credentials);
            } else if (options.config != null) {
              const result = (0, credential_chain_1.resolveCredentialsFromConfig)(options.config, this._credentialResolverOptions());
              this._authState.provider = result.provider;
              this._authState.tokenCache = this._makeTokenCache(result.provider);
              this._authState.extraHeaders = result.extraHeaders;
              this._applyCredentialBaseURL(result.baseURL);
            } else if (options.profile != null) {
              this._authState.resolution = this._resolveDefaultCredentials(options.profile);
            } else {
              this._authState.resolution = this._resolveDefaultCredentials();
            }
          }
        }
      }
      /**
       * Stores a profile/config-supplied base URL on the shared auth state and, if
       * the caller did not pin `baseURL` via constructor option or env, adopts it
       * as this client's outbound API host. Precedence: ctor opt > env > profile >
       * hardcoded default.
       */
      _applyCredentialBaseURL(baseURL) {
        if (!baseURL)
          return;
        const normalized = baseURL.replace(/\/+$/, "");
        this._authState.baseURL = normalized;
        if (!this._baseURLIsExplicit) {
          this.baseURL = normalized;
        }
      }
      /**
       * Options bag passed into the credential chain. `baseURL` here is only the
       * fallback host for the token-exchange POST when the config itself omits
       * `base_url`; the chain returns the config's own `base_url` (if any) on
       * {@link CredentialResult.baseURL}, which {@link _applyCredentialBaseURL}
       * then adopts for outbound API requests. The two are deliberately decoupled
       * so this fallback never round-trips into precedence.
       */
      _credentialResolverOptions() {
        return {
          baseURL: this.baseURL,
          fetch: this.fetch,
          userAgent: this.getUserAgent(),
          onCacheWriteError: (err) => {
            (0, log_1.loggerFor)(this).debug("credential cache write failed (best-effort)", err);
          },
          onSafetyWarning: (msg) => {
            (0, log_1.loggerFor)(this).warn(msg);
          }
        };
      }
      _makeTokenCache(provider) {
        return new token_cache_1.TokenCache(provider, (err) => {
          (0, log_1.loggerFor)(this).debug("advisory token refresh failed; serving cached token", err);
        });
      }
      /**
       * Create a new client instance re-using the same options given to the current client with optional overriding.
       */
      withOptions(options) {
        const overridesStructuredAuth = "credentials" in options || "config" in options || "profile" in options;
        const overridesAuth = "apiKey" in options || "authToken" in options || overridesStructuredAuth;
        const internal = {
          ...this._options,
          // Only forward baseURL when the caller (or env) explicitly chose it.
          // For a non-explicit parent, this.baseURL may have been mutated to the
          // profile-resolved host; pinning that as the clone's options.baseURL
          // would make _options on the clone misreport caller intent and would
          // leave the clone stuck on the parent's host across an auth override.
          // The clone instead receives the construction-time value via
          // ...this._options above and re-adopts the profile host through the
          // shared _authState.baseURL + __baseURLIsExplicit=false path.
          ...this._baseURLIsExplicit ? { baseURL: this.baseURL } : {},
          maxRetries: this.maxRetries,
          timeout: this.timeout,
          logger: this.logger,
          logLevel: this.logLevel,
          fetch: this.fetch,
          fetchOptions: this.fetchOptions,
          apiKey: this.apiKey,
          authToken: this.authToken,
          webhookKey: this.webhookKey,
          // credentials: this.credentials is a no-op when __auth is shared (the
          // ctor takes the inherited path and ignores options.credentials); when
          // overridesAuth is true via apiKey/authToken only, it lets the clone
          // build a fresh TokenCache around the parent's provider.
          credentials: this.credentials,
          // When the caller passes a structured-credential override, drop inherited
          // structured-credential options so only `...options` supplies them —
          // otherwise an inherited `credentials`/`config`/`profile` would trip the
          // mutual-exclusion check or precedence over the override.
          ...overridesStructuredAuth ? { credentials: void 0, config: void 0, profile: void 0 } : {},
          ...options,
          // Always set __auth so any stale value from ...this._options is
          // overwritten. undefined means "build fresh auth from these options".
          __auth: overridesAuth ? void 0 : this._authState,
          __baseURLIsExplicit: "baseURL" in options ? true : this._baseURLIsExplicit
        };
        return new this.constructor(internal);
      }
      /**
       * Lazily resolves credentials from config files or environment variables.
       * Called once from the constructor when no explicit auth is provided, or
       * when an explicit `profile` was passed (in which case a missing/unresolved
       * profile is surfaced as an error instead of falling through to "no auth").
       * The returned promise is stored and awaited on the first request.
       */
      async _resolveDefaultCredentials(profile) {
        try {
          const result = await (0, credential_chain_1.defaultCredentials)(this._credentialResolverOptions(), profile);
          if (result) {
            this._authState.provider = result.provider;
            this._authState.tokenCache = this._makeTokenCache(result.provider);
            this._authState.extraHeaders = result.extraHeaders;
            this._applyCredentialBaseURL(result.baseURL);
          } else if (profile != null) {
            throw new Errors.AnthropicError(`Profile "${profile}" could not be resolved (no <config_dir>/configs/${profile}.json found).`);
          }
        } catch (err) {
          this._authState.error = err;
        } finally {
          this._authState.resolution = null;
        }
      }
      defaultQuery() {
        return this._options.defaultQuery;
      }
      validateHeaders({ values, nulls }) {
        if (values.get("x-api-key") || values.get("authorization")) {
          return;
        }
        if (this._authState.error) {
          throw this._authState.error;
        }
        if (this._authState.tokenCache || this._authState.resolution) {
          return;
        }
        if (this.apiKey && values.get("x-api-key")) {
          return;
        }
        if (nulls.has("x-api-key")) {
          return;
        }
        if (this.authToken && values.get("authorization")) {
          return;
        }
        if (nulls.has("authorization")) {
          return;
        }
        throw new Error('Could not resolve authentication method. Expected one of apiKey, authToken, credentials, config, or profile to be set. Or for one of the "X-Api-Key" or "Authorization" headers to be explicitly omitted');
      }
      _authFlags(opts) {
        let flags = this._requestAuthFlags.get(opts);
        if (!flags) {
          flags = { usedTokenCache: false, didRefreshFor401: false };
          this._requestAuthFlags.set(opts, flags);
        }
        return flags;
      }
      async authHeaders(opts) {
        if (this._authState.resolution) {
          await this._authState.resolution;
        }
        if (this._authState.error) {
          return void 0;
        }
        if (this._authState.tokenCache && this.apiKey == null) {
          const token = await this._authState.tokenCache.getToken();
          this._authFlags(opts).usedTokenCache = true;
          return (0, headers_1.buildHeaders)([{ Authorization: `Bearer ${token}` }]);
        }
        return (0, headers_1.buildHeaders)([await this.apiKeyAuth(opts), await this.bearerAuth(opts)]);
      }
      async apiKeyAuth(opts) {
        if (this.apiKey == null) {
          return void 0;
        }
        return (0, headers_1.buildHeaders)([{ "X-Api-Key": this.apiKey }]);
      }
      async bearerAuth(opts) {
        if (this.authToken == null) {
          return void 0;
        }
        return (0, headers_1.buildHeaders)([{ Authorization: `Bearer ${this.authToken}` }]);
      }
      stringifyQuery(query) {
        return (0, query_1.stringifyQuery)(query);
      }
      getUserAgent() {
        return `${this.constructor.name}/JS ${version_1.VERSION}`;
      }
      defaultIdempotencyKey() {
        return `stainless-node-retry-${(0, uuid_1.uuid4)()}`;
      }
      makeStatusError(status, error, message, headers) {
        return Errors.APIError.generate(status, error, message, headers);
      }
      buildURL(path, query, defaultBaseURL) {
        const baseURL = !tslib_1.__classPrivateFieldGet(this, _BaseAnthropic_instances, "m", _BaseAnthropic_baseURLOverridden).call(this) && defaultBaseURL || this.baseURL;
        const url = (0, values_1.isAbsoluteURL)(path) ? new URL(path) : new URL(baseURL + (baseURL.endsWith("/") && path.startsWith("/") ? path.slice(1) : path));
        const defaultQuery = this.defaultQuery();
        const pathQuery = Object.fromEntries(url.searchParams);
        if (!(0, values_2.isEmptyObj)(defaultQuery) || !(0, values_2.isEmptyObj)(pathQuery)) {
          query = { ...pathQuery, ...defaultQuery, ...query };
        }
        if (typeof query === "object" && query && !Array.isArray(query)) {
          url.search = this.stringifyQuery(query);
        }
        return url.toString();
      }
      _calculateNonstreamingTimeout(maxTokens) {
        const defaultTimeout = 10 * 60;
        const expectedTimeout = 60 * 60 * maxTokens / 128e3;
        if (expectedTimeout > defaultTimeout) {
          throw new Errors.AnthropicError("Streaming is required for operations that may take longer than 10 minutes. See https://github.com/anthropics/anthropic-sdk-typescript#streaming-responses for more details");
        }
        return defaultTimeout * 1e3;
      }
      /**
       * Used as a callback for mutating the given `FinalRequestOptions` object.
       */
      async prepareOptions(options) {
      }
      /**
       * Used as a callback for mutating the given `RequestInit` object.
       *
       * This is useful for cases where you want to add certain headers based off of
       * the request properties, e.g. `method` or `url`.
       */
      async prepareRequest(request, { url, options }) {
        if (this._authState.tokenCache && this.apiKey == null) {
          const headers = request.headers instanceof Headers ? request.headers : new Headers(request.headers);
          for (const [k, v] of Object.entries(this._authState.extraHeaders)) {
            if (!headers.has(k))
              headers.set(k, v);
          }
          const existing = headers.get("anthropic-beta")?.split(",").map((s) => s.trim());
          if (!existing?.includes(types_1.OAUTH_API_BETA_HEADER)) {
            headers.append("anthropic-beta", types_1.OAUTH_API_BETA_HEADER);
          }
          request.headers = headers;
        }
      }
      get(path, opts) {
        return this.methodRequest("get", path, opts);
      }
      post(path, opts) {
        return this.methodRequest("post", path, opts);
      }
      patch(path, opts) {
        return this.methodRequest("patch", path, opts);
      }
      put(path, opts) {
        return this.methodRequest("put", path, opts);
      }
      delete(path, opts) {
        return this.methodRequest("delete", path, opts);
      }
      methodRequest(method, path, opts) {
        return this.request(Promise.resolve(opts).then((opts2) => {
          return { method, path, ...opts2 };
        }));
      }
      request(options, remainingRetries = null) {
        return new api_promise_1.APIPromise(this, this.makeRequest(options, remainingRetries, void 0));
      }
      async makeRequest(optionsInput, retriesRemaining, retryOfRequestLogID) {
        const options = await optionsInput;
        const maxRetries = options.maxRetries ?? this.maxRetries;
        if (retriesRemaining == null) {
          retriesRemaining = maxRetries;
          this._requestAuthFlags.delete(options);
        }
        await this.prepareOptions(options);
        const { req, url, timeout } = await this.buildRequest(options, {
          retryCount: maxRetries - retriesRemaining
        });
        await this.prepareRequest(req, { url, options });
        const requestLogID = "log_" + (Math.random() * (1 << 24) | 0).toString(16).padStart(6, "0");
        const retryLogStr = retryOfRequestLogID === void 0 ? "" : `, retryOf: ${retryOfRequestLogID}`;
        const startTime = Date.now();
        (0, log_1.loggerFor)(this).debug(`[${requestLogID}] sending request`, (0, log_1.formatRequestDetails)({
          retryOfRequestLogID,
          method: options.method,
          url,
          options,
          headers: req.headers
        }));
        if (options.signal?.aborted) {
          throw new Errors.APIUserAbortError();
        }
        const controller = new AbortController();
        const response = await this.fetchWithTimeout(url, req, timeout, controller).catch(errors_1.castToError);
        const headersTime = Date.now();
        if (response instanceof globalThis.Error) {
          const retryMessage = `retrying, ${retriesRemaining} attempts remaining`;
          if (options.signal?.aborted) {
            throw new Errors.APIUserAbortError();
          }
          const isTimeout = (0, errors_1.isAbortError)(response) || /timed? ?out/i.test(String(response) + ("cause" in response ? String(response.cause) : ""));
          if (retriesRemaining) {
            (0, log_1.loggerFor)(this).info(`[${requestLogID}] connection ${isTimeout ? "timed out" : "failed"} - ${retryMessage}`);
            (0, log_1.loggerFor)(this).debug(`[${requestLogID}] connection ${isTimeout ? "timed out" : "failed"} (${retryMessage})`, (0, log_1.formatRequestDetails)({
              retryOfRequestLogID,
              url,
              durationMs: headersTime - startTime,
              message: response.message
            }));
            return this.retryRequest(options, retriesRemaining, retryOfRequestLogID ?? requestLogID);
          }
          (0, log_1.loggerFor)(this).info(`[${requestLogID}] connection ${isTimeout ? "timed out" : "failed"} - error; no more retries left`);
          (0, log_1.loggerFor)(this).debug(`[${requestLogID}] connection ${isTimeout ? "timed out" : "failed"} (error; no more retries left)`, (0, log_1.formatRequestDetails)({
            retryOfRequestLogID,
            url,
            durationMs: headersTime - startTime,
            message: response.message
          }));
          if (isTimeout) {
            throw new Errors.APIConnectionTimeoutError();
          }
          throw new Errors.APIConnectionError({ cause: response });
        }
        const specialHeaders = [...response.headers.entries()].filter(([name]) => name === "request-id").map(([name, value]) => ", " + name + ": " + JSON.stringify(value)).join("");
        const responseInfo = `[${requestLogID}${retryLogStr}${specialHeaders}] ${req.method} ${url} ${response.ok ? "succeeded" : "failed"} with status ${response.status} in ${headersTime - startTime}ms`;
        if (!response.ok) {
          const shouldRetry = await this.shouldRetry(response, options);
          if (retriesRemaining && shouldRetry) {
            const retryMessage2 = `retrying, ${retriesRemaining} attempts remaining`;
            await Shims.CancelReadableStream(response.body);
            (0, log_1.loggerFor)(this).info(`${responseInfo} - ${retryMessage2}`);
            (0, log_1.loggerFor)(this).debug(`[${requestLogID}] response error (${retryMessage2})`, (0, log_1.formatRequestDetails)({
              retryOfRequestLogID,
              url: response.url,
              status: response.status,
              headers: response.headers,
              durationMs: headersTime - startTime
            }));
            return this.retryRequest(options, retriesRemaining, retryOfRequestLogID ?? requestLogID, response.headers);
          }
          const retryMessage = shouldRetry ? `error; no more retries left` : `error; not retryable`;
          (0, log_1.loggerFor)(this).info(`${responseInfo} - ${retryMessage}`);
          const errText = await response.text().catch((err2) => (0, errors_1.castToError)(err2).message);
          const errJSON = (0, values_1.safeJSON)(errText);
          const errMessage = errJSON ? void 0 : errText;
          (0, log_1.loggerFor)(this).debug(`[${requestLogID}] response error (${retryMessage})`, (0, log_1.formatRequestDetails)({
            retryOfRequestLogID,
            url: response.url,
            status: response.status,
            headers: response.headers,
            message: errMessage,
            durationMs: Date.now() - startTime
          }));
          const err = this.makeStatusError(response.status, errJSON, errMessage, response.headers);
          throw err;
        }
        (0, log_1.loggerFor)(this).info(responseInfo);
        (0, log_1.loggerFor)(this).debug(`[${requestLogID}] response start`, (0, log_1.formatRequestDetails)({
          retryOfRequestLogID,
          url: response.url,
          status: response.status,
          headers: response.headers,
          durationMs: headersTime - startTime
        }));
        return { response, options, controller, requestLogID, retryOfRequestLogID, startTime };
      }
      getAPIList(path, Page, opts) {
        return this.requestAPIList(Page, opts && "then" in opts ? opts.then((opts2) => ({ method: "get", path, ...opts2 })) : { method: "get", path, ...opts });
      }
      requestAPIList(Page, options) {
        const request = this.makeRequest(options, null, void 0);
        return new Pagination.PagePromise(this, request, Page);
      }
      async fetchWithTimeout(url, init, ms, controller) {
        const { signal, method, ...options } = init || {};
        const abort = this._makeAbort(controller);
        if (signal)
          signal.addEventListener("abort", abort, { once: true });
        const timeout = setTimeout(abort, ms);
        const isReadableBody = globalThis.ReadableStream && options.body instanceof globalThis.ReadableStream || typeof options.body === "object" && options.body !== null && Symbol.asyncIterator in options.body;
        const fetchOptions = {
          signal: controller.signal,
          ...isReadableBody ? { duplex: "half" } : {},
          method: "GET",
          ...options
        };
        if (method) {
          fetchOptions.method = method.toUpperCase();
        }
        try {
          return await this.fetch.call(void 0, url, fetchOptions);
        } finally {
          clearTimeout(timeout);
        }
      }
      async shouldRetry(response, options) {
        const flags = this._authFlags(options);
        if (response.status === 401 && this._authState.tokenCache && flags.usedTokenCache && !flags.didRefreshFor401) {
          flags.didRefreshFor401 = true;
          this._authState.tokenCache.invalidate();
          return true;
        }
        const shouldRetryHeader = response.headers.get("x-should-retry");
        if (shouldRetryHeader === "true")
          return true;
        if (shouldRetryHeader === "false")
          return false;
        if (response.status === 408)
          return true;
        if (response.status === 409)
          return true;
        if (response.status === 429)
          return true;
        if (response.status >= 500)
          return true;
        return false;
      }
      async retryRequest(options, retriesRemaining, requestLogID, responseHeaders) {
        let timeoutMillis;
        const retryAfterMillisHeader = responseHeaders?.get("retry-after-ms");
        if (retryAfterMillisHeader) {
          const timeoutMs = parseFloat(retryAfterMillisHeader);
          if (!Number.isNaN(timeoutMs)) {
            timeoutMillis = timeoutMs;
          }
        }
        const retryAfterHeader = responseHeaders?.get("retry-after");
        if (retryAfterHeader && !timeoutMillis) {
          const timeoutSeconds = parseFloat(retryAfterHeader);
          if (!Number.isNaN(timeoutSeconds)) {
            timeoutMillis = timeoutSeconds * 1e3;
          } else {
            timeoutMillis = Date.parse(retryAfterHeader) - Date.now();
          }
        }
        if (timeoutMillis === void 0) {
          const maxRetries = options.maxRetries ?? this.maxRetries;
          timeoutMillis = this.calculateDefaultRetryTimeoutMillis(retriesRemaining, maxRetries);
        }
        await (0, sleep_1.sleep)(timeoutMillis);
        return this.makeRequest(options, retriesRemaining - 1, requestLogID);
      }
      calculateDefaultRetryTimeoutMillis(retriesRemaining, maxRetries) {
        const initialRetryDelay = 0.5;
        const maxRetryDelay = 8;
        const numRetries = maxRetries - retriesRemaining;
        const sleepSeconds = Math.min(initialRetryDelay * Math.pow(2, numRetries), maxRetryDelay);
        const jitter = 1 - Math.random() * 0.25;
        return sleepSeconds * jitter * 1e3;
      }
      calculateNonstreamingTimeout(maxTokens, maxNonstreamingTokens) {
        const maxTime = 60 * 60 * 1e3;
        const defaultTime = 60 * 10 * 1e3;
        const expectedTime = maxTime * maxTokens / 128e3;
        if (expectedTime > defaultTime || maxNonstreamingTokens != null && maxTokens > maxNonstreamingTokens) {
          throw new Errors.AnthropicError("Streaming is required for operations that may take longer than 10 minutes. See https://github.com/anthropics/anthropic-sdk-typescript#long-requests for more details");
        }
        return defaultTime;
      }
      async buildRequest(inputOptions, { retryCount = 0 } = {}) {
        const options = { ...inputOptions };
        const { method, path, query, defaultBaseURL } = options;
        if (this._authState.resolution) {
          await this._authState.resolution;
        }
        if (!this._baseURLIsExplicit && this._authState.baseURL && this.baseURL !== this._authState.baseURL) {
          this.baseURL = this._authState.baseURL;
        }
        const url = this.buildURL(path, query, defaultBaseURL);
        if ("timeout" in options)
          (0, values_1.validatePositiveInteger)("timeout", options.timeout);
        options.timeout = options.timeout ?? this.timeout;
        const { bodyHeaders, body } = this.buildBody({ options });
        const reqHeaders = await this.buildHeaders({ options: inputOptions, method, bodyHeaders, retryCount });
        const req = {
          method,
          headers: reqHeaders,
          ...options.signal && { signal: options.signal },
          ...globalThis.ReadableStream && body instanceof globalThis.ReadableStream && { duplex: "half" },
          ...body && { body },
          ...this.fetchOptions ?? {},
          ...options.fetchOptions ?? {}
        };
        return { req, url, timeout: options.timeout };
      }
      async buildHeaders({ options, method, bodyHeaders, retryCount }) {
        let idempotencyHeaders = {};
        if (this.idempotencyHeader && method !== "get") {
          if (!options.idempotencyKey)
            options.idempotencyKey = this.defaultIdempotencyKey();
          idempotencyHeaders[this.idempotencyHeader] = options.idempotencyKey;
        }
        const headers = (0, headers_1.buildHeaders)([
          idempotencyHeaders,
          {
            Accept: "application/json",
            "User-Agent": this.getUserAgent(),
            "X-Stainless-Retry-Count": String(retryCount),
            ...options.timeout ? { "X-Stainless-Timeout": String(Math.trunc(options.timeout / 1e3)) } : {},
            ...(0, detect_platform_1.getPlatformHeaders)(),
            ...this._options.dangerouslyAllowBrowser ? { "anthropic-dangerous-direct-browser-access": "true" } : void 0,
            "anthropic-version": "2023-06-01"
          },
          await this.authHeaders(options),
          this._options.defaultHeaders,
          bodyHeaders,
          options.headers
        ]);
        this.validateHeaders(headers);
        return headers.values;
      }
      _makeAbort(controller) {
        return () => controller.abort();
      }
      buildBody({ options: { body, headers: rawHeaders } }) {
        if (!body) {
          return { bodyHeaders: void 0, body: void 0 };
        }
        const headers = (0, headers_1.buildHeaders)([rawHeaders]);
        if (
          // Pass raw type verbatim
          ArrayBuffer.isView(body) || body instanceof ArrayBuffer || body instanceof DataView || typeof body === "string" && // Preserve legacy string encoding behavior for now
          headers.values.has("content-type") || // `Blob` is superset of `File`
          globalThis.Blob && body instanceof globalThis.Blob || // `FormData` -> `multipart/form-data`
          body instanceof FormData || // `URLSearchParams` -> `application/x-www-form-urlencoded`
          body instanceof URLSearchParams || // Send chunked stream (each chunk has own `length`)
          globalThis.ReadableStream && body instanceof globalThis.ReadableStream
        ) {
          return { bodyHeaders: void 0, body };
        } else if (typeof body === "object" && (Symbol.asyncIterator in body || Symbol.iterator in body && "next" in body && typeof body.next === "function")) {
          return { bodyHeaders: void 0, body: Shims.ReadableStreamFrom(body) };
        } else if (typeof body === "object" && headers.values.get("content-type") === "application/x-www-form-urlencoded") {
          return {
            bodyHeaders: { "content-type": "application/x-www-form-urlencoded" },
            body: this.stringifyQuery(body)
          };
        } else {
          return tslib_1.__classPrivateFieldGet(this, _BaseAnthropic_encoder, "f").call(this, { body, headers });
        }
      }
    };
    exports2.BaseAnthropic = BaseAnthropic;
    _a = BaseAnthropic, _BaseAnthropic_encoder = /* @__PURE__ */ new WeakMap(), _BaseAnthropic_instances = /* @__PURE__ */ new WeakSet(), _BaseAnthropic_baseURLOverridden = function _BaseAnthropic_baseURLOverridden2() {
      return this.baseURL !== "https://api.anthropic.com";
    };
    BaseAnthropic.Anthropic = _a;
    BaseAnthropic.HUMAN_PROMPT = exports2.HUMAN_PROMPT;
    BaseAnthropic.AI_PROMPT = exports2.AI_PROMPT;
    BaseAnthropic.DEFAULT_TIMEOUT = 6e5;
    BaseAnthropic.AnthropicError = Errors.AnthropicError;
    BaseAnthropic.APIError = Errors.APIError;
    BaseAnthropic.APIConnectionError = Errors.APIConnectionError;
    BaseAnthropic.APIConnectionTimeoutError = Errors.APIConnectionTimeoutError;
    BaseAnthropic.APIUserAbortError = Errors.APIUserAbortError;
    BaseAnthropic.NotFoundError = Errors.NotFoundError;
    BaseAnthropic.ConflictError = Errors.ConflictError;
    BaseAnthropic.RateLimitError = Errors.RateLimitError;
    BaseAnthropic.BadRequestError = Errors.BadRequestError;
    BaseAnthropic.AuthenticationError = Errors.AuthenticationError;
    BaseAnthropic.InternalServerError = Errors.InternalServerError;
    BaseAnthropic.PermissionDeniedError = Errors.PermissionDeniedError;
    BaseAnthropic.UnprocessableEntityError = Errors.UnprocessableEntityError;
    BaseAnthropic.toFile = Uploads.toFile;
    var Anthropic2 = class extends BaseAnthropic {
      constructor() {
        super(...arguments);
        this.completions = new API.Completions(this);
        this.messages = new API.Messages(this);
        this.models = new API.Models(this);
        this.beta = new API.Beta(this);
      }
    };
    exports2.Anthropic = Anthropic2;
    Anthropic2.Completions = completions_1.Completions;
    Anthropic2.Messages = messages_1.Messages;
    Anthropic2.Models = models_1.Models;
    Anthropic2.Beta = beta_1.Beta;
  }
});

// node_modules/@anthropic-ai/sdk/index.js
var require_sdk = __commonJS({
  "node_modules/@anthropic-ai/sdk/index.js"(exports2, module2) {
    "use strict";
    exports2 = module2.exports = function(...args) {
      return new exports2.default(...args);
    };
    Object.defineProperty(exports2, "__esModule", { value: true });
    exports2.UnprocessableEntityError = exports2.PermissionDeniedError = exports2.InternalServerError = exports2.AuthenticationError = exports2.BadRequestError = exports2.RateLimitError = exports2.ConflictError = exports2.NotFoundError = exports2.APIUserAbortError = exports2.APIConnectionTimeoutError = exports2.APIConnectionError = exports2.APIError = exports2.AnthropicError = exports2.PagePromise = exports2.AI_PROMPT = exports2.HUMAN_PROMPT = exports2.Anthropic = exports2.BaseAnthropic = exports2.APIPromise = exports2.toFile = exports2.default = void 0;
    var client_1 = require_client();
    Object.defineProperty(exports2, "default", { enumerable: true, get: function() {
      return client_1.Anthropic;
    } });
    var uploads_1 = require_uploads2();
    Object.defineProperty(exports2, "toFile", { enumerable: true, get: function() {
      return uploads_1.toFile;
    } });
    var api_promise_1 = require_api_promise();
    Object.defineProperty(exports2, "APIPromise", { enumerable: true, get: function() {
      return api_promise_1.APIPromise;
    } });
    var client_2 = require_client();
    Object.defineProperty(exports2, "BaseAnthropic", { enumerable: true, get: function() {
      return client_2.BaseAnthropic;
    } });
    Object.defineProperty(exports2, "Anthropic", { enumerable: true, get: function() {
      return client_2.Anthropic;
    } });
    Object.defineProperty(exports2, "HUMAN_PROMPT", { enumerable: true, get: function() {
      return client_2.HUMAN_PROMPT;
    } });
    Object.defineProperty(exports2, "AI_PROMPT", { enumerable: true, get: function() {
      return client_2.AI_PROMPT;
    } });
    var pagination_1 = require_pagination();
    Object.defineProperty(exports2, "PagePromise", { enumerable: true, get: function() {
      return pagination_1.PagePromise;
    } });
    var error_1 = require_error();
    Object.defineProperty(exports2, "AnthropicError", { enumerable: true, get: function() {
      return error_1.AnthropicError;
    } });
    Object.defineProperty(exports2, "APIError", { enumerable: true, get: function() {
      return error_1.APIError;
    } });
    Object.defineProperty(exports2, "APIConnectionError", { enumerable: true, get: function() {
      return error_1.APIConnectionError;
    } });
    Object.defineProperty(exports2, "APIConnectionTimeoutError", { enumerable: true, get: function() {
      return error_1.APIConnectionTimeoutError;
    } });
    Object.defineProperty(exports2, "APIUserAbortError", { enumerable: true, get: function() {
      return error_1.APIUserAbortError;
    } });
    Object.defineProperty(exports2, "NotFoundError", { enumerable: true, get: function() {
      return error_1.NotFoundError;
    } });
    Object.defineProperty(exports2, "ConflictError", { enumerable: true, get: function() {
      return error_1.ConflictError;
    } });
    Object.defineProperty(exports2, "RateLimitError", { enumerable: true, get: function() {
      return error_1.RateLimitError;
    } });
    Object.defineProperty(exports2, "BadRequestError", { enumerable: true, get: function() {
      return error_1.BadRequestError;
    } });
    Object.defineProperty(exports2, "AuthenticationError", { enumerable: true, get: function() {
      return error_1.AuthenticationError;
    } });
    Object.defineProperty(exports2, "InternalServerError", { enumerable: true, get: function() {
      return error_1.InternalServerError;
    } });
    Object.defineProperty(exports2, "PermissionDeniedError", { enumerable: true, get: function() {
      return error_1.PermissionDeniedError;
    } });
    Object.defineProperty(exports2, "UnprocessableEntityError", { enumerable: true, get: function() {
      return error_1.UnprocessableEntityError;
    } });
  }
});

// netlify/functions/school-info.js
var require_school_info = __commonJS({
  "netlify/functions/school-info.js"(exports2, module2) {
    "use strict";
    module2.exports = {
      // ── SCHOOL INFO ──────────────────────────────────────────
      naam: "Verkeersschool Farhan",
      instructeur: "Farhan",
      // Volledige naam als bekend
      certificering: "WRM gecertificeerd",
      locaties: ["Assen (Drenthe)", "Amersfoort (Utrecht)"],
      whatsapp: "+31 6 44626777",
      email: "info@verkeersschoolfarhan.nl",
      telefoon: "+31 6 44626777",
      bereikbaar: "Maandag t/m zaterdag, 08:00\u201320:00",
      // ← aanpassen
      talen: ["Nederlands", "Engels"],
      // ← aanvullen indien nodig
      // ── PRIJZEN ──────────────────────────────────────────────
      losLes: {
        prijs: 60,
        duur: 60,
        // minuten
        beschrijving: "Losse les, geen verplichtingen"
      },
      proefles: {
        prijs: 60,
        duur: 60,
        beschrijving: "Vrijblijvend \u2014 geen verplichtingen achteraf"
      },
      pakketten: [
        {
          naam: "Compleet",
          prijs: 1199,
          lessen: 40,
          inclusiefTTT: true,
          inclusiefExamen: 1,
          inclusiefTheorie: true,
          spoedplanning: false,
          populair: true
        },
        {
          naam: "Intensief",
          prijs: 1599,
          lessen: 50,
          inclusiefTTT: true,
          inclusiefExamen: 2,
          inclusiefTheorie: true,
          spoedplanning: true,
          populair: false
        }
      ],
      // ── LOCATIE DETAILS ──────────────────────────────────────
      cbr: {
        assen: "CBR Assen",
        // ← exacte locatie invullen
        amersfoort: "CBR Amersfoort"
        // ← exacte locatie invullen
      },
      rijgebieden: {
        assen: ["Assen-Centrum", "Kloosterveen", "Peelo", "Rolde", "Beilen"],
        // ← aanvullen
        amersfoort: ["Amersfoort-Centrum", "Vathorst", "Nieuwland", "Soest"]
        // ← aanvullen
      },
      // ── INSTRUCTEUR ERVARING ─────────────────────────────────
      jarenErvaring: null,
      // ← invullen: bijv. 8
      specialisaties: [
        // ← aanvullen of verwijderen
        // 'Faalangstbegeleiding',
        // 'Spoedcursus rijbewijs',
        // 'Automaat lessen',
      ],
      // ── LESTIJDEN ────────────────────────────────────────────
      lestijden: {
        // ← invullen zodra bekend
        // maandag: '08:00–20:00',
        // zaterdag: '09:00–17:00',
        // zondag: 'Op afspraak',
      },
      // ── UNIEKE VERKOOPARGUMENTEN ─────────────────────────────
      usps: [
        "60 minuten per les voor vaste prijs \u2014 geen kortere lessen",
        "Altijd dezelfde instructeur van begin tot examen",
        "Na zak: direct verder zonder meerkosten",
        "Transparante prijzen, geen verborgen kosten",
        "2 locaties: Assen en Amersfoort"
      ],
      // ── WAT DE BOT NIET MAG ZEGGEN ───────────────────────────
      verboden: [
        "Rijbewijs garantie beloven",
        "Exact aantal lessen garanderen zonder proefles",
        "Vergelijkingen maken met andere rijscholen bij naam"
      ],
      // ── TOON ─────────────────────────────────────────────────
      toon: "warm en direct",
      // opties: 'formeel', 'casual', 'warm en direct'
      maxAntwoordZinnen: 3
    };
  }
});

// netlify/functions/chat.js
var Anthropic = require_sdk();
var info = require_school_info();
function buildSystemPrompt(i) {
  const compleet = i.pakketten.find((p) => p.naam === "Compleet");
  const intensief = i.pakketten.find((p) => p.naam === "Intensief");
  const besparingCompleet = compleet ? compleet.lessen * i.losLes.prijs - compleet.prijs : null;
  const besparingIntensief = intensief ? intensief.lessen * i.losLes.prijs - intensief.prijs : null;
  return `Je bent de slimme, vriendelijke AI-assistent van ${i.naam}. Je spreekt ${i.toon} Nederlands \u2014 zoals een behulpzame medewerker, niet een robot.

\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
SCHOOL
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
Naam: ${i.naam}
Instructeur: ${i.instructeur}${i.jarenErvaring ? ` (${i.jarenErvaring} jaar ervaring)` : ""} \u2014 ${i.certificering}
Locaties: ${i.locaties.join(" en ")}
WhatsApp: ${i.whatsapp}
Email: ${i.email}
Bereikbaar: ${i.bereikbaar}
Talen: ${i.talen.join(", ")}
${i.specialisaties.length ? `Specialisaties: ${i.specialisaties.join(", ")}` : ""}

\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
PRIJZEN
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
Losse les: \u20AC${i.losLes.prijs} per les (altijd ${i.losLes.duur} minuten, 1-op-1)
Proefles: \u20AC${i.proefles.prijs} \u2014 ${i.proefles.beschrijving}

${i.pakketten.map((p) => {
    const besparing = p.lessen * i.losLes.prijs - p.prijs;
    const perLes = Math.round(p.prijs / p.lessen);
    return `${p.naam}${p.populair ? " \u2B50" : ""} \u2014 \u20AC${p.prijs.toLocaleString("nl")} totaal (\u2248 \u20AC${perLes}/les):
- ${p.lessen} rijlessen van ${i.losLes.duur} minuten
- Theoriebegeleiding: ${p.inclusiefTheorie ? "inbegrepen" : "niet inbegrepen"}
- Tussentijdse toets (TTT): ${p.inclusiefTTT ? "inbegrepen" : "niet inbegrepen"}
- Examens inbegrepen: ${p.inclusiefExamen}x
- Spoedplanning: ${p.spoedplanning ? "beschikbaar" : "standaard"}
- Besparing vs. losse lessen: \u20AC${besparing.toLocaleString("nl")}`;
  }).join("\n\n")}

\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
HOE HET WERKT
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
1. Proefles (\u20AC${i.proefles.prijs}) \u2014 ${i.instructeur} rijdt mee, eerlijk oordeel, geen verplichtingen
2. Persoonlijk rijplan \u2014 samen bepalen hoeveel lessen je nodig hebt
3. Rijlessen \u2014 ${i.losLes.duur} min per les, op jouw tempo, directe feedback
4. TTT \u2014 proefexamen bij ${i.cbr.assen} of ${i.cbr.amersfoort}
5. Rijexamen \u2014 volledig voorbereid, ${i.instructeur} begeleidt je

\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
RIJGEBIEDEN
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
Assen: ${i.rijgebieden.assen.join(", ")}
Amersfoort: ${i.rijgebieden.amersfoort.join(", ")}

\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
WAT MAAKT ONS ANDERS
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
${i.usps.map((u, n) => `${n + 1}. ${u}`).join("\n")}

\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
VEELGESTELDE VRAGEN
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
V: Wat kost een proefles?
A: \u20AC${i.proefles.prijs} voor ${i.proefles.duur} minuten. Daarna geen verplichtingen.

V: Hoe snel kan ik beginnen?
A: Vaak binnen een week. Stuur ${i.instructeur} een WhatsApp: ${i.whatsapp}

V: Wat als ik zak?
A: Dan gaan we gewoon door. We bespreken wat er misging en plannen het herexamen zo snel mogelijk. Bij het Intensief-pakket zit een tweede examen al inbegrepen.

V: Welk pakket is het beste voor mij?
A: Dat hangt af van je ervaring. Start altijd met een proefles (\u20AC${i.proefles.prijs}) \u2014 daarna weet ${i.instructeur} precies wat je nodig hebt.

V: Moet ik eerst theorie doen?
A: Nee. Je kunt theorie en rijlessen tegelijk doen.

V: Zijn er verborgen kosten?
A: Nee. Alle kosten zijn vooraf duidelijk.

V: Hoe lang duurt een les?
A: Altijd ${i.losLes.duur} minuten. Geen kortere lessen.

V: Zijn jullie ook actief buiten Assen/Amersfoort?
A: Wij rijden in en rondom ${i.locaties.join(" en ")}. Vraag ${i.instructeur} via WhatsApp of jouw woonplaats erbij zit.

\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
CONVERSIE-REGELS
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
- Vraagt iemand naar prijs? \u2192 Noem proefles als laagdrempelig startpunt
- Twijfelt iemand? \u2192 Benadruk dat proefles geen verplichtingen heeft
- Wil iemand inschrijven? \u2192 Stuur naar WhatsApp ${i.whatsapp}
- Zegt iemand "te duur"? \u2192 Wijs op pakketbesparing (\u20AC${besparingCompleet?.toLocaleString("nl")} goedkoper dan losse lessen)
- Bang om te zakken? \u2192 Benadruk "na zak gaan we door" aanpak

\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
STIJLREGELS
\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501
- Antwoord in dezelfde taal als de gebruiker (NL, EN${i.talen.includes("Arabisch") ? ", AR" : ""})
- Wees warm, direct en eerlijk \u2014 geen verkooppraatjes
- Maximaal ${i.maxAntwoordZinnen} zinnen per antwoord, tenzij een lijst duidelijker is
- Verzin NOOIT informatie die hier niet staat \u2014 wees eerlijk en verwijs naar WhatsApp
- Verboden: ${i.verboden.join(" \xB7 ")}`;
}
exports.handler = async (event) => {
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type"
  };
  if (event.httpMethod === "OPTIONS") return { statusCode: 200, headers, body: "" };
  if (event.httpMethod !== "POST") return { statusCode: 405, headers, body: JSON.stringify({ error: "Method not allowed" }) };
  if (!process.env.ANTHROPIC_API_KEY) {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        content: `Hoi! Neem even contact op via WhatsApp: ${info.whatsapp} \u2014 we reageren snel! \u{1F44B}`
      })
    };
  }
  try {
    const { messages } = JSON.parse(event.body);
    const client = new Anthropic.default({ apiKey: process.env.ANTHROPIC_API_KEY });
    const response = await client.messages.create({
      model: "claude-haiku-4-5-20251001",
      max_tokens: 500,
      system: buildSystemPrompt(info),
      messages: messages.slice(-12)
    });
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ content: response.content[0].text })
    };
  } catch (err) {
    console.error(err);
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        content: `Even een technisch probleem \u2014 stuur gerust een WhatsApp: ${info.whatsapp} \u{1F4AC}`
      })
    };
  }
};
